var config = {
    map: {
        '*': {
            'Magento_Catalog/js/price-utils' : 'Lillik_PriceDecimal/js/price-utils'
        }
    }
};