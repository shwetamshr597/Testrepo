var config = {
    map: {
        '*': {
            slick: 'Elgentos_Gallery/js/slick.min',
            fancybox: 'Elgentos_Gallery/js/jquery.fancybox.min'
        }
    }
}
