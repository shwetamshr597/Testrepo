![elgentos/gallery](https://banners.beyondco.de/Magento%202%20Gallery%20Replacement.png?theme=light&packageName=elgentos%2Fgallery&pattern=hideout&style=style_1&description=Simple+Magento+2+gallery+replacement+to+swap+out+Fotorama&md=1&fontSize=100px&images=photograph)

# elgentos/gallery

Simple Magento 2 gallery replacement to swap out Fotorama
