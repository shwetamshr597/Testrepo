<?php


namespace Dutchento\Vatfallback\Service\Exceptions;


class ValidationDisabledException extends GenericException
{

}
