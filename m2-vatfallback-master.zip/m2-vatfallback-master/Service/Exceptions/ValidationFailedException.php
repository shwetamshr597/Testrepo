<?php


namespace Dutchento\Vatfallback\Service\Exceptions;


class ValidationFailedException extends GenericException
{

}
