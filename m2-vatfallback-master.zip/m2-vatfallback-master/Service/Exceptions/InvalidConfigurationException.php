<?php


namespace Dutchento\Vatfallback\Service\Exceptions;


class InvalidConfigurationException extends GenericException
{

}
