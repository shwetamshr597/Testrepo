<?php


namespace Dutchento\Vatfallback\Service\Exceptions;


class ValidationIgnoredException extends GenericException
{

}
