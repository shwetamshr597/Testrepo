<?php


namespace Dutchento\Vatfallback\Service\Exceptions;


class NoValidationException extends GenericException
{

}
