<?php


namespace Dutchento\Vatfallback\Service\Exceptions;


class ValidationUnavailableException extends GenericException
{

}
