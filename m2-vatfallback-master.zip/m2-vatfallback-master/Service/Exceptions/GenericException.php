<?php


namespace Dutchento\Vatfallback\Service\Exceptions;


class GenericException extends \RuntimeException
{

}
