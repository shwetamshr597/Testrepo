var config = {
    map: {
        '*': {
            cs_task: 'Wyomind_CronScheduler/js/task'
        }
    }
}; 