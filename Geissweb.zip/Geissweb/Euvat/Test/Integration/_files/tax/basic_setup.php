<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

use Magento\Tax\Api\TaxClassManagementInterface;
use Magento\TestFramework\Helper\Bootstrap;
use Magento\Framework\ObjectManagerInterface;
use Magento\Tax\Api\TaxClassRepositoryInterface;
use Magento\Tax\Api\TaxRuleRepositoryInterface;
use Magento\Tax\Api\Data\TaxClassInterfaceFactory;
use Magento\Tax\Api\Data\TaxClassInterface;
use Magento\Tax\Api\Data\TaxRateInterfaceFactory;
use Magento\Tax\Api\Data\TaxRateInterface;
use Magento\Tax\Api\TaxRateRepositoryInterface;
use Magento\Tax\Api\Data\TaxRuleInterfaceFactory;
use Magento\Tax\Api\Data\TaxRuleInterface;

/** @var ObjectManagerInterface $objectManager */
$objectManager = Bootstrap::getObjectManager();
/** @var TaxClassRepositoryInterface $taxClassRepository */
$taxClassRepository = $objectManager->get(TaxClassRepositoryInterface::class);
$taxClassFactory = $objectManager->get(TaxClassInterfaceFactory::class);

// CUSTOMER TAX CLASSES
/** @var TaxClassInterface $taxClassDataObject */
$taxClassDataObject = $taxClassFactory->create();
$taxClassDataObject->setClassName('Consumer')
    ->setClassType(TaxClassManagementInterface::TYPE_CUSTOMER);
$consumerCustomerTaxClass = $taxClassRepository->save($taxClassDataObject);
$taxClassDataObject = $taxClassFactory->create();
$taxClassDataObject->setClassName('Business')
    ->setClassType(TaxClassManagementInterface::TYPE_CUSTOMER);
$businessCustomerTaxClass = $taxClassRepository->save($taxClassDataObject);

// PRODUCT TAX CLASSES
$taxClassDataObject = $taxClassFactory->create();
$taxClassDataObject->setClassName('Standard VAT')
    ->setClassType(TaxClassManagementInterface::TYPE_PRODUCT);
$standardProductTaxClass = $taxClassRepository->save($taxClassDataObject);

// TAX RATES
$taxRateFactory = $objectManager->get(TaxRateInterfaceFactory::class);
/** @var TaxRateRepositoryInterface $taxRateRepository */
$taxRateRepository = $objectManager->get(TaxRateRepositoryInterface::class);
$standardTaxRates = [];
/** @var TaxRateInterface $taxRate */
$taxRate = $taxRateFactory->create();
$taxRate->setTaxCountryId('DE')
    ->setTaxRegionId(0)
    ->setTaxPostcode('*')
    ->setCode('Germany Standard')
    ->setRate(19.0);
$standardTaxRates[] = $taxRateRepository->save($taxRate);

$taxRate = $taxRateFactory->create();
$taxRate->setTaxCountryId('AT')
    ->setTaxRegionId(0)
    ->setTaxPostcode('*')
    ->setCode('Austria Standard')
    ->setRate(20.0);
$standardTaxRates[] = $taxRateRepository->save($taxRate);

$taxRate = $taxRateFactory->create();
$taxRate->setTaxCountryId('CH')
    ->setTaxRegionId(0)
    ->setTaxPostcode('*')
    ->setCode('Switzerland Standard')
    ->setRate(19.0);
$standardTaxRates[] = $taxRateRepository->save($taxRate);

$standardRateIds = array_map(static function ($taxRate) {
    return $taxRate->getId();
}, $standardTaxRates);

$taxRate = $taxRateFactory->create();
$zeroTaxRates = [];
$taxRate->setTaxCountryId('DE')
    ->setTaxRegionId(0)
    ->setTaxPostcode('*')
    ->setCode('Germany Domestic')
    ->setRate(19);
$zeroTaxRates[] = $taxRateRepository->save($taxRate);
$taxRate = $taxRateFactory->create();
$zeroTaxRates = [];
$taxRate->setTaxCountryId('AT')
    ->setTaxRegionId(0)
    ->setTaxPostcode('*')
    ->setCode('Austria Exempt')
    ->setRate(0);
$zeroTaxRates[] = $taxRateRepository->save($taxRate);
$taxRate = $taxRateFactory->create();
$taxRate->setTaxCountryId('CH')
    ->setTaxRegionId(0)
    ->setTaxPostcode('*')
    ->setCode('Switzerland Exempt')
    ->setRate(0);
$zeroTaxRates[] = $taxRateRepository->save($taxRate);
$zeroRateIds = array_map(static function ($taxRate) {
    return $taxRate->getId();
}, $zeroTaxRates);

/** @var TaxRuleRepositoryInterface $taxRuleRepository */
$taxRuleRepository = $objectManager->get(TaxRuleRepositoryInterface::class);
$taxRuleFactory = $objectManager->get(TaxRuleInterfaceFactory::class);
/** @var TaxRuleInterface $taxRule */
$taxRule = $taxRuleFactory->create();
$taxRule->setCode('Consumer Rule')
    ->setCustomerTaxClassIds([$consumerCustomerTaxClass])
    ->setProductTaxClassIds([$standardProductTaxClass])
    ->setTaxRateIds($standardRateIds)
    ->setPriority(0);
$taxRuleRepository->save($taxRule);
$taxRule = $taxRuleFactory->create();
$taxRule->setCode('Business Rule')
    ->setCustomerTaxClassIds([$businessCustomerTaxClass])
    ->setProductTaxClassIds([$standardProductTaxClass])
    ->setTaxRateIds($zeroRateIds)
    ->setPriority(0);
$taxRuleRepository->save($taxRule);
