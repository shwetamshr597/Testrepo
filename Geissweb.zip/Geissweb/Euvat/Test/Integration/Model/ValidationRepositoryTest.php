<?php

namespace Geissweb\Euvat\Test\Integration\Model;

use PHPUnit\Framework\TestCase;

use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\Api\SearchResults;
use Magento\TestFramework\ObjectManager;

use Geissweb\Euvat\Model\ValidationRepository;
use Geissweb\Euvat\Api\Data\ValidationInterface;

class ValidationRepositoryTest extends TestCase
{
    /**
     * @var \Geissweb\Euvat\Api\Data\ValidationInterface|mixed
     */
    private $validation;
    /**
     * @var \Geissweb\Euvat\Model\ValidationRepository|mixed
     */
    private $repository;

    /**
     * @inheritdoc
     */
    protected function setUp(): void
    {
        parent::setUp();
        $this->objectManager = ObjectManager::getInstance();
        $this->repository = $this->objectManager->get(ValidationRepository::class);
        $this->setUpValidationFixture();
    }

    private function setUpValidationFixture(): void
    {
        $this->validation = $this->objectManager->create(ValidationInterface::class);
        $this->validation->setHandle('test_test')
            ->setRequestMessage('Success')
            ->setVatId('DE123456789')
            ->setVatIsValid(true)
            ->setVatRequestDate('2022-10-05 23:55:00')
            ->setVatRequestId('TESTWapjgawo4egjoajig4')
            ->setVatRequestSuccess(true)
            ->setVatTraderName('Test Company GmbH')
            ->setVatTraderAddress("Street Number 1\n98765 Berlin");

        $this->repository->save($this->validation);
    }

    protected function tearDown() : void
    {
        $this->repository->deleteById($this->validation->getId());
    }

    public function testGetById(): void
    {
        $loadedValidation = $this->repository->get($this->validation->getId());
        $this->assertEquals('DE123456789', $loadedValidation->getVatId());
    }

    public function testGetList(): void
    {
        /** @var SearchCriteriaBuilder $searchCriteriaBuilder */
        $searchCriteriaBuilder = $this->objectManager->create(SearchCriteriaBuilder::class);
        $searchCriteriaBuilder->addFilter('vat_id', 'DE123456789');
        $list = $this->repository->getList($searchCriteriaBuilder->create());
        $this->assertInstanceOf(SearchResults::class, $list);
        $this->assertCount(1, $list->getItems());
        foreach ($list->getItems() as $item) {
            $this->assertEquals('DE123456789', $item->getVatId());
        }
    }
}
