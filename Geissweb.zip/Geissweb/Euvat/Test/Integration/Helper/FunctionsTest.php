<?php

namespace Geissweb\Euvat\Test\Integration\Helper;

use Geissweb\Euvat\Api\Data\ValidationInterface;
use Geissweb\Euvat\Helper\Functions;
use Magento\TestFramework\ObjectManager;
use Magento\Framework\Intl\DateTimeFactory;

class FunctionsTest extends \PHPUnit\Framework\TestCase
{
    /**
     * @var \Geissweb\Euvat\Api\Data\ValidationInterface|mixed
     */
    private $validation;

    /**
     * @inheritdoc
     */
    protected function setUp(): void
    {
        parent::setUp();
        $this->objectManager = ObjectManager::getInstance();
        $this->helper = $this->objectManager->get(Functions::class);
        $this->dateTimeFactory = $this->objectManager->get(DateTimeFactory::class);
    }

    private function getValidationFixture(
        $vatId = 'DE267070673',
        $isValid = true,
        $reqId = '',
        $reqSuccess = true,
        $reqDate = null,
        $reqMsg = 'The VAT Number is valid.',
        $name = 'Test Company GmbH',
        $address = "Street Number 1\n12345 Berlin"
    ) {
        $yesterday = $this->dateTimeFactory->create()
            ->setDate(date("Y"), date("m"), date("d") - 1);

        $fixture = [
            'handle' => null,
            'vat_id' => $vatId,
            'vat_is_valid' => $isValid,
            'vat_request_id' => $reqId !== '' ? $reqId : 'WAPIAAAAYPrkhvGd',
            'vat_request_success' => $reqSuccess,
            'vat_request_date' => $reqDate ?? $yesterday->format("Y-m-d H:i:s"),
            'request_message' => $reqMsg,
            'vat_trader_name' => $name,
            'vat_trader_address' => $address,
        ];
        $this->validation = $this->objectManager->create(ValidationInterface::class);
        $this->validation->setHandle($fixture['handle'])
            ->setVatId($fixture['vat_id'])
            ->setVatIsValid($fixture['vat_is_valid'])
            ->setVatRequestId($fixture['vat_request_id'])
            ->setVatRequestSuccess($fixture['vat_request_success'])
            ->setVatRequestDate($fixture['vat_request_date'])
            ->setRequestMessage($fixture['request_message'])
            ->setVatTraderName($fixture['vat_trader_name'])
            ->setVatTraderAddress($fixture['vat_trader_address']);

        return $this->validation;
    }

    public function testValidationExpired()
    {
        $validation = $this->getValidationFixture();
        //echo PHP_EOL;
        //echo "Now is: ".$this->dateTimeFactory->create()->format("Y-m-d H:i:s").PHP_EOL;
        //echo "Testing validation with date: ".$validation->getVatRequestDate().PHP_EOL;
        $needTo_1 = $this->helper->isValidationExpired($validation, 1);
        $this->assertFalse($needTo_1);

        $validation->setVatRequestDate("2020-10-10 10:10:10");
        $needTo_365 = $this->helper->isValidationExpired($validation, 365);
        $this->assertTrue($needTo_365);
    }

    public function testNeedToValidate()
    {
        $validation = $this->getValidationFixture();
        $needTo = $this->helper->getNeedToValidate($validation->getVatId());
        $this->assertTrue($needTo); // Should not exist yet
    }
}
