<?php

namespace Geissweb\Euvat\Test\Integration\Controller;

//use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Framework\Data\Form\FormKey;
use Magento\TestFramework\TestCase\AbstractController;

/**
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 * @magentoDbIsolation enabled
 */
class ValidationTest extends AbstractController
{
    private ?FormKey $formKey;

    /**
     * @inheritdoc
     */
    protected function setUp(): void
    {
        parent::setUp();
        $this->formKey = $this->_objectManager->get(FormKey::class);
    }

    /**
     * @return void
     */
    public function testValidationEU()
    {
        $this->validate('DE123456789', false);
        $this->validate('LU20944528', true);
    }

    /**
     * @return void
     */
    public function testValidationGB()
    {
        $this->validate('GB132331166', true);
    }

    private function validate(string $vatNumber, bool $shouldBeValid) : void
    {
        $postData = [
            'vat_number' => $vatNumber,
            'form_key' => $this->formKey->getFormKey()
        ];
        $this->getRequest()->setMethod('GET');
        $this->getRequest()->setParams($postData);
        $this->getRequest()->getHeaders()->addHeaderLine('X-Requested-With', 'XMLHttpRequest');

        $this->dispatch('euvat/vatnumber/validation');
        /** @var \Magento\Framework\App\Response\Http $response */
        $response = $this->getResponse()->getBody();
        $this->assertJson($response, 'Response has to be JSON');

        $result = json_decode($response, true);

        $this->assertIsArray($result, 'Json decode of validation response failed');
        $this->assertArrayHasKey('vat_is_valid', $result, 'Validation result is missing data');

        if ($shouldBeValid) {
            $this->assertTrue(
                (bool)$result['vat_is_valid'],
                'Validation result is wrong, should be valid but is invalid'
            );
        } else {
            $this->assertFalse(
                (bool)$result['vat_is_valid'],
                'Validation result is wrong, should be invalid but is valid'
            );
        }
    }
}
