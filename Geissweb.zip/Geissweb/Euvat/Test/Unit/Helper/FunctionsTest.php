<?php
declare(strict_types=1);

namespace Geissweb\Euvat\Test\Unit\Helper;

use Geissweb\Euvat\Api\Data\ValidationInterface;
use Geissweb\Euvat\Helper\Configuration;
use Geissweb\Euvat\Helper\Functions;
use Geissweb\Euvat\Logger\Logger;
use Geissweb\Euvat\Model\ValidationRepository;
use Geissweb\Euvat\Validator\Syntax;
use Magento\Framework\Intl\DateTimeFactory;
use PHPUnit\Framework\TestCase;

class FunctionsTest extends TestCase
{
    private Functions $functions;
    private ValidationRepository $validationRepository;
    protected function setUp(): void
    {
        $configHelper = $this->createMock(Configuration::class);
        $logger = $this->createMock(Logger::class);
        $this->validationRepository = $this->createMock(ValidationRepository::class);
        $syntaxValidator = $this->createMock(Syntax::class);
        $dateTimeFactory = $this->createMock(DateTimeFactory::class);
        $dateTimeFactory->method('create')
            ->willReturnCallback(function ($time) {
                return new \DateTime($time);
            });

        $this->functions = $this->getMockBuilder(Functions::class)
            ->setConstructorArgs([
                $configHelper,
                $logger,
                $this->validationRepository,
                $syntaxValidator,
                $dateTimeFactory
            ])
            ->onlyMethods(['getValidationData'])
            ->getMock();
    }

    /**
     * @dataProvider getNeedToValidateDataProvider
     */
    public function testGetNeedToValidate(string $vatNumber, array $mockReturns, bool $expected): void
    {
        $validation = $this->createMock(ValidationInterface::class);
        $validation->method('getVatRequestId')->willReturn($mockReturns['requestId']);
        $validation->method('getVatRequestSuccess')->willReturn($mockReturns['requestSuccess']);
        $validation->method('getVatIsValid')->willReturn($mockReturns['isValid']);
        $validation->method('getVatRequestDate')->willReturn($mockReturns['requestDate']);
        // Mock the getValidationData method to return our mocked ValidationInterface
        $this->functions->method('getValidationData')->willReturn($validation); //@phpstan-ignore-line

        $result = $this->functions->getNeedToValidate($vatNumber);
        $this->assertEquals($expected, $result);
    }

    public function getNeedToValidateDataProvider(): array
    {
        return [
            //offline validation
            ['DE123456789', [
                'requestId' => 'OFFLINE',
                'requestSuccess' => false,
                'isValid' => false,
                'requestDate' => '2021-01-01 00:00:00'
                ],
                true
            ],
            //initial validation
            ['FR123456789', [
                'requestId' => 'INIT',
                'requestSuccess' => true,
                'isValid' => true,
                'requestDate' => '2021-01-01 00:00:00'
                ],
                true
            ],
            //expired validation
            ['DE123456789', [
                'requestId' => 'abc123',
                'requestSuccess' => true,
                'isValid' => true,
                'requestDate' => '2021-01-01 00:00:00'
                ],
                true
            ],
            //totally new
            ['DE123456789', [
                'requestId' => 'abc123',
                'requestSuccess' => true,
                'isValid' => true,
                'requestDate' => 'now'
                ],
                false
            ],
            //totally new false
            ['DE123456789', [
                'requestId' => 'abc123',
                'requestSuccess' => false,
                'isValid' => false,
                'requestDate' => 'now'
                ],
                true
            ],
        ];
    }
}
