<?php
declare(strict_types=1);

namespace Geissweb\Euvat\Setup\Patch\Data;

use Magento\Customer\Setup\CustomerSetupFactory;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\Patch\DataPatchInterface;
use Magento\Framework\Setup\Patch\PatchRevertableInterface;
use Magento\Framework\Setup\Patch\PatchVersionInterface;
use Magento\Eav\Api\AttributeRepositoryInterface;

/** This patch removes the VAT Trader fields from admihtml_sales_order_create */
class VatTraderAttributesHidePatch implements DataPatchInterface, PatchRevertableInterface, PatchVersionInterface
{
    public const ADDRESS_ENTITY = 'customer_address';
    /**
     * @var ModuleDataSetupInterface $moduleDataSetup
     */
    private $moduleDataSetup;

    /**
     * @var \Magento\Customer\Setup\CustomerSetupFactory
     */
    private $customerSetupFactory;

    /** @var string[] $attributes */
    private $attributes = [
        'vat_trader_name',
        'vat_trader_address'
    ];
    /**
     * @var \Magento\Eav\Api\AttributeRepositoryInterface
     */
    private AttributeRepositoryInterface $attributeRepository;

    /**
     * @param ModuleDataSetupInterface $moduleDataSetup
     * @param \Magento\Customer\Setup\CustomerSetupFactory $customerSetupFactory
     */
    public function __construct(
        ModuleDataSetupInterface $moduleDataSetup,
        CustomerSetupFactory $customerSetupFactory,
        AttributeRepositoryInterface $attributeRepository
    ) {
        $this->moduleDataSetup = $moduleDataSetup;
        $this->customerSetupFactory = $customerSetupFactory;
        $this->attributeRepository = $attributeRepository;
    }

    public static function getVersion()
    {
        return '1.8.8';
    }

    /**
     * @inheritdoc
     */
    public function getAliases()
    {
        return [];
    }

    /**
     * @inheritdoc
     */
    public static function getDependencies()
    {
        return [
            VatTraderAttributesPatch::class
        ];
    }

    /**
     * Do Upgrade
     */
    public function apply()
    {
        $this->moduleDataSetup->startSetup();
        $this->hideVatTraderAttributes();
        $this->moduleDataSetup->endSetup();
        return $this;
    }

    /**
     * Adds customer address attributes for the data the service interface returns
     *
     * @return void
     * @throws \Magento\Framework\Exception\StateException
     */
    private function hideVatTraderAttributes(): void
    {
        $customerSetup = $this->customerSetupFactory->create(['setup' => $this->moduleDataSetup]);
        foreach ($this->attributes as $attributeCode) {
            $attribute = $customerSetup->getEavConfig()
                ->clear()
                ->getAttribute(self::ADDRESS_ENTITY, $attributeCode);
            if ($attribute !== null) {
                $attribute->setData('used_in_forms', []);
                $this->attributeRepository->save($attribute);
            }
        }
    }

    /**
     * Rollback all changes, done by this patch
     *
     * @return void
     * @throws \Exception
     */
    public function revert()
    {
        $this->moduleDataSetup->startSetup();
        $customerSetup = $this->customerSetupFactory->create(['setup' => $this->moduleDataSetup]);
        foreach ($this->attributes as $attributeCode) {
            $attribute = $customerSetup->getEavConfig()
                ->clear()
                ->getAttribute(self::ADDRESS_ENTITY, $attributeCode);
            if ($attribute !== null) {
                $attribute->setData('used_in_forms', ['adminhtml_customer_address']);
                $this->attributeRepository->save($attribute);
            }
        }
        $this->moduleDataSetup->endSetup();
    }
}
