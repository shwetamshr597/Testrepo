<?php
declare(strict_types=1);

namespace Geissweb\Euvat\Setup\Patch\Data;

use Magento\Customer\Setup\CustomerSetupFactory;
use Magento\Eav\Api\AttributeRepositoryInterface;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Exception\StateException;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\Patch\DataPatchInterface;
use Magento\Framework\Setup\Patch\PatchRevertableInterface;

/**
 * This patch is the replacement for the old InstallData.php script.
 * It does not implement the PatchVersionInterface because it is thought as an install, not upgrade script.
 */
class VatTraderAttributesPatch implements DataPatchInterface, PatchRevertableInterface
{
    public const ADDRESS_ENTITY = 'customer_address';
    private ModuleDataSetupInterface $moduleDataSetup;
    private CustomerSetupFactory $customerSetupFactory;
    private AttributeRepositoryInterface $attributeRepository;

    /**
     * @param ModuleDataSetupInterface $moduleDataSetup
     * @param \Magento\Customer\Setup\CustomerSetupFactory $customerSetupFactory
     * @param \Magento\Eav\Api\AttributeRepositoryInterface $attributeRepository
     */
    public function __construct(
        ModuleDataSetupInterface $moduleDataSetup,
        CustomerSetupFactory $customerSetupFactory,
        AttributeRepositoryInterface $attributeRepository
    ) {
        $this->moduleDataSetup = $moduleDataSetup;
        $this->customerSetupFactory = $customerSetupFactory;
        $this->attributeRepository = $attributeRepository;
    }

    /**
     * @inheritdoc
     */
    public function getAliases(): array
    {
        return [];
    }

    /**
     * @inheritdoc
     */
    public static function getDependencies(): array
    {
        return [];
    }

    /**
     * Do Upgrade
     *
     * @throws \Magento\Framework\Exception\StateException
     */
    public function apply(): VatTraderAttributesPatch
    {
        $this->moduleDataSetup->startSetup();
        $this->addVatTraderAttributes();
        $this->moduleDataSetup->endSetup();
        return $this;
    }

    /**
     * Adds customer address attributes for the data the service interface returns
     *
     * @return void
     * @throws \Magento\Framework\Exception\StateException
     */
    private function addVatTraderAttributes(): void
    {
        $attributes = [
            'vat_trader_name' => [
                'label' => 'VAT number company name',
                'type' => 'static',
                'input' => 'text',
                'required' => false,
                'position' => 150,
                'visible' => true,
                'system' => 0,
                'user_defined' => true,
                'is_user_defined' => 1,
                'is_used_in_grid' => false,
                'is_visible_in_grid' => false,
                'is_filterable_in_grid' => false,
                'is_searchable_in_grid' => false,
            ],
            'vat_trader_address' => [
                'label' => 'VAT number company address',
                'type' => 'static',
                'input' => 'textarea',
                'required' => false,
                'position' => 160,
                'visible' => true,
                'system' => 0,
                'user_defined' => true,
                'is_user_defined' => 1,
                'is_used_in_grid' => false,
                'is_visible_in_grid' => false,
                'is_filterable_in_grid' => false,
                'is_searchable_in_grid' => false,
            ],
        ];

        $customerSetup = $this->customerSetupFactory->create(['setup' => $this->moduleDataSetup]);
        foreach ($attributes as $attributeCode => $attributeParams) {
            try {
                $this->attributeRepository->get(self::ADDRESS_ENTITY, $attributeCode);
            } catch (NoSuchEntityException $e) {
                $customerSetup->addAttribute(self::ADDRESS_ENTITY, $attributeCode, $attributeParams);
                $attribute = $customerSetup->getEavConfig()
                    ->clear()
                    ->getAttribute(self::ADDRESS_ENTITY, $attributeCode);
                if ($attribute !== null) {
                    $attribute->setData('used_in_forms', ['adminhtml_customer_address']);
                    $this->attributeRepository->save($attribute);
                }
            }
        }
    }

    /**
     * Rollback all changes, done by this patch
     *
     * @return void
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function revert(): void
    {
        $this->moduleDataSetup->startSetup();
        $vatTraderNameAttributeId = $this->attributeRepository->get(
            self::ADDRESS_ENTITY,
            'vat_trader_name'
        )->getAttributeId();
        $vatTraderAddressAttributeId = $this->attributeRepository->get(
            self::ADDRESS_ENTITY,
            'vat_trader_address'
        )->getAttributeId();

        /** @var \Magento\Customer\Setup\CustomerSetup $customerSetup */
        $customerSetup = $this->customerSetupFactory->create(['setup' => $this->moduleDataSetup]);
        $customerSetup->removeAttribute(self::ADDRESS_ENTITY, 'vat_trader_name');
        $customerSetup->removeAttribute(self::ADDRESS_ENTITY, 'vat_trader_address');

        if (isset($vatTraderNameAttributeId, $vatTraderAddressAttributeId)) {
            $this->moduleDataSetup->getConnection()->delete(
                $this->moduleDataSetup->getTable('customer_eav_attribute'),
                ['attribute_id = ?' => $vatTraderNameAttributeId]
            );
            $this->moduleDataSetup->getConnection()->delete(
                $this->moduleDataSetup->getTable('customer_eav_attribute'),
                ['attribute_id = ?' => $vatTraderAddressAttributeId]
            );
        }

        $this->moduleDataSetup->endSetup();
    }
}
