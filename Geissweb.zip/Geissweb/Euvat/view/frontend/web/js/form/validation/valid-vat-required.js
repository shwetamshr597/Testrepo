define([
    'jquery',
    'mage/translate',
    'mageUtils',
    'euvatTools'
], function(
    $,
    $t,
    Utils,
    EuVatTools
) {
    'use strict';

    return function(value, component) {

        if(typeof component !== 'object' || !component.vatFieldFunctionalityEnabled) {
            return true;
        }

        if(component.debug) {
            console.log('valid-vat-required validation', component);
        }

        if(!component.visible()) {
            if(component.debug) {
                console.log('valid-vat-required not visible');
            }
            return true;
        }

        if(!Utils.isEmpty(value) && component.validatedNumber() !== value) {
            let results = window.checkoutConfig.vatNumberValidationResults;
            if(typeof results === 'object' && typeof results[value] === 'object') {
                component.isChanging = false;
                component.validatedNumber(value);
                component.isValidated(results[value].vat_request_success);
                component.isValidVatNumber(results[value].vat_is_valid);
            }
        }

        if(Utils.isEmpty(component.value())) {
            if(component.debug) {
                console.log('valid-vat-required is empty');
            }
            return false;
        }

        if(!EuVatTools.isValidateable(
            component.getCountry(), // address country
            component.euCountries,
            component.noValidateCountries)
        ) {
            if(component.debug) {
                console.log('valid-vat-required not isValidateable');
            }
            return true;
        }

        if (component.offlineValidationEnabled
            && component.response.vat_request_success === false
            && component.passedRegex()
        ) {
            if(component.debug) {
                console.log('valid-vat-required disabled AJAX but pass Regex');
            }
            return true;
        }

        let errMsg = component.error() || '';

        if(component.debug) {
            console.log('valid-vat-required conditions', [
                value,
                component.isValidated(),
                component.isValidVatNumber(),
                (errMsg.length <= 0)
            ]);
        }

        /*
        if(!component.isValidated()) {
            if(component.debug) {
                console.log('valid-vat-required !isValidated (yet)');
            }
            component.validateVatNumber(component.value());
            return false;
        }

         */

        return component.isValidated() && component.isValidVatNumber() && (errMsg.length <= 0);

    };
});


