define([
    'euvatTools'
], function(
    EuVatTools
) {
    'use strict';

    return function(value, component) {

        if(typeof component !== 'object' || !component.vatFieldFunctionalityEnabled) {
            return true;
        }

        if(component.debug) {
            console.log('valid-vat-if-specified validation', component);
        }

        //Not specified
        if (typeof(component.value()) === 'string'
            && component.value().length <= 0
        ) {
            if(component.debug) {
                console.log('valid-vat-if-specified isNotSpecified', component);
            }
            return true;
        }

        //Not visible (by country)
        if (!component.visible()) {
            if(component.debug) {
                console.log('valid-vat-if-specified isNotVisible', component);
            }
            return true;
        }

        if(!EuVatTools.isValidateable(
            component.getCountry(), // address country
            component.euCountries,
            component.noValidateCountries)
        ) {
            if(component.debug) {
                console.log('valid-vat-if-specified isNotValidateable', component);
            }
            return true;
        }


        return component.isValidated() && component.isValidVatNumber() && (component.error().length <= 0);
    };

});


