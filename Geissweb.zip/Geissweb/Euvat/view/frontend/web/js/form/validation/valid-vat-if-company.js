define([
    'jquery',
    'mage/translate',
    'mageUtils',
    './valid-vat-required'
], function(
    $,
    $t,
    Utils,
    validVatRequiredValidation
) {
    'use strict';

    return function(value, component) {

        if(typeof component !== 'object' || !component.vatFieldFunctionalityEnabled) {
            return true;
        }

        if(component.debug) {
            console.log('valid-vat-if-company validation', component);
        }

        //Not visible (by country)
        if (!component.visible()) {
            if(component.debug) {
                console.log('valid-vat-if-company isNotVisible', component);
            }
            return true;
        }

        let company = component.getCompany();
        if(!Utils.isEmpty(company)) {
            return validVatRequiredValidation(value, component);
        }

        return true;
    };

});


