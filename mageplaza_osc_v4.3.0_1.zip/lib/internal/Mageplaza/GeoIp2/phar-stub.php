<?php

require_once 'phar://geoip2.phar/vendor/autoload.php';
