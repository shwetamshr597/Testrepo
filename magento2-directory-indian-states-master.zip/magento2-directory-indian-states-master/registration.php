<?php
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Credevlabz_DirectoryIndianStates',
    __DIR__
);
