<?php
/**
 * @category  Mageants PdfInvoice
 * @package   Mageants_PdfInvoice
 * @copyright Copyright (c) 2018 mageants
 * @author Mageants Team <info@mageants.com>
 */

namespace Mageants\PdfInvoice\ViewModel;

use Mageants\PdfInvoice\Helper\Data;
use Magento\GiftMessage\Helper\Message;
use Magento\Catalog\Api\ProductRepositoryInterface;
use \Magento\Catalog\Helper\Image;
use Magento\Shipping\Helper\Data as shippingHelper;

class PdfViewModel implements \Magento\Framework\View\Element\Block\ArgumentInterface
{
    /**
     * @var productRepository
     */
    protected $productRepository;

    /**
     * @var imageHelper
     */
    protected $imageHelper;

    /**
     * @var shippingHelper
     */
    protected $shippingHelper;

    /**
     * Constructor function
     *
     * @param Data $data
     * @param Message $giftMessage
     * @param Image $imageHelper
     * @param ProductRepositoryInterface $productRepository
     * @param shippingHelper $shippingHelper
     */
    public function __construct(
        Data $data,
        Message $giftMessage,
        Image $imageHelper,
        ProductRepositoryInterface $productRepository,
        shippingHelper $shippingHelper
    ) {
        $this->data = $data;
        $this->giftMessage = $giftMessage;
        $this->imageHelper = $imageHelper;
        $this->productRepository = $productRepository;
        $this->shippingHelper = $shippingHelper;
    }
    /**
     * Helper Config function
     *
     * @return array
     */
    public function getHelperConfigValues()
    {
        return $this->data->getConfigValues();
    }
    /**
     * Helper Extension Enabled function
     *
     * @return boolean
     */
    public function isExtentionEnable()
    {
        return $this->data->isExtentionEnable();
    }
    /**
     * Helper Default Printing function
     *
     * @return boolean
     */
    public function isDefaultPrintingDisable()
    {
        return $this->data->isDefaultPrintingDisable();
    }
    /**
     * Gift message Methods function
     *
     * @return mixed
     */
    public function getGiftData()
    {
        return $this->giftMessage;
    }
    /**
     * Get Image Url function
     *
     * @param int $productId
     * @return mixed
     */
    public function getItemImage($productId)
    {
        $product = $this->productRepository->getById($productId);
        $image_url = $this->imageHelper->init($product, 'product_thumbnail_image')
        ->setImageFile($product->getFile())->resize(500, 500)->getUrl();
        return $image_url;
    }
    /**
     * Shipping Helper Methods function
     *
     * @return mixed
     */
    public function shipHelperMethods()
    {
        return $this->shippingHelper;
    }
}
