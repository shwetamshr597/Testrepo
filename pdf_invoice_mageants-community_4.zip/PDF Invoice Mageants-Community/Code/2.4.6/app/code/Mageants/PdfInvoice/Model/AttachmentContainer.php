<?php
/**
 * @category  Mageants PdfInvoice
 * @package   Mageants_PdfInvoice
 * @copyright Copyright (c) 2019 mageants
 * @author Mageants Team <info@mageants.com>
 */

namespace Mageants\PdfInvoice\Model;

class AttachmentContainer implements Api\AttachmentContainerInterface
{
    /**
     * @var array
     */
    private $attachments = [];

    /**
     * Has Attachment
     *
     * @return bool
     */
    public function hasAttachments()
    {
        return !empty($this->attachments);
    }

    /**
     * Add Attachment function
     *
     * @param Api\AttachmentInterface $attachment
     * @return void
     */
    public function addAttachment(Api\AttachmentInterface $attachment)
    {
        $this->attachments[] = $attachment;
    }

    /**
     * Get Attachment
     *
     * @return array
     */
    public function getAttachments()
    {
        return $this->attachments;
    }

    /**
     * Reset Attachment
     *
     * @return array
     */
    public function resetAttachments()
    {
        $this->attachments = [];
    }
}
