<?php
/**
 * @category  Mageants PdfInvoice
 * @package   Mageants_PdfInvoice
 * @copyright Copyright (c) 2019 mageants
 * @author Mageants Team <info@mageants.com>
 */

namespace Mageants\PdfInvoice\Plugin;

class TransportFactory
{
    /**
     * @var $emailEventDispatcher
     */
    private $emailEventDispatcher;

    /**
     * @param \Mageants\PdfInvoice\Model\EmailEventDispatcher $emailEventDispatcher
     */
    public function __construct(
        \Mageants\PdfInvoice\Model\EmailEventDispatcher $emailEventDispatcher
    ) {
        $this->emailEventDispatcher = $emailEventDispatcher;
    }

    /**
     * @param \Magento\Framework\Mail\TransportInterfaceFactory $subject
     * @param \Closure $proceed,
     * @param  array $data
     * @return mixed
     */
    public function aroundCreate(
        \Magento\Framework\Mail\TransportInterfaceFactory $subject,
        \Closure $proceed,
        array $data = []
    ) {
        if (isset($data['message'])) {
            $this->emailEventDispatcher->dispatch($data['message']);
        }
        return $proceed($data);
    }

}
