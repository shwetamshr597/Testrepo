<?php
/**
 * @category  Mageants PdfInvoice
 * @package   Mageants_PdfInvoice
 * @copyright Copyright (c) 2019 mageants
 * @author Mageants Team <info@mageants.com>
 */

namespace Mageants\PdfInvoice\Model;

class NextEmailInfo
{
    /**
     * @var $templateVars
     */
    private $templateVars;

    /**
     * @var $templateIdentifier
     */
    private $templateIdentifier;

    /**
     * Set Template Var
     *
     * @param mixed $templateVars
     * @return void
     */
    public function setTemplateVars($templateVars)
    {
        $this->templateVars = $templateVars;
    }
    /**
     * Get Template Variable
     *
     * @return array
     */
    public function getTemplateVars()
    {
        return $this->templateVars;
    }

    /**
     * Get Template Identifier
     *
     * @param mixed $templateIdentifier
     * @return mixed
     */
    public function setTemplateIdentifier($templateIdentifier)
    {
        $this->templateIdentifier = $templateIdentifier;
    }

    /**
     * Get Template Identifier
     *
     * @return mixed
     */
    public function getTemplateIdentifier()
    {
        return $this->templateIdentifier;
    }
}
