<?php
/**
 * @category  Mageants PdfInvoice
 * @package   Mageants_PdfInvoice
 * @copyright Copyright (c) 2019 mageants
 * @author Mageants Team <info@mageants.com>
 */

namespace Mageants\PdfInvoice\Model;

use Zend\Mime\Message as MimeMessage;
use Zend\Mime\Mime;
use Zend\Mime\Part as MimePart;
use Zend\Mail\Message;
use Zend_Mime_Decode;
use Zend_Mime;

class MailProcessor implements Api\MailProcessorInterface
{
    /**
     * Create Multipart Message function
     *
     * @param \Magento\Framework\Mail\EmailMessage $message
     * @param Api\AttachmentContainerInterface $attachmentContainer
     * @return void
     */
    public function createMultipartMessage(
        \Magento\Framework\Mail\EmailMessage $message,
        Api\AttachmentContainerInterface $attachmentContainer
    ) {
        if ($attachmentContainer->hasAttachments()) {
            $body = new MimeMessage();
            $existingEmailBody = $message->getBody();

            foreach ($attachmentContainer->getAttachments() as $attachment) {
                $mimeAttachment = new MimePart($attachment->getContent());
                $mimeAttachment->filename = $this->getEncodedFileName($attachment);
                $mimeAttachment->type = $attachment->getMimeType();
                $mimeAttachment->encoding = $attachment->getEncoding();
                $mimeAttachment->disposition = $attachment->getDisposition();

                $this->parts[] = $mimeAttachment;
            }

            // set Body attachment
            $body = Message::fromString($message->getRawMessage())->getBody();
            
            $body = Zend_Mime_Decode::decodeQuotedPrintable($body);

            $part = new MimePart($body);
            $part->setCharset('utf-8');
            $part->setEncoding(Mime::ENCODING_BASE64);
            $part->setEncoding(Mime::ENCODING_QUOTEDPRINTABLE);
            $part->setDisposition(Mime::DISPOSITION_INLINE);
            
            $part->setType(Mime::TYPE_HTML);
            array_unshift($this->parts, $part);

            $bodyPart = new \Zend\Mime\Message();
            $bodyPart->setParts($this->parts);
            
            $message->setBody($bodyPart);
        }
    }

    /**
     * Ge File name
     *
     * @param mixed $attachment
     * @return mixed
     */
    public function getEncodedFileName($attachment)
    {
        return sprintf('=?utf-8?B?%s?=', base64_encode($attachment->getFilename()));
    }
}
