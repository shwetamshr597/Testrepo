<?php
/**
 * @category  Mageants PdfInvoice
 * @package   Mageants_PdfInvoice
 * @copyright Copyright (c) 2018 mageants
 * @author Mageants Team <info@mageants.com>
 */

namespace Mageants\PdfInvoice\Model\Variables;

abstract class AbstractMainVariablesItem extends AbstractMainVariables
{
    /**
     * Get prefix variable
     *
     * @return string
     */
    public function getPrefixVariable()
    {
        return \Mageants\PdfInvoice\Model\Variables\AbstractVariableOption::PREFIX_VAR_ITEMS;
    }
}
