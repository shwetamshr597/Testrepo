<?php
/**
 * @category  Mageants PdfInvoice
 * @package   Mageants_PdfInvoice
 * @copyright Copyright (c) 2019 mageants
 * @author Mageants Team <info@mageants.com>
 */


namespace Mageants\PdfInvoice\Model;

class EmailEventDispatcher
{
    /**
     * @var \Magento\Framework\Event\ManagerInterface
     */
    private $eventManager;

    /**
     * @var NextEmailInfo
     */
    private $nextEmailInfo;

    /**
     * @var Api\AttachmentContainerInterface
     */
    private $attachmentContainer;

    /**
     * @var EmailIdentifier
     */
    private $emailIdentifier;

    /**
     * @var MailProcessor
     */
    private $mailProcessor;

    /**
     * Constructor function
     *
     * @param \Magento\Framework\Event\ManagerInterface $eventManager
     * @param NextEmailInfo $nextEmailInfo
     * @param Api\AttachmentContainerInterface $attachmentContainer
     * @param EmailIdentifier $emailIdentifier
     * @param Api\MailProcessorInterface $mailProcessor
     */
    public function __construct(
        \Magento\Framework\Event\ManagerInterface $eventManager,
        NextEmailInfo $nextEmailInfo,
        Api\AttachmentContainerInterface $attachmentContainer,
        EmailIdentifier $emailIdentifier,
        Api\MailProcessorInterface $mailProcessor
    ) {
        $this->eventManager = $eventManager;
        $this->nextEmailInfo = $nextEmailInfo;
        $this->attachmentContainer = $attachmentContainer;
        $this->emailIdentifier = $emailIdentifier;
        $this->mailProcessor = $mailProcessor;
    }

    /**
     * Dispatch function
     *
     * @param \Magento\Framework\Mail\EmailMessage $message
     * @return void
     */
    public function dispatch(\Magento\Framework\Mail\EmailMessage $message)
    {
        if ($this->nextEmailInfo->getTemplateIdentifier()) {
            $this->determineEmailAndDispatch();
            $this->attachIfNeeded($message);
            $this->attachmentContainer->resetAttachments();
        }
    }

    /**
     * Determine Email and send function
     *
     * @return void
     */
    public function determineEmailAndDispatch()
    {
        $emailType = $this->emailIdentifier->getType($this->nextEmailInfo);
        if ($emailType->getType()) {
            $this->eventManager->dispatch(
                'mageants_pdfinvoice_before_send_' . $emailType->getType(),
                [

                    'attachment_container' => $this->attachmentContainer,
                    $emailType->getVarCode() => $this->nextEmailInfo->getTemplateVars()[$emailType->getVarCode()]
                ]
            );
        }
    }

    /**
     * Attachment function
     *
     * @param \Magento\Framework\Mail\EmailMessage $message
     * @return void
     */
    public function attachIfNeeded(\Magento\Framework\Mail\EmailMessage $message)
    {
        $this->mailProcessor->createMultipartMessage($message, $this->attachmentContainer);
    }

    /**
     * Get Encoded File Name function
     *
     * @param mixed $attachment
     * @return void
     */
    public function getEncodedFileName($attachment)
    {
        return $this->mailProcessor->getEncodedFileName($attachment);
    }
}
