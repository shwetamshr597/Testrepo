<?php

/**
 * @category  mageants Pdf Invoice
 * @package   Mageants_PdfInvoice
 * @copyright Copyright (c) 2018 mageants
 * @author Mageants Team <info@mageants.com>
 */

namespace Mageants\PdfInvoice\Model\Source;

class Orientation implements \Magento\Framework\Data\OptionSourceInterface
{
    /**
     *     Display as Popup
     */
    public const USE_HORIZONTAL = 1;

    /**
     *    Display bellow of "Add To Cart "
     */
    public const USE_VERTICLE = 0;

    /**
     * Get OptionArray
     *
     * @return array
     */
    public function getOptionArray()
    {
        $optionArray = ['' => ' '];
        foreach ($this->toOptionArray() as $option) {
            $optionArray[$option['value']] = $option['label'];
        }

        return $optionArray;
    }

    /**
     * Get OptionArray
     *
     * @return array
     */
    public function toOptionArray()
    {
        return [
            ['value' => self::USE_VERTICLE,  'label' => __('Vertical')],
            ['value' => self::USE_HORIZONTAL,  'label' => __('Horizontal')],
        ];
    }
}
