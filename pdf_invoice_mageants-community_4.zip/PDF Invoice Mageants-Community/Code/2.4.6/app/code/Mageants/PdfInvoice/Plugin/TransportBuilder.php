<?php
/**
 * @category  mageants Pdf Invoice
 * @package   Mageants_PdfInvoice
 * @copyright Copyright (c) 2019 mageants
 * @author Mageants Team <info@mageants.com>
 */
namespace Mageants\PdfInvoice\Plugin;

class TransportBuilder
{
    /**
     * @var $nextEMail
     */
    private $nextEmail;

    /**
     * @param \Mageants\PdfInvoice\Model\NextEmailInfo $nextEmailInfo
     */
    public function __construct(
        \Mageants\PdfInvoice\Model\NextEmailInfo $nextEmailInfo
    ) {
        $this->nextEmail = $nextEmailInfo;
    }
  
    /**
     * Before Set Template function
     *
     * @param \Magento\Framework\Mail\Template\TransportBuilder $subject
     * @param mixed $templateIdentifier
     * @return void
     */
    public function beforeSetTemplateIdentifier(
        \Magento\Framework\Mail\Template\TransportBuilder $subject,
        $templateIdentifier
    ): void {
        $this->nextEmail->setTemplateIdentifier($templateIdentifier);
    }

    /**
     * Before Set Template Var function
     *
     * @param \Magento\Framework\Mail\Template\TransportBuilder $subject
     * @param mixed $templateVars
     * @return void
     */
    public function beforeSetTemplateVars(
        \Magento\Framework\Mail\Template\TransportBuilder $subject,
        $templateVars
    ): void {
        $this->nextEmail->setTemplateVars($templateVars);
    }

    /**
     * Around function
     *
     * @param \Magento\Framework\Mail\Template\TransportBuilder $subject
     * @param \Closure $proceed
     * @return void
     */
    public function aroundGetTransport(
        \Magento\Framework\Mail\Template\TransportBuilder $subject,
        \Closure $proceed
    ) {
        $mailTransport = $proceed();
        $this->reset();
        return $mailTransport;
    }

    /**
     * Reset function
     *
     * @return void
     */
    private function reset(): void
    {
        $this->nextEmail->setTemplateIdentifier(null);
        $this->nextEmail->setTemplateVars(null);
    }
}
