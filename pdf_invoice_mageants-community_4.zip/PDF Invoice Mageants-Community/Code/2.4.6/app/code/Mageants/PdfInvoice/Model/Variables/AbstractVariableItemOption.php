<?php
/**
 * @category  Mageants PdfInvoice
 * @package   Mageants_PdfInvoice
 * @copyright Copyright (c) 2018 mageants
 * @author Mageants Team <info@mageants.com>
 */

namespace Mageants\PdfInvoice\Model\Variables;

abstract class AbstractVariableItemOption extends AbstractVariableOption
{
    /**
     * Get prefix variable
     *
     * @return string
     */
    public function getPrefixVariable()
    {
        return AbstractVariableOption::PREFIX_VAR_ITEMS;
    }

    /**
     * Get Option Array
     *
     * @return array
     */
    public function getAdditionalVar()
    {
        return [
            'small_image' => __('Product Image')
        ];
    }
}
