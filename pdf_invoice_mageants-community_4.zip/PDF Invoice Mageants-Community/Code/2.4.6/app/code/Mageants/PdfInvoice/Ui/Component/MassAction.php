<?php

/**
 * @category  Mageants PdfInvoice
 * @package   Mageants_PdfInvoice
 * @copyright Copyright (c) 2018 mageants
 * @author Mageants Team <info@mageants.com>
 */

namespace Mageants\PdfInvoice\Ui\Component;

use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Mageants\PdfInvoice\Helper\Data;

class MassAction extends \Magento\Ui\Component\MassAction
{
    /**
     *
     * @var array
     */
    protected $removeType = [
        'pdfinvoices_order',
        'pdfshipments_order', 'pdfcreditmemos_order',
        'pdfdocs_order'
    ];

    /**
     *
     * @var array
     */
    protected $removeMageantsType = [
        'pdfinvoices_orders', 'pdfinvoices_shipments',
        'pdfinvoices_creditmemo', 'pdfmageants_orders'
    ];

    /**
     * @var  \Magento\Framework\View\Element\UiComponent\ContextInterface
     */
    protected $context;

    /**
     *
     * @var helper
     */
    protected $helper;

    /**
     *
     * @var _data
     */
    protected $_data = [];

    /**
     * Constructor function
     *
     * @param ContextInterface $context
     * @param Data $helper
     * @param array $components
     * @param array $data
     */
    public function __construct(
        ContextInterface $context,
        Data $helper,
        array $components = [],
        array $data = []
    ) {
        parent::__construct($context, $components, $data);
        $this->context = $context;
        $this->components = $components;
        $this->helper = $helper;
        $this->_data = array_replace_recursive($this->_data, $data);
        $this->initObservers($this->_data);
    }

    /**
     * Prepare function
     *
     * @return void
     */
    public function prepare()
    {
        $config = $this->getConfiguration();

        foreach ($this->getChildComponents() as $actionComponent) {
            $config['actions'][] = $actionComponent->getConfiguration();
        };

        $origConfig = $this->getConfiguration();
        if ($origConfig !== $config) {
            $config = array_replace_recursive($config, $origConfig);
        }

        $newConfigActions = [];
        foreach ($config['actions'] as $configItem) {
            if (in_array($configItem['type'], $this->removeType)
                && $this->helper->isDefaultPrintingDisable() && $this->helper->isExtentionEnable()
            ) {
                continue;
            }
            if (in_array($configItem['type'], $this->removeMageantsType)
                && (bool)$this->helper->isExtentionEnable() === false
            ) {
                continue;
            }

            $newConfigActions[] = $configItem;
        }
        $config['actions'] = $newConfigActions;

        $this->setData('config', $config);
        $this->components = [];

        parent::prepare();
    }
}
