<?php

/**
 * @category  Mageants PdfInvoice
 * @package   Mageants_PdfInvoice
 * @copyright Copyright (c) 2019 mageants
 * @author Mageants Team <info@mageants.com>
 */

namespace Mageants\PdfInvoice\Observer;

class AbstractSendCreditmemoObserver extends AbstractObserver
{

    public const XML_PATH_ENABLE_PDF_INVOICE = 'mageants_pdfinvoice/general/enable';
    public const XML_PATH_ATTACH_PDF = 'mageants_pdfinvoice/general/send_pdf_attachment';

    /**
     * Main function
     *
     * @param \Magento\Framework\Event\Observer $observer
     * @return void
     */
    public function execute(\Magento\Framework\Event\Observer $observer): void
    {
        /**
         * @var $creditmemo \Magento\Sales\Api\Data\CreditmemoInterface
         */
        if ($this->scopeConfig->getValue(
            self::XML_PATH_ENABLE_PDF_INVOICE,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        ) && $this->scopeConfig->getValue(
            self::XML_PATH_ATTACH_PDF,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        )) {
            $creditmemo = $observer->getCreditmemo();

            $this->contentAttacher->addPdf(
                $this->pdfRenderer->getPdfAsString($creditmemo, 'setCreditMemo', 'memo'),
                $this->pdfRenderer->getFileName(__('Credit Memo') . $creditmemo->getIncrementId()),
                $observer->getAttachmentContainer()
            );
        }
    }
}
