<?php
/**
 * @category  mageants Pdf Invoice
 * @package   Mageants_PdfInvoice
 * @copyright Copyright (c) 2019 mageants
 * @author Mageants Team <info@mageants.com>
 */
namespace Mageants\PdfInvoice\Model;

use Magento\Framework\App\Filesystem\DirectoryList;

class PdfRenderer implements Api\PdfRendererInterface
{
    /**
     * @var pdfRenderer
     */
    protected $pdfRenderer;

    /**
     * @var directory_list
     */
    protected $directory_list;

    /**
     * @var pdfTemplate
     */
    protected $pdfTemplate;

    /**
     * Construct
     *
     * @param \Mageants\PdfInvoice\Helper\Pdf           $pdf
     * @param DirectoryList                             $directory_list
     * @param \Mageants\PdfInvoice\Model\Pdftemplate    $pdfTemplate
     * @param \Magento\Framework\Filesystem\Driver\File $driver
     * @param \Magento\Framework\App\RequestInterface   $request
     */
    public function __construct(
        \Mageants\PdfInvoice\Helper\Pdf $pdf,
        DirectoryList $directory_list,
        \Mageants\PdfInvoice\Model\Pdftemplate $pdfTemplate,
        \Magento\Framework\Filesystem\Driver\File $driver,
        \Magento\Framework\App\RequestInterface $request
    ) {
        $this->pdfhelper = $pdf;
        $this->directory_list =$directory_list;
        $this->pdfTemplate = $pdfTemplate;
        $this->driver = $driver;
        $this->request = $request;
    }

    /**
     * Get Pdf
     *
     * @param salesObject $salesObject
     * @param type $type
     * @param pdf $pdffor
     * @return string
     */
    public function getPdfAsString($salesObject, $type = null, $pdffor = null)
    {
        $template = $this->pdfTemplate->getCollection()->addFieldToFilter('status', 1)
        ->addFieldToFilter('store_id', ['in',[0, $salesObject->getStoreId()]])->getLastItem();
        
        if ($template->getData()) {
            if ($pdffor == 'invoice') {
                $this->request->setParam('invoice_id', $salesObject->getId());
            } elseif ($pdffor == 'shipment') {
                $this->request->setParam('shipment_id', $salesObject->getId());
            } elseif ($pdffor == 'memo') {
                $this->request->setParam('creditmemo_id', $salesObject->getId());
            }

            $this->pdfhelper->$type($salesObject);
            $this->pdfhelper->setTemplate($template);
            $pdfFileData = $this->pdfhelper->generateEmailPdfData($pdffor);
            $this->directory_list->getPath('var');
            $fileattached = $this->directory_list->getPath('var').'/'.$pdfFileData;
            $obj = $this->driver;
            $content = $obj->fileGetContents($fileattached);
           
            return $content;
        }
    }

    /**
     * GetFileName
     *
     * @param  string $input
     * @return file
     */
    public function getFileName($input = '')
    {
        return sprintf('%s.pdf', $input);
    }
    
    /**
     * Can Render
     *
     * @return boolean
     */
    public function canRender()
    {
        return true;
    }
}
