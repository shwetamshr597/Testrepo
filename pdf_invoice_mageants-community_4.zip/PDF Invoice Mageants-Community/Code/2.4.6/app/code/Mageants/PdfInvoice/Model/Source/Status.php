<?php
 /**
  * @category  mageants Pdf Invoice
  * @package   Mageants_PdfInvoice
  * @copyright Copyright (c) 2018 mageants
  * @author Mageants Team <info@mageants.com>
  */

namespace Mageants\PdfInvoice\Model\Source;

class Status implements \Magento\Framework\Data\OptionSourceInterface
{
    /**
     * Status values
     */
    public const STATUS_ENABLED = 1;
    public const STATUS_DISABLED = 0;

    /**
     * Get OptionArray
     *
     * @return array
     */
    public function getOptionArray()
    {
        $optionArray = ['' => ' '];
        
        foreach ($this->toOptionArray() as $option) {
            $optionArray[$option['value']] = $option['label'];
        }
        
        return $optionArray;
    }

    /**
     * Get OptionArray
     *
     * @return array
     */
    public function toOptionArray()
    {
        return [
            ['value' => self::STATUS_ENABLED,  'label' => __('Enabled')],
            ['value' => self::STATUS_DISABLED,  'label' => __('Disabled')],
        ];
    }
}
