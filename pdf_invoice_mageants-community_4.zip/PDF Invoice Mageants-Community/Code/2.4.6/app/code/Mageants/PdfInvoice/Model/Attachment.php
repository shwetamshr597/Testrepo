<?php
/**
 * @category  Mageants PdfInvoice
 * @package   Mageants_PdfInvoice
 * @copyright Copyright (c) 2019 mageants
 * @author Mageants Team <info@mageants.com>
 */

namespace Mageants\PdfInvoice\Model;

class Attachment implements Api\AttachmentInterface
{
    /**
     * @var content
     */
    private $content;

    /**
     * @var mimeType
     */
    private $mimeType;

    /**
     * @var filename
     */
    private $filename;

    /**
     * @var disposition
     */
    private $disposition;

    /**
     * @var encoding
     */
    private $encoding;

    /**
     * Constructor function
     *
     * @param mixed $content
     * @param mixed $mimeType
     * @param mixed $fileName
     * @param mixed $disposition
     * @param mixed $encoding
     */
    public function __construct(
        $content,
        $mimeType,
        $fileName,
        $disposition = Api\AttachmentInterface::DISPOSITION_ATTACHMENT,
        $encoding = Api\AttachmentInterface::ENCODING_BASE64
    ) {
        $this->content = $content;
        $this->mimeType = $mimeType;
        $this->filename = $fileName;
        $this->disposition = $disposition;
        $this->encoding = $encoding;
    }

    /**
     * Get Mime Type
     *
     * @return mixed
     */
    public function getMimeType()
    {
        return $this->mimeType;
    }

    /**
     * Get File Name
     *
     * @return mixed
     */
    public function getFilename()
    {
        return $this->filename;
    }

    /**
     * Get Disposition
     *
     * @return string
     */
    public function getDisposition()
    {
        return $this->disposition;
    }

    /**
     * Get Encoding
     *
     * @return string
     */
    public function getEncoding()
    {
        return $this->encoding;
    }

    /**
     * Get Content
     *
     * @return mixed
     */
    public function getContent()
    {
        return $this->content;
    }
}
