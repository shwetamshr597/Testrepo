<?php
/**
 * @category  Mageants PdfInvoice
 * @package   Mageants_PdfInvoice
 * @copyright Copyright (c) 2018 mageants
 * @author Mageants Team <info@mageants.com>
 */


namespace Mageants\PdfInvoice\Model\Variables;

abstract class AbstractMainVariables implements MainVariablesInterface
{
    /**
     * @var array
     */
    protected $_mainVariables = [];

    /**
     * @var _optionManager
     */
    protected $_optionManager;

    /**
     * AbstractMainVariables constructor.
     *
     * @param \Mageants\PdfInvoice\Model\OptionManager $optionManager
     */
    public function __construct(\Mageants\PdfInvoice\Model\OptionManager $optionManager)
    {
        $this->_optionManager = $optionManager;
    }

    /**
     * Get prefix variable
     *
     * @return string
     */
    abstract public function getPrefixVariable();

    /**
     * Get config variables option
     *
     * @return array
     */
    abstract public function getConfigVariables();

    /**
     * Mask variable function
     *
     * @param array $arrayMain
     * @param array $arrayData
     * @param string $labelMain
     * @param string $labelMore
     * @return array
     */
    protected function _maskVariables($arrayMain, $arrayData, $labelMain = 'main', $labelMore = 'more')
    {
        $more = [];
        $main = [];

        if (empty($arrayMain) && count($arrayMain) <= 0) {
            return [$labelMain => $arrayData, $labelMore => []];
        }

        foreach ($arrayData as $item) {
            if (in_array($item['value'], $arrayMain)) {
                $main[] = $item;
            } else {
                $more[] = $item;
            }
        }

        $data = [$labelMain => $main, $labelMore => $more];

        return $data;
    }

    /**
     * Get Main Variable
     *
     * @return array
     */
    public function getMainVariables()
    {
        $boundVariables = [];

        foreach ($this->_mainVariables as $mainVariable) {
            $boundVariables[] = "{{var {$this->getPrefixVariable()}_{$mainVariable}}}";
        }

        return $boundVariables;
    }

    /**
     * Get Variables
     *
     * @return array
     */
    public function getVariables()
    {
        return $this->_maskVariables($this->getMainVariables(), $this->getConfigVariables());
    }
}
