<?php

/**
 * @category  Mageants PdfInvoice
 * @package   Mageants_PdfInvoice
 * @copyright Copyright (c) 2019 mageants
 * @author Mageants Team <info@mageants.com>
 */

namespace Mageants\PdfInvoice\Model;

class EmailType
{
    /**
     * @var $type
     */
    private $type;

    /**
     * @var $varCode
     */
    private $varCode;

    /**
     * Constructor function
     *
     * @param mixed $type
     * @param mixed $varCode
     */
    public function __construct(
        $type,
        $varCode
    ) {
        $this->type = $type;
        $this->varCode = $varCode;
    }

    /**
     * Get Type
     *
     * @param $mixed
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * Get Varcode
     *
     * @param $mixed
     */
    public function getVarCode()
    {
        return $this->varCode;
    }
}
