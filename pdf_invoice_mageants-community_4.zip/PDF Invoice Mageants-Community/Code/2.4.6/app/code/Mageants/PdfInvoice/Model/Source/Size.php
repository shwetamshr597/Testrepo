<?php
 /**
  * @category  mageants Pdf Invoice
  * @package   Mageants_PdfInvoice
  * @copyright Copyright (c) 2018 mageants
  * @author Mageants Team <info@mageants.com>
  */

namespace Mageants\PdfInvoice\Model\Source;

class Size implements \Magento\Framework\Data\OptionSourceInterface
{

    /**
     * Get OptionArray
     *
     * @return array
     */
    public function toOptionArray()
    {
        $values = [];
        for ($i=0.8; $i<=2; $i=$i+0.1) {
            $values[] = ['label'=>$i, 'value'=>(string)$i ];
        }
        return $values;
    }
}
