<?php
namespace Mageants\PdfInvoice\Block;

use Mageants\PdfInvoice\Helper\Data;

class PdfInvoice extends \Magento\Framework\View\Element\Template
{
    /**
     * Constructor function
     *
     * @param Data $helper
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param array $data
     */
    public function __construct(
        Data $helper,
        \Magento\Framework\View\Element\Template\Context $context,
        array $data = []
    ) {
        $this->helper = $helper;
        parent::__construct($context, $data);
    }
    /**
     * Helper Config function
     *
     * @return array
     */
    public function getHelperConfigValues()
    {
        return $this->helper->getConfigValues();
    }
}
