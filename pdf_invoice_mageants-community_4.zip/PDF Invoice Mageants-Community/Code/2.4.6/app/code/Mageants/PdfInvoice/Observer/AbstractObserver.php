<?php

/**
 * @category  Mageants PdfInvoice
 * @package   Mageants_PdfInvoice
 * @copyright Copyright (c) 2019 mageants
 * @author Mageants Team <info@mageants.com>
 */


namespace Mageants\PdfInvoice\Observer;

use \Mageants\PdfInvoice\Model\Api\AttachmentContainerInterface as ContainerInterface;
use Mageants\PdfInvoice\Model\ContentAttacher;

abstract class AbstractObserver implements \Magento\Framework\Event\ObserverInterface
{
    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * @var \Mageants\PdfInvoice\Model\Api\PdfRendererInterface
     */
    protected $pdfRenderer;

    /**
     * @var ContentAttacher $contentAttacher
     */
    protected $contentAttacher;

    /**
     * @param  \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param  \Mageants\PdfInvoice\Model\Api\PdfRendererInterface $pdfRenderer
     * @param   ContentAttacher $contentAttacher
     */
    public function __construct(
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Mageants\PdfInvoice\Model\Api\PdfRendererInterface $pdfRenderer,
        ContentAttacher $contentAttacher
    ) {
        $this->scopeConfig = $scopeConfig;
        $this->pdfRenderer = $pdfRenderer;
        $this->contentAttacher = $contentAttacher;
    }

    /**
     * Attach Content function
     *
     * @param mixed $content
     * @param mixed $pdfFilename
     * @param mixed $mimeType
     * @param ContainerInterface $attachmentContainer
     * @return void
     */
    public function attachContent($content, $pdfFilename, $mimeType, ContainerInterface $attachmentContainer): void
    {
        $this->contentAttacher->addGeneric($content, $pdfFilename, $mimeType, $attachmentContainer);
    }

    /**
     * Attach PDF function
     *
     * @param mixed $pdfString
     * @param mixed $pdfFilename
     * @param ContainerInterface $attachmentContainer
     * @return void
     */
    public function attachPdf($pdfString, $pdfFilename, ContainerInterface $attachmentContainer): void
    {
        $this->contentAttacher->addPdf($pdfString, $pdfFilename, $attachmentContainer);
    }

    /**
     * Attach Text function
     *
     * @param mixed $text
     * @param mixed $filename
     * @param ContainerInterface $attachmentContainer
     * @return void
     */
    public function attachTxt($text, $filename, ContainerInterface $attachmentContainer): void
    {
        $this->contentAttacher->addText($text, $filename, $attachmentContainer);
    }

    /**
     * Attach html function
     *
     * @param mixed $html
     * @param string $filename
     * @param ContainerInterface $attachmentContainer
     * @return void
     */
    public function attachHtml($html, $filename, ContainerInterface $attachmentContainer): void
    {
        $this->contentAttacher->addHtml($html, $filename, $attachmentContainer);
    }

    /**
     * Term And Conidtion function
     *
     * @param int $storeId
     * @param ContainerInterface $attachmentContainer
     * @return void
     */
    public function attachTermsAndConditions($storeId, ContainerInterface $attachmentContainer): void
    {
        $this->termsAttacher->attachForStore($storeId, $attachmentContainer);
    }
}
