<?php

/**
 * @category Mageants Freegift
 * @package Mageants_Freegift
 * @copyright Copyright (c) 2018 Mageants
 * @author Mageants Team <support@mageants.com>
 */

namespace Mageants\PdfInvoice\Model;

class OptionManager extends AbstractObjectManager
{
    /**#@+
     * Allowed object types
     */
    public const OPTION_BARCODE_TYPE = 'barcode_type';
    /**
     *
     */
    public const OPTION_PAGE_SIZES = 'page_sizes';
    /**
     *
     */
    public const OPTION_SHOW_BARCODE = 'show_barcode';
    /**
     *
     */
    public const OPTION_STATUSES = 'statuses';
    /**
     *
     */
    public const OPTION_PAGE_ORIENTATION = 'page_orientation';
    /**
     *
     */
    public const OPTION_LANGUANGE = 'language';

    /**
     *
     */
    public const OPTION_VARIABLE_ORDER = 'variable_order';
    /**
     *
     */
    public const OPTION_VARIABLE_ORDER_ITEM = 'variable_order_item';
    /**
     *
     */
    public const OPTION_VARIABLE_INVOICE = 'variable_invoice';
    /**
     *
     */
    public const OPTION_VARIABLE_INVOICE_ITEM = 'variable_invoice_item';
    /**
     *
     */
    public const OPTION_VARIABLE_CREDITMEMO = 'variable_creditmemo';
    /**
     *
     */
    public const OPTION_VARIABLE_CREDITMEMO_ITEM = 'variable_creditmemo_item';
    /**
     *
     */
    public const OPTION_VARIABLE_SHIPMENT = 'variable_shipment';
    /**
     *
     */
    public const OPTION_VARIABLE_SHIPMENT_ITEM = 'variable_shipment_item';
    /**
     *
     */
    public const OPTION_VARIABLE_QUOTE = 'variable_quote';
    /**
     *
     */
    public const OPTION_VARIABLE_QUOTE_ITEM = 'variable_quote_item';
    /**
     *
     */
    public const OPTION_VARIABLE_CUSTOMER = 'variable_customer';

    /**
     *
     */
    public const OPTION_VARIABLE_BARCODEFILENAME_ORDER = 'variable_barcodefilename_order';
    /**
     *
     */
    public const OPTION_VARIABLE_BARCODEFILENAME_INVOICE = 'variable_barcodefilename_invoice';
    /**
     *
     */
    public const OPTION_VARIABLE_BARCODEFILENAME_CREDITMEMO = 'variable_barcodefilename_creditmemo';
    /**
     *
     */
    public const OPTION_VARIABLE_BARCODEFILENAME_SHIPMENT = 'variable_barcodefilename_shipment';
    /**
     *
     */
    public const OPTION_VARIABLE_BARCODEFILENAME_QUOTE = 'variable_barcodefilename_quote';

    /**
     *
     */
    public const OPTION_VARIABLE_CONFIG_ORDER = 'variable_config_order';
    /**
     *
     */
    public const OPTION_VARIABLE_CONFIG_ORDER_ITEM = 'variable_config_order_item';
    /**
     *
     */
    public const OPTION_VARIABLE_CONFIG_INVOICE = 'variable_config_invoice';
    /**
     *
     */
    public const OPTION_VARIABLE_CONFIG_INVOICE_ITEM = 'variable_config_invoice_item';
    /**
     *
     */
    public const OPTION_VARIABLE_CONFIG_CREDITMEMO = 'variable_config_creditmemo';
    /**
     *
     */
    public const OPTION_VARIABLE_CONFIG_CREDITMEMO_ITEM = 'variable_config_creditmemo_item';

    /**
     *
     */
    public const OPTION_VARIABLE_CONFIG_SHIPMENT = 'variable_config_shipment';

    /**
     *
     */
    public const OPTION_VARIABLE_CONFIG_SHIPMENT_ITEM = 'variable_config_shipment_item';
    /**
     *
     */
    public const OPTION_VARIABLE_CONFIG_QUOTE = 'variable_config_quote';

    /**
     *
     */
    public const OPTION_VARIABLE_CONFIG_QUOTE_ITEM = 'variable_config_quote_item';

    /**
     *
     */
    public const OPTION_VARIABLE_CONFIG_CUSTOMER = 'variable_config_customer';

    /**
     * Map of types which are references to classes.
     *
     * @var array
     */
    protected $_typeMap = [
        self::OPTION_BARCODE_TYPE =>
        \Mageants\PdfInvoice\Model\PdfTemplate\Option\BarcodeType::class,
        self::OPTION_PAGE_SIZES =>
        \Mageants\PdfInvoice\Model\PdfTemplate\Option\PageSizes::class,
        self::OPTION_SHOW_BARCODE =>
        \Mageants\PdfInvoice\Model\PdfTemplate\Option\ShowBarcode::class,
        self::OPTION_STATUSES =>
        \Mageants\PdfInvoice\Model\PdfTemplate\Option\Statuses::class,
        self::OPTION_PAGE_ORIENTATION =>
        \Mageants\PdfInvoice\Model\PdfTemplate\Option\PageOrientation::class,
        self::OPTION_LANGUANGE =>
        \Mageants\PdfInvoice\Model\PdfTemplate\Option\Language::class,
        self::OPTION_VARIABLE_ORDER =>
        \Mageants\PdfInvoice\Model\Variables\Option\Order::class,
        self::OPTION_VARIABLE_ORDER_ITEM =>
        \Mageants\PdfInvoice\Model\Variables\Option\OrderItem::class,
        self::OPTION_VARIABLE_INVOICE =>
        \Mageants\PdfInvoice\Model\Variables\Option\Invoice::class,
        self::OPTION_VARIABLE_INVOICE_ITEM =>
        \Mageants\PdfInvoice\Model\Variables\Option\InvoiceItem::class,
        self::OPTION_VARIABLE_CREDITMEMO =>
        \Mageants\PdfInvoice\Model\Variables\Option\Creditmemo::class,
        self::OPTION_VARIABLE_CREDITMEMO_ITEM =>
        \Mageants\PdfInvoice\Model\Variables\Option\CreditmemoItem::class,
        self::OPTION_VARIABLE_SHIPMENT =>
        \Mageants\PdfInvoice\Model\Variables\Option\Shipment::class,
        self::OPTION_VARIABLE_SHIPMENT_ITEM =>
        \Mageants\PdfInvoice\Model\Variables\Option\ShipmentItem::class,
        self::OPTION_VARIABLE_QUOTE =>
        \Mageants\PdfInvoice\Model\Variables\Option\Quote::class,
        self::OPTION_VARIABLE_QUOTE_ITEM =>
        \Mageants\PdfInvoice\Model\Variables\Option\QuoteItem::class,
        self::OPTION_VARIABLE_CUSTOMER =>
        \Mageants\PdfInvoice\Model\Variables\Option\Customer::class,
        self::OPTION_VARIABLE_BARCODEFILENAME_ORDER =>
        \Mageants\PdfInvoice\Model\Variables\Option\BarcodeFilename\Order::class,
        self::OPTION_VARIABLE_BARCODEFILENAME_INVOICE =>
        \Mageants\PdfInvoice\Model\Variables\Option\BarcodeFilename\Invoice::class,
        self::OPTION_VARIABLE_BARCODEFILENAME_CREDITMEMO =>
        \Mageants\PdfInvoice\Model\Variables\Option\BarcodeFilename\Creditmemo::class,
        self::OPTION_VARIABLE_BARCODEFILENAME_SHIPMENT =>
        \Mageants\PdfInvoice\Model\Variables\Option\BarcodeFilename\Shipment::class,
        self::OPTION_VARIABLE_BARCODEFILENAME_QUOTE =>
        \Mageants\PdfInvoice\Model\Variables\Option\BarcodeFilename\Quote::class,
        self::OPTION_VARIABLE_CONFIG_ORDER =>
        Mageants\PdfInvoice\Model\Variables\Option\Config\Order::class,
        self::OPTION_VARIABLE_CONFIG_ORDER_ITEM =>
        Mageants\PdfInvoice\Model\Variables\Option\Config\OrderItem::class,
        self::OPTION_VARIABLE_CONFIG_INVOICE =>
        Mageants\PdfInvoice\Model\Variables\Option\Config\Invoice::class,
        self::OPTION_VARIABLE_CONFIG_INVOICE_ITEM =>
        Mageants\PdfInvoice\Model\Variables\Option\Config\InvoiceItem::class,
        self::OPTION_VARIABLE_CONFIG_CREDITMEMO =>
        Mageants\PdfInvoice\Model\Variables\Option\Config\Creditmemo::class,
        self::OPTION_VARIABLE_CONFIG_CREDITMEMO_ITEM =>
        Mageants\PdfInvoice\Model\Variables\Option\Config\CreditmemoItem::class,
        self::OPTION_VARIABLE_CONFIG_SHIPMENT =>
        Mageants\PdfInvoice\Model\Variables\Option\Config\Shipment::class,
        self::OPTION_VARIABLE_CONFIG_SHIPMENT_ITEM =>
        Mageants\PdfInvoice\Model\Variables\Option\Config\ShipmentItem::class,
        self::OPTION_VARIABLE_CONFIG_QUOTE =>
        Mageants\PdfInvoice\Model\Variables\Option\Config\Quote::class,
        self::OPTION_VARIABLE_CONFIG_QUOTE_ITEM =>
        Mageants\PdfInvoice\Model\Variables\Option\Config\QuoteItem::class,
        self::OPTION_VARIABLE_CONFIG_CUSTOMER =>
        Mageants\PdfInvoice\Model\Variables\Option\Config\Customer::class
    ];

    /**
     * Get Type function
     *
     * @param mixed $type
     * @return void
     */
    public function get($type)
    {
        if (empty($this->_typeMap[$type])) {
            throw new \InvalidArgumentException('"' . $type . ': isn\'t allowed');
        }

        $instance = $this->_objectManager->get($this->_typeMap[$type]);
        if (!$instance instanceof \Magento\Framework\Option\ArrayInterface) {
            throw new \InvalidArgumentException(
                get_class($instance)
                    . ' isn\'t instance of \Magento\Framework\Option\ArrayInterface !'
            );
        }

        return $instance;
    }
}
