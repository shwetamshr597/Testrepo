<?php
 /**
  * @category  mageants Pdf Invoice
  * @package   Mageants_PdfInvoice
  * @copyright Copyright (c) 2018 mageants
  * @author Mageants Team <info@mageants.com>
  */

namespace Mageants\PdfInvoice\Model\Source;

class PaperSize implements \Magento\Framework\Data\OptionSourceInterface
{
    public const USE_A4 = 0;
    
    public const USE_A3 = 1;
    
    public const USE_A5 = 2;
    
    public const USE_A6 = 3;
    
    public const USE_LATTER = 4;
    
    public const USE_LEGAL = 5;

    /**
     * Get Option Array
     *
     * @return array
     */
    public function getOptionArray()
    {
        $optionArray = ['' => ' '];
        foreach ($this->toOptionArray() as $option) {
            $optionArray[$option['value']] = $option['label'];
        }
        
        return $optionArray;
    }

    /**
     * Get Option Array
     *
     * @return array
     */
    public function toOptionArray()
    {
        return [
            ['value' => self::USE_A4,  'label' => __('A4')],
            ['value' => self::USE_A3,  'label' => __('A3')],
            ['value' => self::USE_A5,  'label' => __('A5')],
            ['value' => self::USE_A6,  'label' => __('A6')],
            ['value' => self::USE_LATTER,  'label' => __('Latter')],
            ['value' => self::USE_LEGAL,  'label' => __('Legal')]
        ];
    }
}
