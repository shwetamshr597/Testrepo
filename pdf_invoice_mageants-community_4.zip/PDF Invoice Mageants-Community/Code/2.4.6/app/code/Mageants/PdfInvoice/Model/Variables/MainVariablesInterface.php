<?php
/**
 * @category  Mageants PdfInvoice
 * @package   Mageants_PdfInvoice
 * @copyright Copyright (c) 2018 mageants
 * @author Mageants Team <info@mageants.com>
 */

namespace Mageants\PdfInvoice\Model\Variables;

interface MainVariablesInterface
{
    /**
     * Get Variables
     *
     * @return array
     */
    public function getVariables();
}
