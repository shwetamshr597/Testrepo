<?php

/**
 * @category  Mageants PdfInvoice
 * @package   Mageants_PdfInvoice
 * @copyright Copyright (c) 2019 mageants
 * @author Mageants Team <info@mageants.com>
 */

namespace Mageants\PdfInvoice\Observer;

class AbstractSendShipmentObserver extends AbstractObserver
{
    public const XML_PATH_ENABLE_PDF_INVOICE = 'mageants_pdfinvoice/general/enable';
    public const XML_PATH_ATTACH_PDF = 'mageants_pdfinvoice/general/send_pdf_attachment';

    /**
     * Constructor function
     *
     * @param \Magento\Framework\Event\Observer $observer
     * @return void
     */
    public function execute(\Magento\Framework\Event\Observer $observer): void
    {
        if ($this->scopeConfig->getValue(
            self::XML_PATH_ENABLE_PDF_INVOICE,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        )
            && $this->scopeConfig->getValue(
                self::XML_PATH_ATTACH_PDF,
                \Magento\Store\Model\ScopeInterface::SCOPE_STORE
            )
        ) {
            $shipment = $observer->getShipment();
            $this->contentAttacher->addPdf(
                $this->pdfRenderer->getPdfAsString($shipment, 'setShipment', 'shipment'),
                $this->pdfRenderer->getFileName(__('Packing Slip') . $shipment->getIncrementId()),
                $observer->getAttachmentContainer()
            );
        }
    }
}
