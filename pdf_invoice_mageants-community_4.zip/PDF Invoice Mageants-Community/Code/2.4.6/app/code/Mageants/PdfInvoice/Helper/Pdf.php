<?php

/**
 * @category  Mageants PdfInvoice
 * @package   Mageants_PdfInvoice
 * @copyright Copyright (c) 2018 mageants
 * @author Mageants Team <info@mageants.com>
 */

namespace Mageants\PdfInvoice\Helper;

use Mageants\PdfInvoice\Model\Template\Processor;
use Magento\Payment\Helper\Data as PaymentHelper;
use Magento\Sales\Model\Order\Email\Container\InvoiceIdentity;
use Magento\Sales\Model\Order\Address\Renderer;
use Magento\Framework\App\Helper\Context;
use Magento\Framework\App\Helper\AbstractHelper;
use \Mageants\PdfInvoice\Model\Source\Orientation;
use \Mageants\PdfInvoice\Model\Pdftemplate;
use \Mageants\PdfInvoice\Helper\Data;
use Magento\Framework\App\Filesystem\DirectoryList;
use \Mageants\PdfInvoice\Model\OptionManager;
use Magento\Sales\Model\OrderFactory as OrderFactory;
use \Magento\Sales\Model\Order;
use Zend_Loader;

class Pdf extends AbstractHelper
{
    /**
     * @var \Magento\Framework\Filesystem\DirectoryList
     */
    public $dir;

    /**
     * @var \Magento\Framework\App\RequestInterface
     */
    public $request;

    /**
     * @var \Magento\Sales\Model\Order
     */
    public $orderTemplate;

    /**
     * @var OrderFactory
     */
    public $orderFactory;

    /**
     * @var \Magento\Sales\Api\Data\OrderInterface
     */
    public $orderInterface;

    /**
     * @var \Magento\Sales\Api\InvoiceRepositoryInterface
     */
    public $invoiceRepository;

    /**
     * @var \Magento\Sales\Model\Order\Creditmemo
     */
    public $modelCreditmemo;

    /**
     * @var \Magento\Sales\Model\Order\Shipment
     */
    public $modelShipment;

    /**
     * Paper orientation
     */
    public const PAPER_ORI = [
        0 => 'P',
        1 => 'L'
    ];

    /**
     * Paper size
     */
    public const PAPER_SIZE = [
        0 => 'A4',
        1 => 'A3',
        2 => 'A5',
        3 => 'A6',
        4 => 'LETTER',
        5 => 'LEGAL'
    ];

    /**
     * fonts
     */
    public const FONTS = 'mageants_pdfinvoice/setting/choose_fonts';

    /* orientation */

    public const ORIENTATION = 'mageants_pdfinvoice/setting/orientation';

    /* PAPER SIZE */

    public const PAPERSIZE = 'mageants_pdfinvoice/setting/paper_size';

    /* FONT SIZE */

    public const FONTSIZE = 'mageants_pdfinvoice/setting/font_size';

    /* TOP MARGIN */

    public const TOP_MARGIN = 'mageants_pdfinvoice/setting/top_margin';

    /* BOTTOM MARGIN */

    public const BOTTOM_MARGIN = 'mageants_pdfinvoice/setting/bottom_margin';

    /* LEFT MARGIN */

    public const LEFT_MARGIN = 'mageants_pdfinvoice/setting/left_margin';

    /* RIGHT MARGIN */

    public const RIGHT_MARGIN = 'mageants_pdfinvoice/setting/right_margin';

    /* SCRIPT DIRECTION [LTR || RTL]*/

    public const SCRIPT_DIR = 'mageants_pdfinvoice/setting/lang_direction';

    /* COMPANY NAME */

    public const COMPANY_NAME = 'mageants_pdfinvoice/business_info/company_name';

    /* COMPANY ADDRESS */

    public const COMPANY_ADDRESS = 'mageants_pdfinvoice/business_info/address';

    /* VAT MUMBER */

    public const VAT_NUMBER = 'mageants_pdfinvoice/business_info/vat_number';

    /* VAT OFFICE */

    public const VAT_OFFICE = 'mageants_pdfinvoice/business_info/var_office';

    /* BUSINESS ID */

    public const BUSINESS_ID = 'mageants_pdfinvoice/business_info/business_id';

    /* BUSINESS LOGO */
    public const BUSINESS_LOGO = 'mageants_pdfinvoice/business_info/company_logo';

    /* BUSINESS EMAIL */
    public const BUSINESS_EMAIL = 'mageants_pdfinvoice/business_contact/email';

    /* COMPANY PHONE */

    public const COMPANY_PHONE = 'mageants_pdfinvoice/business_contact/phone';

    /* COMPANY FAX */

    public const COMPANY_FAX = 'mageants_pdfinvoice/business_contact/Fax';

    /* BARCODE_HORIZONTAL */

    public const SHOW_BARCODE = 'mageants_pdfinvoice/barcode/show_barcode';

    /* SHOW_TEXT_BARCODE */

    public const SHOW_TEXT_BARCODE = 'mageants_pdfinvoice/barcode/show_text_barcode';

    /* SHOW_TEXT_BARCODE */

    public const SIZE_BARCODE = 'mageants_pdfinvoice/barcode/size_barcode';

    /* SHOW_TEXT_BARCODE */

    public const HEIGHT_BARCODE = 'mageants_pdfinvoice/barcode/height';

    /* SHOW_TEXT_BARCODE */

    public const TYPE_BARCODE = 'mageants_pdfinvoice/barcode/btype';

    /**
     * NOTES
     *
     */
    public const NOTES = 'mageants_pdfinvoice/business_info/notes';

    /**
     * TERMS_AND_CONDITIONS
     *
     */
    public const TERMS_AND_CONDITIONS = 'mageants_pdfinvoice/business_info/terms_and_condition';

    /**
     * @var \Magento\Sales\Model\Order
     */

    protected $order;

    /**
     * @var \Magento\Sales\Model\Order\Invoice
     */
    protected $invoice;

    /**
     * @var \Mageants\PdfInvoice\Model\Pdftemplate
     */
    protected $template;

    /**
     * @var \Magento\Sales\Model\Order\Email\Container\InvoiceIdentity
     */
    protected $identityContainer;

    /**
     * @var mPDF
     */
    public $_mPDF;

    /**
     * @var \Magento\Payment\Helper\Data
     */
    protected $paymentHelper;

    /**
     * @var \Magento\Sales\Model\Order\Address\Renderer
     */
    protected $addressRenderer;

    /**
     * @var \Mageants\PdfInvoice\Model\Template\Processor
     */
    protected $processor;

    /**
     * @var \Mageants\PdfInvoice\Helper\Data
     */
    protected $helper;

    /**
     * @var \Magento\Framework\Filesystem
     */
    protected $_filesystem;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $scopeConfig;

    /**
     * @var \Mageants\PdfInvoice\Model\OptionManager
     */
    protected $optionManager;

    /**
     * @var \Magento\Framework\Pricing\Helper\Data
     */
    protected $priceHelper;

    /**
     * @var \Mageants\PdfInvoice\Model\Config\FontList
     */
    protected $fontlist;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var \Magento\Framework\Stdlib\DateTime\DateTime
     */
    protected $datetime;

    /**
     * @var pdf library
     */
    protected $pdf;

    /**
     * @var pdf config
     */
    protected $config;

    /**
     * @var pdf ucdn
     */
    protected $ucdn;

    /**
     * @var default CSS
     */
    protected $defaultCss;

    /**
     * @var size Convertor
     */
    protected $sizeConvertor;

    /**
     * @var color
     */
    protected $color;

    /**
     * @var gradient
     */
    protected $gradient;

    /**
     * @var table of contents
     */
    protected $tableOfContents;

    /**
     * @var cache
     */
    protected $cache;

    /**
     * @var font cache
     */
    protected $fontCache;

    /**
     * @var fonts file finder
     */
    protected $fontsFileFinder;

    /**
     * @var css Manager
     */
    protected $cssManager;

    /**
     * @var otl
     */
    protected $otl;

    /**
     * @var form
     */
    protected $form;

    /**
     * @var hyphenator
     */
    protected $hyphenator;

    /**
     * @var tag
     */
    protected $tag;

    /**
     * @var namedcolors
     */
    protected $namedcolors;

    /**
     * @var pageformat
     */
    protected $pageformat;

    /**
     * @var font variables
     */
    protected $fontVariables;

    /**
     * @var text vars
     */
    protected $textvars;

    /**
     * @var border
     */
    protected $border;

    /**
     * @var log context
     */
    protected $logcontext;

    /**
     * @var tt font file
     */
    protected $ttfotfile;

    /**
     * @var destonation
     */
    protected $destination;

    /**
     * @var pdf exception
     */
    protected $pdfexception;

    /**
     * @var metrix generator
     */
    protected $metrixGenerator;

    /**
     * @var glyph operator
     */
    protected $GlyphOperator;

    /**
     * @var script to lang
     */
    protected $ScriptToLang;

    /**
     * @var lang to font
     */
    protected $LangToFont;

    /**
     * @var barcode
     */
    protected $barcode;
    
    /**
     * Pdf constructor
     *
     * @param Context $context
     * @param Renderer $addressRenderer
     * @param PaymentHelper $paymentHelper
     * @param InvoiceIdentity $identityContainer
     * @param Processor $templateFactory
     * @param Data $helper
     * @param \Magento\Framework\Filesystem $filesystem
     * @param \Magento\Framework\Pricing\Helper\Data $priceHelper
     * @param OptionManager $optionManager
     * @param \Mageants\PdfInvoice\Model\Config\FontList $fontlist
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Framework\Stdlib\DateTime\DateTime $datetime
     * @param \Magento\Sales\Model\Order\Shipment $modelShipment
     * @param \Magento\Sales\Model\Order\Creditmemo $modelCreditmemo
     * @param \Magento\Sales\Api\InvoiceRepositoryInterface $invoiceRepository
     * @param \Magento\Sales\Api\Data\OrderInterface $orderInterface
     * @param OrderFactory $orderFactory
     * @param \Magento\Sales\Model\Order $orderTemplate
     * @param \Magento\Framework\App\RequestInterface $request
     * @param \Magento\Framework\Filesystem\DirectoryList $dir
     */
    public function __construct(
        Context $context,
        Renderer $addressRenderer,
        PaymentHelper $paymentHelper,
        InvoiceIdentity $identityContainer,
        Processor $templateFactory,
        Data $helper,
        \Magento\Framework\Filesystem $filesystem,
        \Magento\Framework\Pricing\Helper\Data $priceHelper,
        OptionManager $optionManager,
        \Mageants\PdfInvoice\Model\Config\FontList $fontlist,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Stdlib\DateTime\DateTime $datetime,
        \Magento\Sales\Model\Order\Shipment $modelShipment,
        \Magento\Sales\Model\Order\Creditmemo $modelCreditmemo,
        \Magento\Sales\Api\InvoiceRepositoryInterface $invoiceRepository,
        \Magento\Sales\Api\Data\OrderInterface $orderInterface,
        OrderFactory $orderFactory,
        \Magento\Sales\Model\Order $orderTemplate,
        \Magento\Framework\App\RequestInterface $request,
        \Magento\Framework\Filesystem\DirectoryList $dir
    ) {
        $this->processor = $templateFactory;
        $this->paymentHelper = $paymentHelper;
        $this->identityContainer = $identityContainer;
        $this->addressRenderer = $addressRenderer;
        $this->helper = $helper;
        $this->_filesystem = $filesystem;
        $this->scopeConfig = $context->getScopeConfig();
        $this->optionManager = $optionManager;
        $this->priceHelper = $priceHelper;
        $this->fontlist = $fontlist->toOptionArray();
        $this->storeManager = $storeManager;
        $this->datetime = $datetime;
        $this->modelShipment = $modelShipment;
        $this->modelCreditmemo = $modelCreditmemo;
        $this->invoiceRepository = $invoiceRepository;
        $this->orderInterface = $orderInterface;
        $this->orderFactory = $orderFactory;
        $this->orderTemplate = $orderTemplate;
        $this->request = $request;
        $this->dir = $dir;
        $this->_construct();
        parent::__construct($context);
    }

    /**
     * Construct
     *
     * Initialization of MPDF LIBRARY
     */
    protected function _construct()
    {
        error_reporting(0);
        $vendorePath = $this->dir->getRoot() . "/vendor/mpdf/mpdf/src/";
        $this->pdf = $vendorePath . "Mpdf.php";
        $this->config = $vendorePath . "Config/ConfigVariables.php";
        $this->ucdn = $vendorePath . 'Ucdn.php';
        $this->defaultCss = $vendorePath . 'Css/DefaultCss.php';
        $this->sizeConvertor = $vendorePath . 'SizeConverter.php';
        $this->color = $vendorePath . 'Color/ColorConverter.php';
        $this->gradient = $vendorePath . 'Gradient.php';
        $this->tableOfContents = $vendorePath . 'TableOfContents.php';
        $this->cache = $vendorePath . 'Cache.php';
        $this->fontCache = $vendorePath . 'Fonts/FontCache.php';
        $this->fontsFileFinder = $vendorePath . 'Fonts/FontFileFinder.php';
        $this->cssManager = $vendorePath . 'CssManager.php';
        $this->otl = $vendorePath . 'Otl.php';
        $this->form = $vendorePath . 'Form.php';
        $this->hyphenator = $vendorePath . 'Hyphenator.php';
        $this->tag = $vendorePath . 'Tag.php';
        $this->namedcolors = $vendorePath . 'Color/NamedColors.php';
        $this->pageformat = $vendorePath . 'PageFormat.php';
        $this->fontVariables = $vendorePath . 'Config/FontVariables.php';
        $this->textvars = $vendorePath . 'Css/TextVars.php';
        $this->border = $vendorePath . 'Css/Border.php';
        $this->logcontext = $vendorePath . 'Log/Context.php';
        $this->ttfotfile = $vendorePath . 'TTFontFile.php';
        $this->destination = $vendorePath . 'Output/Destination.php';
        $this->pdfexception = $vendorePath . 'MpdfException.php';
        $this->metrixGenerator = $vendorePath . 'Fonts/MetricsGenerator.php';
        $this->GlyphOperator = $vendorePath . 'Fonts/GlyphOperator.php';
        $this->barcode = $vendorePath . 'Barcode.php';

        // require_once $this->pdf;
        Zend_Loader::loadFile($this->pdf, null, true);

        // require_once $this->config;
        Zend_Loader::loadFile($this->config, null, true);

        // require_once $this->ucdn;
        Zend_Loader::loadFile($this->ucdn, null, true);

        // require_once $this->defaultCss;
        Zend_Loader::loadFile($this->defaultCss, null, true);

        // require_once $this->sizeConvertor;
        Zend_Loader::loadFile($this->sizeConvertor, null, true);

        // require_once $this->color;
        Zend_Loader::loadFile($this->color, null, true);

        // require_once $this->gradient;
        Zend_Loader::loadFile($this->gradient, null, true);

        // require_once $this->tableOfContents;
        Zend_Loader::loadFile($this->tableOfContents, null, true);

        // require_once $this->cache;
        Zend_Loader::loadFile($this->cache, null, true);

        // require_once $this->fontCache;
        Zend_Loader::loadFile($this->fontCache, null, true);

        // require_once $this->fontsFileFinder;
        Zend_Loader::loadFile($this->fontsFileFinder, null, true);

        // require_once $this->cssManager;
        Zend_Loader::loadFile($this->cssManager, null, true);

        // require_once $this->otl;
        Zend_Loader::loadFile($this->otl, null, true);

        // require_once $this->form;
        Zend_Loader::loadFile($this->form, null, true);

        // require_once $this->hyphenator;
        Zend_Loader::loadFile($this->hyphenator, null, true);

        // require_once $this->tag;
        Zend_Loader::loadFile($this->tag, null, true);

        // require_once $this->namedcolors;
        Zend_Loader::loadFile($this->namedcolors, null, true);

        // require_once $this->pageformat;
        Zend_Loader::loadFile($this->pageformat, null, true);

        // require_once $this->fontVariables;
        Zend_Loader::loadFile($this->fontVariables, null, true);

        // require_once $this->textvars;
        Zend_Loader::loadFile($this->textvars, null, true);

        // require_once $this->border;
        Zend_Loader::loadFile($this->border, null, true);

        // require_once $this->logcontext;
        Zend_Loader::loadFile($this->logcontext, null, true);

        // require_once $this->ttfotfile;
        Zend_Loader::loadFile($this->ttfotfile, null, true);

        // require_once $this->destination;
        Zend_Loader::loadFile($this->destination, null, true);

        // require_once $this->pdfexception;
        Zend_Loader::loadFile($this->pdfexception, null, true);

        // require_once $this->metrixGenerator;
        Zend_Loader::loadFile($this->metrixGenerator, null, true);

        // require_once $this->GlyphOperator;
        Zend_Loader::loadFile($this->GlyphOperator, null, true);

        // require_once $this->barcode;
        Zend_Loader::loadFile($this->barcode, null, true);
    }
    /**
     * Set Invoice
     *
     * @param \Magento\Sales\Model\Order\Invoice $invoice
     * @return $this
     */
    public function setInvoice(\Magento\Sales\Model\Order\Invoice $invoice)
    {
        $this->invoice = $invoice;

        $this->setOrder($invoice->getOrder());

        return $this;
    }

    /**
     * Set shipment
     *
     * @param \Magento\Sales\Model\Order\Shipment $shipment
     * @return $this
     */
    public function setShipment(\Magento\Sales\Model\Order\Shipment $shipment)
    {
        $this->shipment = $shipment;

        $this->setOrder($shipment->getOrder());

        return $this;
    }

    /**
     * Set Creditmemo
     *
     * @param \Magento\Sales\Model\Order\Creditmemo $creditmemo
     * @return $this
     */
    public function setCreditMemo(\Magento\Sales\Model\Order\Creditmemo $creditmemo)
    {
        $this->memo = $creditmemo;
        $this->setOrder($creditmemo->getOrder());

        return $this;
    }

    /**
     * Set Ordertemplate
     *
     * @param \Magento\Sales\Model\Order $orderTemplate
     * @return $this
     */
    public function setOrderTemplate(\Magento\Sales\Model\Order $orderTemplate)
    {
        $this->orderTemplate = $orderTemplate;

        $this->setOrder($orderTemplate);

        return $this;
    }

    /**
     * Set Order
     *
     * @param \Magento\Sales\Model\Order $order
     * @return $this
     */
    public function setOrder(\Magento\Sales\Model\Order $order)
    {
        $this->order = $order;

        return $this;
    }

    /**
     * Set template
     *
     * @param \Mageants\PdfInvoice\Model\Pdftemplate $template
     * @return $this
     */
    public function setTemplate(Pdftemplate $template)
    {
        $this->template = $template;
        $template_data = $this->template->getData();
        $helper = $this->helper;
        $this->template->addData($template_data);
        $this->processor->setPDFTemplate($this->template);

        return $this;
    }

    /**
     * Generated Pdf
     *
     * Filename of the pdf and the stream to sent to the download
     *
     * @param array $type
     * @return array
     */
    public function generatePdfData($type = '')
    {
        /**transport use to get the variables $order object, $invoice object and the template model object*/

        $parts = $this->_transport($type);
        /** instantiate the mPDF class and add the processed html to get the pdf*/
        $applySettings = $this->getPDFSettings($parts);

        $fileParts = [
            'filestream' => $applySettings,
            'filename' => filter_var($parts['filename'], FILTER_SANITIZE_URL)
        ];

        return $fileParts;
    }

    /**
     * Generated Email
     *
     * Filename of the pdf and the stream to sent to the download
     *
     * @param array $type
     * @return array
     */
    public function generateEmailPdfData($type = '')
    {
        /**transport use to get the variables $order object, $invoice object and the template model object*/
        $parts = $this->_transport($type);
        /** instantiate the mPDF class and add the processed html to get the pdf*/
        $applySettings = $this->getEmailPDFSettings($parts, $type);
        $fileParts = [
            'filestream' => $applySettings,
            'filename' => filter_var($parts['filename'], FILTER_SANITIZE_URL)
        ];

        return $applySettings;
    }

    /**
     * Transport
     *
     * This will proces the template and the variables from the entity's
     *
     * @param array $type
     * @return array
     */
    protected function _transport($type = '')
    {
        if ($type == 'invoice') {
            $pdfElement = $this->invoice;
        }

        if ($type == 'shipment') {
            $pdfElement = $this->shipment;
        }
        if ($type == 'memo') {
            $pdfElement = $this->memo;
        }
        if ($type == 'order') {
            $pdfElement = $this->orderTemplate;
        }
        $order = $this->order;
        if ($this->request->getParam('order_id')) {
            $order_id = $this->request->getParam('order_id');
        } else {
            $invoiceVariablesValue = $this->optionManager->get(OptionManager::OPTION_VARIABLE_INVOICE)->toOptionArray();
            foreach ($invoiceVariablesValue as $invoiceVariable) {
                $str = substr($invoiceVariable['value'], 2, -2);
                $newstr = explode('_', $str);
                $parts = preg_split('/\s+/', $str);
                $var_to_set = array_splice($parts, 1);
                $varstr = array_splice($newstr, 1);
                $invoice_variable = implode('_', $varstr);
                if ($invoice_variable == 'order_id') {
                    $orderId = $pdfElement->getData($invoice_variable);
                }
            }
            if (isset($orderId) && $orderId != '') {
                $order_id = $orderId;
            } else {
                $order_id = 0;
            }
        }
        if ($order_id != 0) {
            if ($type == 'invoice') {
                $order = $this->orderFactory->create()->load($order_id);
                $history = [];
                $orderComment = [];
                foreach ($order->getInvoiceCollection() as $_invoice) {
                    foreach ($_invoice->getCommentsCollection() as $_comment) {
                        $history[] = $_comment->getComment();
                    }
                }
                $invoiceHistories = [];
                if (!empty($history)) {
                    $totalHistory = count($history);
                    for ($i = ($totalHistory - 1); $i >= 0; $i--) {
                        $invoiceHistories[] = $history[$i];
                    }
                }
            }
        }
        if (!empty($invoiceHistories)) {
            $comment  = implode(",", $invoiceHistories);
        } else {
            $comment  = ($pdfElement != null) ? ($pdfElement->getCustomerNoteNotify()
                ? $pdfElement->getCustomerNote() : '') : '';
        }

        if (!empty($this->shipment)) {
            $transport = [
                'order' => $order,
                'order_id' => $this->shipment->getData('order_id'),
                'comment' => str_replace(',', '<br />', $comment),
                'billing' => $order->getBillingAddress(),
                'payment_html' => $this->getPaymentHtml($order),
                'store' => $order->getStore(),
                'formattedShippingAddress' => $this->getFormattedShippingAddress($order),
                'formattedBillingAddress' => $this->getFormattedBillingAddress($order)
            ];
        } elseif (!empty($this->memo)) {
            $transport = [
                'order' => $order,
                'order_id' => $this->memo->getData('order_id'),
                'comment' => str_replace(',', '<br />', $comment),
                'billing' => $order->getBillingAddress(),
                'payment_html' => $this->getPaymentHtml($order),
                'store' => $order->getStore(),
                'formattedShippingAddress' => $this->getFormattedShippingAddress($order),
                'formattedBillingAddress' => $this->getFormattedBillingAddress($order)
            ];
        } elseif (!empty($this->invoice)) {
            $transport = [
                'order' => $order,
                'order_id' => $this->invoice->getOrder()->getEntityId(),
                'comment' => str_replace(',', '<br />', $comment),
                'billing' => $order->getBillingAddress(),
                'payment_html' => $this->getPaymentHtml($order),
                'store' => $order->getStore(),
                'formattedShippingAddress' => $this->getFormattedShippingAddress($order),
                'formattedBillingAddress' => $this->getFormattedBillingAddress($order)
            ];
        } else {
            $transport = [
                'order' => $order,
                'order_id' => $this->orderTemplate->getEntityId(),
                'comment' => str_replace(',', '<br />', $comment),
                'billing' => $order->getBillingAddress(),
                'payment_html' => $this->getPaymentHtml($order),
                'store' => $order->getStore(),
                'formattedShippingAddress' => $this->getFormattedShippingAddress($order),
                'formattedBillingAddress' => $this->getFormattedBillingAddress($order)
            ];
        }

        $invoiceVariables = $this->optionManager->get(OptionManager::OPTION_VARIABLE_INVOICE)->toOptionArray();
        $shipmentVariables = $this->optionManager->get(OptionManager::OPTION_VARIABLE_SHIPMENT)->toOptionArray();
        $memoVariables = $this->optionManager->get(OptionManager::OPTION_VARIABLE_CREDITMEMO)->toOptionArray();
        $orderVariables = $this->optionManager->get(OptionManager::OPTION_VARIABLE_ORDER)->toOptionArray();
        $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
        $transport[self::COMPANY_NAME] = $this->scopeConfig->getValue(self::COMPANY_NAME, $storeScope);
        $transport[self::COMPANY_ADDRESS] = $this->scopeConfig->getValue(self::COMPANY_ADDRESS, $storeScope);
        $transport[self::VAT_NUMBER] = $this->scopeConfig->getValue(self::VAT_NUMBER, $storeScope);
        $transport[self::VAT_OFFICE] = $this->scopeConfig->getValue(self::VAT_OFFICE, $storeScope);
        $transport[self::BUSINESS_LOGO] = $this->storeManager->getStore()
            ->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA)
            . 'mageants/pdfinvoice/logo/' . $this->scopeConfig->getValue(self::BUSINESS_LOGO, $storeScope);
        $transport[self::BUSINESS_EMAIL] = $this->scopeConfig->getValue(self::BUSINESS_EMAIL, $storeScope);
        $transport[self::COMPANY_PHONE] = $this->scopeConfig->getValue(self::COMPANY_PHONE, $storeScope);
        $transport[self::COMPANY_FAX] = $this->scopeConfig->getValue(self::COMPANY_FAX, $storeScope);
        $transport[self::NOTES] = $this->scopeConfig->getValue(self::NOTES, $storeScope);
        $transport[self::TERMS_AND_CONDITIONS] = $this->scopeConfig->getValue(self::TERMS_AND_CONDITIONS, $storeScope);
        foreach ($invoiceVariables as $invoiceVariable) {
            $str = substr($invoiceVariable['value'], 2, -2);
            $newstr = explode('_', $str);
            $parts = preg_split('/\s+/', $str);
            $var_to_set = array_splice($parts, 1);

            $varstr = array_splice($newstr, 1);
            $invoice_variable = implode('_', $varstr);

            if ($pdfElement->getData($invoice_variable)) {
                if (is_numeric($pdfElement->getData($invoice_variable))
                    && $invoice_variable != 'entity_id' && $invoice_variable != 'store_id'
                    && $invoice_variable != 'billing_address_id' && $invoice_variable != 'order_id'
                    && $invoice_variable != 'state' && $invoice_variable != 'shipping_address_id'
                    && $invoice_variable != 'increment_id' && $invoice_variable != 'increment_id'
                    && $invoice_variable != 'store_to_order_rate'
                ) {
                    $transport[implode("_", $var_to_set)] = $this->priceHelper
                        ->currency($pdfElement->getData($invoice_variable), true, false);
                } else {
                    $transport[implode("_", $var_to_set)] = $pdfElement->getData($invoice_variable);
                }
            }
        }
        foreach ($shipmentVariables as $shipmentVariable) {
            $str = substr($shipmentVariable['value'], 2, -2);
            $newstr = explode('_', $str);
            $parts = preg_split('/\s+/', $str);

            $var_to_set = array_splice($parts, 1);
            $varstr = array_splice($newstr, 1);
            $shipment_variable = implode('_', $varstr);

            if ($pdfElement->getData($shipment_variable)) {
                $transport[implode("_", $var_to_set)] = $pdfElement->getData($shipment_variable);
            }
        }
        foreach ($memoVariables as $memoVariable) {
            $str = substr($memoVariable['value'], 2, -2);
            $newstr = explode('_', $str);
            $parts = preg_split('/\s+/', $str);

            $var_to_set = array_splice($parts, 1);
            $varstr = array_splice($newstr, 1);
            $ordervar = implode('_', $varstr);

            if ($pdfElement->getData($ordervar)) {
                if (is_numeric($pdfElement->getData($ordervar)) && $ordervar != 'entity_id' && $ordervar != 'store_id'
                    && $ordervar != 'billing_address_id' && $ordervar != 'order_id' && $ordervar != 'state'
                    && $ordervar != 'shipping_address_id' && $memoVariable != 'increment_id'
                    && $ordervar != 'increment_id' && $ordervar != 'store_to_order_rate'
                ) {
                    $transport[implode("_", $var_to_set)] = $this->priceHelper
                        ->currency($pdfElement->getData($ordervar), true, false);
                } else {
                    $transport[implode("_", $var_to_set)] = $pdfElement->getData($ordervar);
                }
            }
        }

        foreach ($orderVariables as $orderVariable) {
            $str = substr($orderVariable['value'], 2, -2);
            $newstr = explode('_', $str);
            $parts = preg_split('/\s+/', $str);

            $var_to_set = array_splice($parts, 1);

            $varstr = array_splice($newstr, 1);
            $orderVariable = implode('_', $varstr);

            if ($pdfElement->getBillingAddress()) {
                $transport['order_billing_address'] =  $this->addressRenderer
                    ->format($pdfElement->getBillingAddress(), 'html');
            }
            if ($pdfElement->getShippingAddress()) {
                $transport['order_shipping_address'] =  $this->addressRenderer
                    ->format($pdfElement->getShippingAddress(), 'html');
            }
            if ($pdfElement->getData($orderVariable)) {
                if (is_numeric($pdfElement->getData($orderVariable)) && $orderVariable != 'entity_id'
                    && $orderVariable != 'store_id' && $orderVariable != 'customer_id'
                    && $orderVariable != 'store_to_order_rate' && $orderVariable != 'total_qty_ordered'
                    && $orderVariable != 'customer_note_notify' && $orderVariable != 'billing_address_id'
                    && $orderVariable != 'customer_group_id' && $orderVariable != 'send_email'
                    && $orderVariable != 'shipping_address_id' && $orderVariable != 'weight'
                    && $orderVariable != 'increment_id' && $orderVariable != 'total_item_count'
                    && $orderVariable != 'customer_gender'
                ) {
                    $transport[implode("_", $var_to_set)] = $this->priceHelper
                        ->currency($pdfElement->getData($orderVariable), true, false);
                } else {
                    $transport[implode("_", $var_to_set)] = $pdfElement->getData($orderVariable);
                }
            }
            if ($orderVariable == 'payment_method') {
                if ($pdfElement->getPayment()) {
                    $transport['order_payment_method'] = $pdfElement->getPayment()->getMethod();
                }
            }
        }
        $processor = $this->processor;

        $processor->setVariables($transport);

        $processor->setTemplate($this->template);

        $parts = $processor->processTemplate($type);

        return $parts;
    }

    /**
     * Get Pdf
     *
     * @param parts $parts
     * @return object
     */
    protected function getPDFSettings($parts)
    {
        $templateModel = $this->template;
        $increment_id = 0000001;
        $xpos = '';
        $ypos = '';

        if ($this->shipment) {
            $increment_id = $this->shipment->getData('increment_id');
            if ((int)$this->template->getData('shipment_horizontal_barcode') > 0) {
                $xpos = $this->template->getData('shipment_horizontal_barcode');
            }
            if ((int)$this->template->getData('shipment_vertical_barcode') > 0) {
                $ypos = $this->template->getData('shipment_vertical_barcode');
            }
        }

        if ($this->invoice) {
            $increment_id = $this->invoice->getData('increment_id');
            if ((int)$this->template->getData('invoice_horizontal_barcode') > 0) {
                $xpos = $this->template->getData('invoice_horizontal_barcode');
            }
            if ((int)$this->template->getData('invoice_vertical_barcode') > 0) {
                $ypos = $this->template->getData('invoice_vertical_barcode');
            }
        }

        if ($this->memo) {
            $increment_id = $this->memo->getData('increment_id');
            if ((int)$this->template->getData('memo_horizontal_barcode') > 0) {
                $xpos = $this->template->getData('memo_horizontal_barcode');
            }
            if ((int)$this->template->getData('memo_vertical_barcode') > 0) {
                $ypos = $this->template->getData('memo_vertical_barcode');
            }
        }

        if ($this->orderTemplate) {
            $increment_id = $this->orderTemplate->getData('increment_id');
            if ((int)$this->template->getData('order_horizontal_barcode') > 0) {
                $xpos = $this->template->getData('order_horizontal_barcode');
            }
            if ((int)$this->template->getData('order_horizontal_barcode') > 0) {
                $ypos = $this->template->getData('order_horizontal_barcode');
            }
        }
        $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
        $fontSize = $this->scopeConfig->getValue(self::FONTSIZE, $storeScope);
        if ($fontSize == '') {
            $fontSize = 10;
        }
        $config = [
            'mode' => '',
            'format' => self::PAPER_SIZE[$this->scopeConfig->getValue(self::PAPERSIZE, $storeScope)],
            'default_font_size' => $fontSize,
            'default_font' => $this->scopeConfig->getValue(self::FONTS, $storeScope),
            'margin_left' => $this->scopeConfig->getValue(self::LEFT_MARGIN, $storeScope),
            'margin_right' => $this->scopeConfig->getValue(self::RIGHT_MARGIN, $storeScope),
            'margin_top' => $this->scopeConfig->getValue(self::TOP_MARGIN, $storeScope),
            'margin_bottom' => $this->scopeConfig->getValue(self::BOTTOM_MARGIN, $storeScope),
            'allow_charset_conversion' => true,
            'orientation' => self::PAPER_ORI[$this->scopeConfig->getValue(self::ORIENTATION, $storeScope)],
            'showBarcodeNumbers' => false
        ];

        $pdf = new \Mpdf\Mpdf($config);

        $pdf->charset_in = 'UTF-8';
        $pdf->SetDirectionality($this->scopeConfig->getValue(self::SCRIPT_DIR, $storeScope));
        $fontdata = $this->scopeConfig->getValue(self::FONTS, $storeScope);
        $fonttoapply = [];
        foreach ($this->fontlist as $font_list) {
            if ($font_list['value'] == $fontdata) {
                $fonttoapply[$fontdata] = $font_list['label'];
                break;
            }
        }
        $pdf->autoScriptToLang = true;
        $pdf->autoLangToFont   = true;

        foreach ($fonttoapply as $f => $fs) {
            // add to fontdata array
            $pdf->fontdata[$fs] = $f;

            // add to available fonts array
            foreach (['R', 'B', 'I', 'BI'] as $style) {
                if (isset($fs[$style]) && $fs[$style]) {
                    // warning: no suffix for regular style! hours wasted: 2
                    $pdf->available_unifonts[] = $f . trim($style, 'R');
                }
            }
        }
        $pdf->SetHTMLHeader($parts['header']);
        $pdf->SetHTMLFooter($parts['footer']);
        $pdf->WriteHTML(htmlspecialchars_decode($parts["body"]));
        if ($this->scopeConfig->getValue(self::SHOW_BARCODE, $storeScope)) {
            $pdf->writeBarcode(
                $increment_id,
                $this->scopeConfig->getValue(self::SHOW_TEXT_BARCODE, $storeScope),
                $xpos,
                $ypos,
                $this->scopeConfig->getValue(self::SIZE_BARCODE, $storeScope),
                0,
                1,
                1,
                2,
                2,
                $this->scopeConfig->getValue(self::HEIGHT_BARCODE, $storeScope),
                false,
                false,
                $this->scopeConfig->getValue(self::TYPE_BARCODE, $storeScope),
                '0',
                '',
                1
            );
        }

        $pdfToOutput = $pdf->Output('', 'S');

        return $pdfToOutput;
    }

    /**
     * Get Emailpdf
     *
     * @param parts $parts
     * @param array $type
     * @return object
     */
    protected function getEmailPDFSettings($parts, $type = '')
    {
        $templateModel = $this->template;

        $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;

        $fontSize = $this->scopeConfig->getValue(self::FONTSIZE, $storeScope);
        if ($fontSize == '') {
            $fontSize = 10;
        }

        if ($this->shipment) {
            $increment_id = $this->shipment->getData('increment_id');
            if ((int)$this->template->getData('shipment_horizontal_barcode') > 0) {
                $xpos = $this->template->getData('shipment_horizontal_barcode');
            }
            if ((int)$this->template->getData('shipment_vertical_barcode') > 0) {
                $ypos = $this->template->getData('shipment_vertical_barcode');
            }
        }

        if ($this->invoice) {
            $increment_id = $this->invoice->getData('increment_id');
            if ((int)$this->template->getData('invoice_horizontal_barcode') > 0) {
                $xpos = $this->template->getData('invoice_horizontal_barcode');
            }
            if ((int)$this->template->getData('invoice_vertical_barcode') > 0) {
                $ypos = $this->template->getData('invoice_vertical_barcode');
            }
        }

        if ($this->memo) {
            $increment_id = $this->memo->getData('increment_id');
            if ((int)$this->template->getData('memo_horizontal_barcode') > 0) {
                $xpos = $this->template->getData('memo_horizontal_barcode');
            }
            if ((int)$this->template->getData('memo_vertical_barcode') > 0) {
                $ypos = $this->template->getData('memo_vertical_barcode');
            }
        }

        if ($this->orderTemplate) {
            $increment_id = $this->orderTemplate->getData('increment_id');
            if ((int)$this->template->getData('order_horizontal_barcode') > 0) {
                $xpos = $this->template->getData('order_horizontal_barcode');
            }
            if ((int)$this->template->getData('order_horizontal_barcode') > 0) {
                $ypos = $this->template->getData('order_horizontal_barcode');
            }
        }

        $config = [
            'mode' => '',
            'format' => self::PAPER_SIZE[$this->scopeConfig->getValue(self::PAPERSIZE, $storeScope)],
            'default_font_size' => $fontSize,
            'default_font' => $this->scopeConfig->getValue(self::FONTS, $storeScope),
            'margin_left' => $this->scopeConfig->getValue(self::LEFT_MARGIN, $storeScope),
            'margin_right' => $this->scopeConfig->getValue(self::RIGHT_MARGIN, $storeScope),
            'margin_top' => $this->scopeConfig->getValue(self::TOP_MARGIN, $storeScope),
            'margin_bottom' => $this->scopeConfig->getValue(self::BOTTOM_MARGIN, $storeScope),
            'allow_charset_conversion' => true,
            'orientation' => self::PAPER_ORI[$this->scopeConfig->getValue(self::ORIENTATION, $storeScope)]
        ];

        $pdf = new \Mpdf\Mpdf($config);
        $pdf->charset_in = 'UTF-8';
        $pdf->SetDirectionality($this->scopeConfig->getValue(self::SCRIPT_DIR, $storeScope));
        $fontdata = $this->scopeConfig->getValue(self::FONTS, $storeScope);
        $fonttoapply = [];
        foreach ($this->fontlist as $font_list) {
            if ($font_list['value'] == $fontdata) {
                $fonttoapply[$fontdata] = $font_list['label'];
                break;
            }
        }
        $pdf->autoScriptToLang = true;
        $pdf->autoLangToFont   = true;

        foreach ($fonttoapply as $f => $fs) {
            // add to fontdata array
            $pdf->fontdata[$fs] = $f;

            // add to available fonts array
            foreach (['R', 'B', 'I', 'BI'] as $style) {
                if (isset($fs[$style]) && $fs[$style]) {
                    // warning: no suffix for regular style! hours wasted: 2
                    $pdf->available_unifonts[] = $f . trim($style, 'R');
                }
            }
        }
        $pdf->SetHTMLHeader($parts['header']);
        $pdf->SetHTMLFooter($parts['footer']);
        $pdf->WriteHTML(htmlspecialchars_decode($parts["body"]));

        if ($this->scopeConfig->getValue(self::SHOW_BARCODE, $storeScope)) {
            $pdf->writeBarcode(
                $increment_id,
                $this->scopeConfig->getValue(self::SHOW_TEXT_BARCODE, $storeScope),
                $xpos,
                $ypos,
                $this->scopeConfig->getValue(self::SIZE_BARCODE, $storeScope),
                0,
                1,
                1,
                2,
                2,
                $this->scopeConfig->getValue(self::HEIGHT_BARCODE, $storeScope),
                false,
                false,
                $this->scopeConfig->getValue(self::TYPE_BARCODE, $storeScope),
                '0',
                '',
                1
            );
        }
        $pdfname = $type . $this->datetime->date('Y-m-d_H-i-s') . '.pdf';
        $pdfToOutput = $pdf->Output($this->dir->getPath('var') . '/' . $pdfname, 'F');
        return $pdfname;
    }

    /**
     * Paper Format
     *
     * Get the format and orientation, ex: A4-L
     *
     * @param array $form
     * @param array $ori
     * @return string
     */
    private function paperFormat($form, $ori)
    {
        $size = self::PAPER_SIZE;
        $oris = self::PAPER_ORI;

        if ($ori == Orientation::USE_VERTICLE) {
            return str_replace('-', '', $size[$form]);
        }

        $format = $size[$form] . $oris[$ori];

        return $format;
    }

    /**
     * Get payment
     *
     * @param \Magento\Sales\Model\Order $order
     * @return mixed
     */
    protected function getPaymentHtml(\Magento\Sales\Model\Order $order)
    {
        return $this->paymentHelper->getInfoBlockHtml(
            $order->getPayment(),
            $this->identityContainer->getStore()->getStoreId()
        );
    }

    /**
     * Get formattedshippingaddress
     *
     * @param \Magento\Sales\Model\Order $order
     * @return null
     */
    protected function getFormattedShippingAddress(\Magento\Sales\Model\Order $order)
    {
        return $order->getIsVirtual()
            ? null
            : $this->addressRenderer->format($order->getShippingAddress(), 'html');
    }

    /**
     * Get FormattedBillingaddress
     *
     * @param \Magento\Sales\Model\Order $order
     * @return mixed
     */
    protected function getFormattedBillingAddress(\Magento\Sales\Model\Order $order)
    {
        return $this->addressRenderer->format($order->getBillingAddress(), 'html');
    }

    /**
     * GenerateMassOrderPdf
     *
     * @param id $massOrderIds
     * @param data $orderTemplate
     * @return $pdfOrdersData
     */
    public function generateMassOrderPdf($massOrderIds, $orderTemplate)
    {
        $pdfOrdersData = [];

        $pdfOrdersData = $this->generatePdfDataMass($massOrderIds, $orderTemplate, 'order');

        return $pdfOrdersData;
    }

    /**
     * GenerateMassInvoicePdf
     *
     * @param id $massOrderIds
     * @param data $orderTemplate
     * @return $pdfOrdersData
     */
    public function generateMassInvoicePdf($massOrderIds, $orderTemplate)
    {
        $pdfOrdersData = [];

        $pdfOrdersData = $this->generatePdfDataMass($massOrderIds, $orderTemplate, 'invoice');

        return $pdfOrdersData;
    }

    /**
     * GenerateMassShipmentPdf
     *
     * @param id $massOrderIds
     * @param data $orderTemplate
     * @return $pdfOrdersData
     */
    public function generateMassShipmentPdf($massOrderIds, $orderTemplate)
    {
        $pdfOrdersData = [];

        $pdfOrdersData = $this->generatePdfDataMass($massOrderIds, $orderTemplate, 'shipment');

        return $pdfOrdersData;
    }

    /**
     * GenerateMassCreditMemoPdf
     *
     * @param id $massOrderIds
     * @param data $orderTemplate
     * @return $pdfOrdersData
     */
    public function generateMassCreditMemoPdf($massOrderIds, $orderTemplate)
    {
        $pdfOrdersData = [];

        $pdfOrdersData = $this->generatePdfDataMass($massOrderIds, $orderTemplate, 'memo');

        return $pdfOrdersData;
    }

    /**
     * GeneratePdfDataMass
     *
     * @param id $ordrIds
     * @param data $pdfTemplate
     * @param array $type
     * @return pdf
     */
    public function generatePdfDataMass($ordrIds, $pdfTemplate, $type = '')
    {
        /** instantiate the mPDF class and add the processed html to get the pdf*/
        if ($type == "invoice") {
            $applySettings = $this->getPDFSettingsMassInvoice($type, $ordrIds, $pdfTemplate);
        } elseif ($type == "shipment") {
            $applySettings = $this->getPDFSettingsMassShipment($type, $ordrIds, $pdfTemplate);
        } elseif ($type == "memo") {
            $applySettings = $this->getPDFSettingsMassCreditMemo($type, $ordrIds, $pdfTemplate);
        } else {
            $applySettings = $this->getPDFSettingsMass($type, $ordrIds, $pdfTemplate);
        }

        $fileParts = [
            'filestream' => $applySettings,
            'filename' => filter_var($parts['filename'], FILTER_SANITIZE_URL)
        ];

        return $fileParts;
    }

    /**
     * GetPDFSettingsMass
     *
     * @param array $type
     * @param id $massOrdrIds
     * @param data $orderTemplate
     * @return pdf
     */
    protected function getPDFSettingsMass($type, $massOrdrIds, $orderTemplate)
    {
        $maxMassOrdrIds = count($massOrdrIds);

        $maxMassOrdrIdKey = 1;

        foreach ($massOrdrIds as $massOrderIdSingle) {

            //fetch whole order information
            $orders = $this->orderInterface->load($massOrderIdSingle);

            $this->setOrderTemplate($orders);

            $this->setTemplate($orderTemplate);

            $parts = $this->_transport($type);

            $templateModel = $this->template;
            $xpos = '';
            $ypos = '';

            if ($this->orderTemplate) {
                $increment_id = $this->orderTemplate->getData('increment_id');
                if ((int)$this->template->getData('order_horizontal_barcode') > 0) {
                    $xpos = $this->template->getData('order_horizontal_barcode');
                }
                if ((int)$this->template->getData('order_horizontal_barcode') > 0) {
                    $ypos = $this->template->getData('order_horizontal_barcode');
                }
            }
            $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;

            $fontSize = $this->scopeConfig->getValue(self::FONTSIZE, $storeScope);
            if ($fontSize == '') {
                $fontSize = 10;
            }
            $config = [
                'mode' => '',
                'format' => self::PAPER_SIZE[$this->scopeConfig->getValue(self::PAPERSIZE, $storeScope)],
                'default_font_size' => $fontSize,
                'default_font' => $this->scopeConfig->getValue(self::FONTS, $storeScope),
                'margin_left' => $this->scopeConfig->getValue(self::LEFT_MARGIN, $storeScope),
                'margin_right' => $this->scopeConfig->getValue(self::RIGHT_MARGIN, $storeScope),
                'margin_top' => $this->scopeConfig->getValue(self::TOP_MARGIN, $storeScope),
                'margin_bottom' => $this->scopeConfig->getValue(self::BOTTOM_MARGIN, $storeScope),
                'allow_charset_conversion' => true,
                'orientation' => self::PAPER_ORI[$this->scopeConfig->getValue(self::ORIENTATION, $storeScope)],
                'showBarcodeNumbers' => false
            ];
            $orientation = self::PAPER_ORI[$this->scopeConfig->getValue(self::ORIENTATION, $storeScope)];
            // Create pdf for first time
            if ($maxMassOrdrIdKey == 1) {
                $pdf = new \Mpdf\Mpdf($config);
            }

            $pdf->charset_in = 'UTF-8';
            $pdf->SetDirectionality($this->scopeConfig->getValue(self::SCRIPT_DIR, $storeScope));
            $fontdata = $this->scopeConfig->getValue(self::FONTS, $storeScope);
            $fonttoapply = [];
            foreach ($this->fontlist as $font_list) {
                if ($font_list['value'] == $fontdata) {
                    $fonttoapply[$fontdata] = $font_list['label'];
                    break;
                }
            }
            $pdf->autoScriptToLang = true;
            $pdf->autoLangToFont   = true;
            foreach ($fonttoapply as $f => $fs) {
                // add to fontdata array
                $pdf->fontdata[$fs] = $f;

                // add to available fonts array
                foreach (['R', 'B', 'I', 'BI'] as $style) {
                    if (isset($fs[$style]) && $fs[$style]) {
                        // warning: no suffix for regular style! hours wasted: 2
                        $pdf->available_unifonts[] = $f . trim($style, 'R');
                    }
                }
            }

            // set header, footer and body for first time
            if ($maxMassOrdrIdKey == 1) {
                $pdf->SetHTMLHeader($parts['header']);
                $pdf->SetHTMLFooter($parts['footer']);
                $pdf->WriteHTML(htmlspecialchars_decode($parts["body"]));
            }
            if ($maxMassOrdrIdKey == 1) {
                if ($this->scopeConfig->getValue(self::SHOW_BARCODE, $storeScope)) {
                    $pdf->writeBarcode(
                        $increment_id,
                        $this->scopeConfig->getValue(self::SHOW_TEXT_BARCODE, $storeScope),
                        $xpos,
                        $ypos,
                        $this->scopeConfig->getValue(self::SIZE_BARCODE, $storeScope),
                        0,
                        1,
                        1,
                        2,
                        2,
                        $this->scopeConfig->getValue(self::HEIGHT_BARCODE, $storeScope),
                        false,
                        false,
                        $this->scopeConfig->getValue(self::TYPE_BARCODE, $storeScope),
                        '0',
                        '',
                        1
                    );
                }

                // write additional pages body to pdf
                if ($maxMassOrdrIdKey != 1) {
                    $pdf->WriteHTML(htmlspecialchars_decode($parts["body"]));
                }
            } else {
                // write additional pages body to pdf
                if ($maxMassOrdrIdKey != 1) {
                    $pdf->WriteHTML(htmlspecialchars_decode($parts["body"]));
                }

                if ($this->scopeConfig->getValue(self::SHOW_BARCODE, $storeScope)) {
                    $pdf->writeBarcode(
                        $increment_id,
                        $this->scopeConfig->getValue(self::SHOW_TEXT_BARCODE, $storeScope),
                        $xpos,
                        $ypos,
                        $this->scopeConfig->getValue(self::SIZE_BARCODE, $storeScope),
                        0,
                        1,
                        1,
                        2,
                        2,
                        $this->scopeConfig->getValue(self::HEIGHT_BARCODE, $storeScope),
                        false,
                        false,
                        $this->scopeConfig->getValue(self::TYPE_BARCODE, $storeScope),
                        '0',
                        '',
                        1
                    );
                }
            }

            // add blank page for next orders
            if ($maxMassOrdrIdKey < $maxMassOrdrIds) {
                $pdf->AddPage();
            }

            $maxMassOrdrIdKey++;
        }
        $pdfToOutput = $pdf->Output('', 'S');
        return $pdfToOutput;
    }

    /**
     * GetPDFSettingsMassInvoice
     *
     * @param array $type
     * @param id $massInvoiceIds
     * @param data $pdfTemplate
     * @return pdf
     */
    protected function getPDFSettingsMassInvoice($type, $massInvoiceIds, $pdfTemplate)
    {
        $maxMassInvoiceIds = count($massInvoiceIds);

        $maxMassInvoiceIdKey = 1;
        foreach ($massInvoiceIds as $massInvoiceIdSingle) {
            $Invoice = $this->invoiceRepository->get($massInvoiceIdSingle);
            $this->request->setParam('invoice_id', $massInvoiceIdSingle);

            $this->setInvoice($Invoice);

            $this->setTemplate($pdfTemplate);

            $parts = $this->_transport($type);

            $templateModel = $this->template;
            $xpos = '';
            $ypos = '';

            if ($this->invoice) {
                $increment_id = $this->invoice->getData('increment_id');
                if ((int)$this->template->getData('invoice_horizontal_barcode') > 0) {
                    $xpos = $this->template->getData('invoice_horizontal_barcode');
                }
                if ((int)$this->template->getData('invoice_vertical_barcode') > 0) {
                    $ypos = $this->template->getData('invoice_vertical_barcode');
                }
            }
            $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;

            $fontSize = $this->scopeConfig->getValue(self::FONTSIZE, $storeScope);
            if ($fontSize == '') {
                $fontSize = 10;
            }
            $config = [
                'mode' => '',
                'format' => self::PAPER_SIZE[$this->scopeConfig->getValue(self::PAPERSIZE, $storeScope)],
                'default_font_size' => $fontSize,
                'default_font' => $this->scopeConfig->getValue(self::FONTS, $storeScope),
                'margin_left' => $this->scopeConfig->getValue(self::LEFT_MARGIN, $storeScope),
                'margin_right' => $this->scopeConfig->getValue(self::RIGHT_MARGIN, $storeScope),
                'margin_top' => $this->scopeConfig->getValue(self::TOP_MARGIN, $storeScope),
                'margin_bottom' => $this->scopeConfig->getValue(self::BOTTOM_MARGIN, $storeScope),
                'allow_charset_conversion' => true,
                'orientation' => self::PAPER_ORI[$this->scopeConfig->getValue(self::ORIENTATION, $storeScope)],
                'showBarcodeNumbers' => false
            ];

            // Create pdf for first time
            if ($maxMassInvoiceIdKey == 1) {
                $pdf = new \Mpdf\Mpdf($config);
            }

            $pdf->charset_in = 'UTF-8';
            $pdf->SetDirectionality($this->scopeConfig->getValue(self::SCRIPT_DIR, $storeScope));
            $fontdata = $this->scopeConfig->getValue(self::FONTS, $storeScope);
            $fonttoapply = [];
            foreach ($this->fontlist as $font_list) {
                if ($font_list['value'] == $fontdata) {
                    $fonttoapply[$fontdata] = $font_list['label'];
                    break;
                }
            }
            $pdf->autoScriptToLang = true;
            $pdf->autoLangToFont   = true;

            foreach ($fonttoapply as $f => $fs) {
                // add to fontdata array
                $pdf->fontdata[$fs] = $f;

                // add to available fonts array
                foreach (['R', 'B', 'I', 'BI'] as $style) {
                    if (isset($fs[$style]) && $fs[$style]) {
                        // warning: no suffix for regular style! hours wasted: 2
                        $pdf->available_unifonts[] = $f . trim($style, 'R');
                    }
                }
            }

            // set header, footer and body for first time
            if ($maxMassInvoiceIdKey == 1) {
                $pdf->SetHTMLHeader($parts['header']);
                $pdf->SetHTMLFooter($parts['footer']);
                $pdf->WriteHTML(htmlspecialchars_decode($parts["body"]));
            }

            // Custom Add
            if ($maxMassInvoiceIdKey == 1) {
                if ($this->scopeConfig->getValue(self::SHOW_BARCODE, $storeScope)) {
                    $pdf->writeBarcode(
                        $increment_id,
                        $this->scopeConfig->getValue(self::SHOW_TEXT_BARCODE, $storeScope),
                        $xpos,
                        $ypos,
                        $this->scopeConfig->getValue(self::SIZE_BARCODE, $storeScope),
                        0,
                        1,
                        1,
                        2,
                        2,
                        $this->scopeConfig->getValue(self::HEIGHT_BARCODE, $storeScope),
                        false,
                        false,
                        $this->scopeConfig->getValue(self::TYPE_BARCODE, $storeScope),
                        '0',
                        '',
                        1
                    );
                }

                // write additional pages body to pdf
                if ($maxMassInvoiceIdKey != 1) {
                    $pdf->WriteHTML(htmlspecialchars_decode($parts["body"]));
                }
            } else {
                // write additional pages body to pdf
                if ($maxMassInvoiceIdKey != 1) {
                    $pdf->WriteHTML(htmlspecialchars_decode($parts["body"]));
                }

                if ($this->scopeConfig->getValue(self::SHOW_BARCODE, $storeScope)) {
                    $pdf->writeBarcode(
                        $increment_id,
                        $this->scopeConfig->getValue(self::SHOW_TEXT_BARCODE, $storeScope),
                        $xpos,
                        $ypos,
                        $this->scopeConfig->getValue(self::SIZE_BARCODE, $storeScope),
                        0,
                        1,
                        1,
                        2,
                        2,
                        $this->scopeConfig->getValue(self::HEIGHT_BARCODE, $storeScope),
                        false,
                        false,
                        $this->scopeConfig->getValue(self::TYPE_BARCODE, $storeScope),
                        '0',
                        '',
                        1
                    );
                }
            }

            // add blank page for next orders
            if ($maxMassInvoiceIdKey < $maxMassInvoiceIds) {
                $pdf->AddPage();
            }

            $maxMassInvoiceIdKey++;
        }
        $pdfToOutput = $pdf->Output('', 'S');
        return $pdfToOutput;
    }

    /**
     * GetPDFSettingsMassShipment
     *
     * @param array $type
     * @param id $massShipmentIds
     * @param data $pdfTemplate
     * @return pdf
     */
    protected function getPDFSettingsMassShipment($type, $massShipmentIds, $pdfTemplate)
    {
        $maxMassShipmentIds = count($massShipmentIds);
        $maxMassShipmentIdKey = 1;
        foreach ($massShipmentIds as $massShipmentIdSingle) {
            $shipment = $this->modelShipment->load($massShipmentIdSingle);
            $order_id = $shipment['order_id'];
            $sales_orders = $this->orderTemplate->load($order_id);
            $shipment['grand_total'] = $sales_orders->getGrandTotal();
            $this->request->setParam('shipment_id', $massShipmentIdSingle);

            $this->setShipment($shipment);
            $this->setTemplate($pdfTemplate);

            $parts = $this->_transport($type);

            $templateModel = $this->template;
            $xpos = '';
            $ypos = '';

            if ($this->shipment) {
                $increment_id = $this->shipment->getData('increment_id');
                if ((int)$this->template->getData('shipment_horizontal_barcode') > 0) {
                    $xpos = $this->template->getData('shipment_horizontal_barcode');
                }
                if ((int)$this->template->getData('shipment_vertical_barcode') > 0) {
                    $ypos = $this->template->getData('shipment_vertical_barcode');
                }
            }
            $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;

            $fontSize = $this->scopeConfig->getValue(self::FONTSIZE, $storeScope);
            if ($fontSize == '') {
                $fontSize = 10;
            }
            $config = [
                'mode' => '',
                'format' => self::PAPER_SIZE[$this->scopeConfig->getValue(self::PAPERSIZE, $storeScope)],
                'default_font_size' => $fontSize,
                'default_font' => $this->scopeConfig->getValue(self::FONTS, $storeScope),
                'margin_left' => $this->scopeConfig->getValue(self::LEFT_MARGIN, $storeScope),
                'margin_right' => $this->scopeConfig->getValue(self::RIGHT_MARGIN, $storeScope),
                'margin_top' => $this->scopeConfig->getValue(self::TOP_MARGIN, $storeScope),
                'margin_bottom' => $this->scopeConfig->getValue(self::BOTTOM_MARGIN, $storeScope),
                'allow_charset_conversion' => true,
                'orientation' => self::PAPER_ORI[$this->scopeConfig->getValue(self::ORIENTATION, $storeScope)],
                'showBarcodeNumbers' => false
            ];

            // Create pdf for first time
            if ($maxMassShipmentIdKey == 1) {
                $pdf = new \Mpdf\Mpdf($config);
            }

            $pdf->charset_in = 'UTF-8';
            $pdf->SetDirectionality($this->scopeConfig->getValue(self::SCRIPT_DIR, $storeScope));
            $fontdata = $this->scopeConfig->getValue(self::FONTS, $storeScope);
            $fonttoapply = [];
            foreach ($this->fontlist as $font_list) {
                if ($font_list['value'] == $fontdata) {
                    $fonttoapply[$fontdata] = $font_list['label'];
                    break;
                }
            }
            $pdf->autoScriptToLang = true;
            $pdf->autoLangToFont   = true;

            foreach ($fonttoapply as $f => $fs) {
                // add to fontdata array
                $pdf->fontdata[$fs] = $f;

                // add to available fonts array
                foreach (['R', 'B', 'I', 'BI'] as $style) {
                    if (isset($fs[$style]) && $fs[$style]) {
                        // warning: no suffix for regular style! hours wasted: 2
                        $pdf->available_unifonts[] = $f . trim($style, 'R');
                    }
                }
            }

            // set header, footer and body for first time
            if ($maxMassShipmentIdKey == 1) {
                $pdf->SetHTMLHeader($parts['header']);
                $pdf->SetHTMLFooter($parts['footer']);
                $pdf->WriteHTML(htmlspecialchars_decode($parts["body"]));
            }
            if ($maxMassShipmentIdKey == 1) {
                if ($this->scopeConfig->getValue(self::SHOW_BARCODE, $storeScope)) {
                    $pdf->writeBarcode(
                        $increment_id,
                        $this->scopeConfig->getValue(self::SHOW_TEXT_BARCODE, $storeScope),
                        $xpos,
                        $ypos,
                        $this->scopeConfig->getValue(self::SIZE_BARCODE, $storeScope),
                        0,
                        1,
                        1,
                        2,
                        2,
                        $this->scopeConfig->getValue(self::HEIGHT_BARCODE, $storeScope),
                        false,
                        false,
                        $this->scopeConfig->getValue(self::TYPE_BARCODE, $storeScope),
                        '0',
                        '',
                        1
                    );
                }

                // write additional pages body to pdf
                if ($maxMassShipmentIdKey != 1) {
                    $pdf->WriteHTML(htmlspecialchars_decode($parts["body"]));
                }
            } else {
                // write additional pages body to pdf
                if ($maxMassShipmentIdKey != 1) {
                    $pdf->WriteHTML(htmlspecialchars_decode($parts["body"]));
                }

                if ($this->scopeConfig->getValue(self::SHOW_BARCODE, $storeScope)) {
                    $pdf->writeBarcode(
                        $increment_id,
                        $this->scopeConfig->getValue(self::SHOW_TEXT_BARCODE, $storeScope),
                        $xpos,
                        $ypos,
                        $this->scopeConfig->getValue(self::SIZE_BARCODE, $storeScope),
                        0,
                        1,
                        1,
                        2,
                        2,
                        $this->scopeConfig->getValue(self::HEIGHT_BARCODE, $storeScope),
                        false,
                        false,
                        $this->scopeConfig->getValue(self::TYPE_BARCODE, $storeScope),
                        '0',
                        '',
                        1
                    );
                }
            }

            // add blank page for next orders
            if ($maxMassShipmentIdKey < $maxMassShipmentIds) {
                $pdf->AddPage();
            }

            $maxMassShipmentIdKey++;
        }
        $pdfToOutput = $pdf->Output('', 'S');
        return $pdfToOutput;
    }

    /**
     * GetPDFSettingsMassCreditMemo
     *
     * @param array $type
     * @param id $massCreditMemoIds
     * @param data $pdfTemplate
     * @return pdf
     */
    protected function getPDFSettingsMassCreditMemo($type, $massCreditMemoIds, $pdfTemplate)
    {
        $maxMassCreditMemoIds = count($massCreditMemoIds);

        $maxMassCreditMemoIdKey = 1;
        foreach ($massCreditMemoIds as $massCreditMemoIdSingle) {
            $creditMemo = $this->modelCreditmemo->load($massCreditMemoIdSingle);

            $this->request->setParam('creditmemo_id', $massCreditMemoIdSingle);

            $this->setCreditMemo($creditMemo);

            $this->setTemplate($pdfTemplate);

            $parts = $this->_transport($type);

            $templateModel = $this->template;
            $xpos = '';
            $ypos = '';

            if ($this->memo) {
                $increment_id = $this->memo->getData('increment_id');
                if ((int)$this->template->getData('memo_horizontal_barcode') > 0) {
                    $xpos = $this->template->getData('memo_horizontal_barcode');
                }
                if ((int)$this->template->getData('memo_vertical_barcode') > 0) {
                    $ypos = $this->template->getData('memo_vertical_barcode');
                }
            }

            $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;

            $fontSize = $this->scopeConfig->getValue(self::FONTSIZE, $storeScope);
            if ($fontSize == '') {
                $fontSize = 10;
            }
            $config = [
                'mode' => '',
                'format' => self::PAPER_SIZE[$this->scopeConfig->getValue(self::PAPERSIZE, $storeScope)],
                'default_font_size' => $fontSize,
                'default_font' => $this->scopeConfig->getValue(self::FONTS, $storeScope),
                'margin_left' => $this->scopeConfig->getValue(self::LEFT_MARGIN, $storeScope),
                'margin_right' => $this->scopeConfig->getValue(self::RIGHT_MARGIN, $storeScope),
                'margin_top' => $this->scopeConfig->getValue(self::TOP_MARGIN, $storeScope),
                'margin_bottom' => $this->scopeConfig->getValue(self::BOTTOM_MARGIN, $storeScope),
                'allow_charset_conversion' => true,
                'orientation' => self::PAPER_ORI[$this->scopeConfig->getValue(self::ORIENTATION, $storeScope)],
                'showBarcodeNumbers' => false
            ];

            // Create pdf for first time
            if ($maxMassCreditMemoIdKey == 1) {
                $pdf = new \Mpdf\Mpdf($config);
            }

            $pdf->charset_in = 'UTF-8';
            $pdf->SetDirectionality($this->scopeConfig->getValue(self::SCRIPT_DIR, $storeScope));
            $fontdata = $this->scopeConfig->getValue(self::FONTS, $storeScope);
            $fonttoapply = [];
            foreach ($this->fontlist as $font_list) {
                if ($font_list['value'] == $fontdata) {
                    $fonttoapply[$fontdata] = $font_list['label'];
                    break;
                }
            }
            $pdf->autoScriptToLang = true;
            $pdf->autoLangToFont   = true;

            foreach ($fonttoapply as $f => $fs) {
                // add to fontdata array
                $pdf->fontdata[$fs] = $f;

                // add to available fonts array
                foreach (['R', 'B', 'I', 'BI'] as $style) {
                    if (isset($fs[$style]) && $fs[$style]) {
                        // warning: no suffix for regular style! hours wasted: 2
                        $pdf->available_unifonts[] = $f . trim($style, 'R');
                    }
                }
            }

            // set header, footer and body for first time
            if ($maxMassCreditMemoIdKey == 1) {
                $pdf->SetHTMLHeader($parts['header']);
                $pdf->SetHTMLFooter($parts['footer']);
                $pdf->WriteHTML(htmlspecialchars_decode($parts["body"]));
            }
            if ($maxMassCreditMemoIdKey == 1) {
                if ($this->scopeConfig->getValue(self::SHOW_BARCODE, $storeScope)) {
                    $pdf->writeBarcode(
                        $increment_id,
                        $this->scopeConfig->getValue(self::SHOW_TEXT_BARCODE, $storeScope),
                        $xpos,
                        $ypos,
                        $this->scopeConfig->getValue(self::SIZE_BARCODE, $storeScope),
                        0,
                        1,
                        1,
                        2,
                        2,
                        $this->scopeConfig->getValue(self::HEIGHT_BARCODE, $storeScope),
                        false,
                        false,
                        $this->scopeConfig->getValue(self::TYPE_BARCODE, $storeScope),
                        '0',
                        '',
                        1
                    );
                }

                // write additional pages body to pdf
                if ($maxMassCreditMemoIdKey != 1) {
                    $pdf->WriteHTML(htmlspecialchars_decode($parts["body"]));
                }
            } else {
                // write additional pages body to pdf
                if ($maxMassCreditMemoIdKey != 1) {
                    $pdf->WriteHTML(htmlspecialchars_decode($parts["body"]));
                }

                if ($this->scopeConfig->getValue(self::SHOW_BARCODE, $storeScope)) {
                    $pdf->writeBarcode(
                        $increment_id,
                        $this->scopeConfig->getValue(self::SHOW_TEXT_BARCODE, $storeScope),
                        $xpos,
                        $ypos,
                        $this->scopeConfig->getValue(self::SIZE_BARCODE, $storeScope),
                        0,
                        1,
                        1,
                        2,
                        2,
                        $this->scopeConfig->getValue(self::HEIGHT_BARCODE, $storeScope),
                        false,
                        false,
                        $this->scopeConfig->getValue(self::TYPE_BARCODE, $storeScope),
                        '0',
                        '',
                        1
                    );
                }
            }

            // add blank page for next orders
            if ($maxMassCreditMemoIdKey < $maxMassCreditMemoIds) {
                $pdf->AddPage();
            }

            $maxMassCreditMemoIdKey++;
        }
        $pdfToOutput = $pdf->Output('', 'S');
        return $pdfToOutput;
    }
}
