<?php
/**
 * @category  Mageants PdfInvoice
 * @package   Mageants_PdfInvoice
 * @copyright Copyright (c) 2019 mageants
 * @author Mageants Team <info@mageants.com>
 */


namespace Mageants\PdfInvoice\Model;

class EmailIdentifier
{
    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    private $scopeConfig;

    /**
     * @var EmailTypeFactory
     */
    private $emailTypeFactory;

    /**
     * Constructor function
     *
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param EmailTypeFactory $emailTypeFactory
     */
    public function __construct(
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        EmailTypeFactory $emailTypeFactory
    ) {
        $this->scopeConfig = $scopeConfig;
        $this->emailTypeFactory = $emailTypeFactory;
    }

    /**
     * Get Type function
     *
     * @param NextEmailInfo $nextEmailInfo
     * @return object
     */
    public function getType(NextEmailInfo $nextEmailInfo)
    {
        $type = false;
        $templateVars = $nextEmailInfo->getTemplateVars();

        $varCode = $this->getMainEmailType($templateVars);

        if ($varCode) {
            $method = 'get' . ucfirst($varCode) . 'Email';
            
            $type = $this->$method(
                $nextEmailInfo->getTemplateIdentifier(),
                $templateVars[$varCode]->getStoreId()
            );
        }

        return $this->emailTypeFactory->create(['type' => $type, 'varCode' => $varCode]);
    }

    /**
     * Get Main Email function
     *
     * @param array $templateVars
     * @return string
     */
    private function getMainEmailType($templateVars)
    {

        if (isset($templateVars['shipment']) && method_exists($templateVars['shipment'], 'getStoreId')) {
            return 'shipment';
        }

        if (isset($templateVars['invoice']) && method_exists($templateVars['invoice'], 'getStoreId')) {
            return 'invoice';
        }

        if (isset($templateVars['creditmemo']) && method_exists($templateVars['creditmemo'], 'getStoreId')) {
            return 'creditmemo';
        }
        
        if (isset($templateVars['order']) && method_exists($templateVars['order'], 'getStoreId')) {
            return 'order';
        }
        return false;
    }

    /**
     * Get Shipment Email function
     *
     * @param mixed $templateIdentifier
     * @param int $storeId
     * @return string
     */
    private function getShipmentEmail($templateIdentifier, $storeId)
    {
        if ($this->scopeConfig->getValue(
            \Magento\Sales\Model\Order\Email\Container\ShipmentCommentIdentity::XML_PATH_EMAIL_GUEST_TEMPLATE,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE,
            $storeId
        ) === $templateIdentifier ||
            $this->scopeConfig->getValue(
                \Magento\Sales\Model\Order\Email\Container\ShipmentCommentIdentity::XML_PATH_EMAIL_TEMPLATE,
                \Magento\Store\Model\ScopeInterface::SCOPE_STORE,
                $storeId
            ) === $templateIdentifier
        ) {
            return 'shipment_comment';
        }

        return 'shipment';
    }

    /**
     * Get Invoice Email function
     *
     * @param mixed $templateIdentifier
     * @param int $storeId
     * @return string
     */
    private function getInvoiceEmail($templateIdentifier, $storeId)
    {
        if ($this->scopeConfig->getValue(
            \Magento\Sales\Model\Order\Email\Container\InvoiceCommentIdentity::XML_PATH_EMAIL_GUEST_TEMPLATE,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE,
            $storeId
        ) === $templateIdentifier ||
            $this->scopeConfig->getValue(
                \Magento\Sales\Model\Order\Email\Container\InvoiceCommentIdentity::XML_PATH_EMAIL_TEMPLATE,
                \Magento\Store\Model\ScopeInterface::SCOPE_STORE,
                $storeId
            ) === $templateIdentifier
        ) {
            return 'invoice_comment';
        }

        return 'invoice';
    }

    /**
     * Get Order Email function
     *
     * @param mixed $templateIdentifier
     * @param int $storeId
     * @return string
     */
    private function getOrderEmail($templateIdentifier, $storeId)
    {
        if ($this->scopeConfig->getValue(
            \Magento\Sales\Model\Order\Email\Container\OrderCommentIdentity::XML_PATH_EMAIL_GUEST_TEMPLATE,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE,
            $storeId
        ) === $templateIdentifier ||
            $this->scopeConfig->getValue(
                \Magento\Sales\Model\Order\Email\Container\OrderCommentIdentity::XML_PATH_EMAIL_TEMPLATE,
                \Magento\Store\Model\ScopeInterface::SCOPE_STORE,
                $storeId
            ) === $templateIdentifier
        ) {
            return 'order_comment';
        }

        return 'order';
    }

    /**
     * Get CreditMemo Email function
     *
     * @param mixed $templateIdentifier
     * @param int $storeId
     * @return string
     */
    private function getCreditmemoEmail($templateIdentifier, $storeId)
    {
        if ($this->scopeConfig->getValue(
            \Magento\Sales\Model\Order\Email\Container\CreditmemoCommentIdentity::XML_PATH_EMAIL_GUEST_TEMPLATE,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE,
            $storeId
        ) === $templateIdentifier ||
            $this->scopeConfig->getValue(
                \Magento\Sales\Model\Order\Email\Container\CreditmemoCommentIdentity::XML_PATH_EMAIL_TEMPLATE,
                \Magento\Store\Model\ScopeInterface::SCOPE_STORE,
                $storeId
            ) === $templateIdentifier
        ) {
            return 'creditmemo_comment';
        }

        return 'creditmemo';
    }
}
