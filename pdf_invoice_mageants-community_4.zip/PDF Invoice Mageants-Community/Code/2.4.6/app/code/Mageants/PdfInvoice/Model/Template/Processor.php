<?php
/**
 * @category  Mageants PdfInvoice
 * @package   Mageants_PdfInvoice
 * @copyright Copyright (c) 2018 mageants
 * @author Mageants Team <info@mageants.com>
 */

namespace Mageants\PdfInvoice\Model\Template;

use Magento\Email\Model\Template;
use Magento\Framework\DataObject;

class Processor extends Template
{

    /**
     * @var store id;
     */
    private $storeId;

    /**
     * Configuration of design package for template
     *
     * @var DataObject
     */
    private $designConfig;

    /**
     * Get Template Body function
     *
     * @param string $type
     * @return void
     */
    public function getTemplateBody($type = '')
    {
        if ($type=='invoice') {
            return $this->getPDFTemplate()->getInvoiceTemplateData();
        }
        if ($type=='shipment') {
            return $this->getPDFTemplate()->getShipmentTemplateData();
        }
        if ($type=='memo') {
            return $this->getPDFTemplate()->getCreditmemoTemplateData();
        }
        if ($type=='order') {
            return $this->getPDFTemplate()->getInvoiceOrderData();
        }
    }

    /**
     * Get Template Header
     *
     * @return mixed
     */
    public function getTemplateHeader()
    {
        
        return $this->getPDFTemplate()->getHeader();
    }

    /**
     * Get Template Footer
     *
     * @return mixed
     */
    public function getTemplateFooter()
    {
        return $this->getPDFTemplate()->getFooter();
    }

    /**
     * Get Template File Name
     *
     * @return mixed
     */
    public function getTemplateFileName()
    {
        return $this->getPDFTemplate()->getFilename();
    }

    /**
     * Get Process Template function
     *
     * @param string $type
     * @return void
     */
    public function processTemplate($type = '')
    {
        // Support theme fallback for email templates
        $isDesignApplied = $this->applyDesignConfig();

        $processor = $this->getTemplateFilter()
            ->setUseSessionInUrl(false)
            ->setPlainTemplateMode($this->isPlain())
            ->setIsChildTemplate($this->isChildTemplate())
            ->setTemplateProcessor([$this, 'getTemplateContent']);

        $processor->setVariables($this->getVariables());
        
        $this->setUseAbsoluteLinks(true);
        
        $html = $this->html($processor, $type);

        if ($isDesignApplied) {
            $this->cancelDesignConfig();
        }
        return $html;
    }

    /**
     * Process Area function
     *
     * @param mixed $processor
     * @param mixed $area
     * @return void
     */
    private function processArea($processor, $area)
    {
        $textProcessor = $processor
            ->setStoreId($this->storeId)
            ->setDesignParams([0])
            ->filter((string)($area));

        return $textProcessor;
    }

    /**
     * Get Html function
     *
     * @param mixed $processor
     * @param string $type
     * @return array
     */
    private function html($processor, $type = '')
    {
        
        $html = [
            'body' => $this->processArea($processor, $this->getTemplateBody($type)),
            'header' => $this->processArea($processor, $this->getTemplateHeader()),
            'footer' => $this->processArea($processor, $this->getTemplateFooter()),
            'filename' => $this->processArea($processor, $this->getTemplateFileName()),
        ];
        return $html;
    }

    /**
     * Get Design Config function
     *
     * @return void
     */
    public function getDesignConfig()
    {
        $templates = $this->getTemplate()->getData('store_id');
        $this->storeId = $templates[0];

        if ($this->designConfig === null) {
            $this->designConfig = new DataObject(
                ['area' => \Magento\Framework\App\Area::AREA_FRONTEND, 'store' => $this->storeId]
            );
        }

        return $this->designConfig;
    }
}
