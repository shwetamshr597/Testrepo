<?php
/**
 * @category  Mageants PdfInvoice
 * @package   Mageants_PdfInvoice
 * @copyright Copyright (c) 2019 mageants
 * @author Mageants Team <info@mageants.com>
 */


namespace Mageants\PdfInvoice\Observer;

class BeforeSendInvoiceObserver extends AbstractSendInvoiceObserver
{
}
