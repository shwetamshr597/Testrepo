/**
 * @category  Mageants PdfInvoice
 * @package   Mageants_PdfInvoice
 * @copyright Copyright (c) 2018 Mageants
 * @author Mageants Team <info@mageants.com>
 */
 
var config = {
    map: {
       '*': {
           'insertVariable': 'Mageants_PdfInvoice/js/form/insert-variable',
       }
    }
};