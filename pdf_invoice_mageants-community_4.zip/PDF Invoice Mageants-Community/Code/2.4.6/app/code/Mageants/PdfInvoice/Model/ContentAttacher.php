<?php
/**
 * @category  Mageants PdfInvoice
 * @package   Mageants_PdfInvoice
 * @copyright Copyright (c) 2019 mageants
 * @author Mageants Team <info@mageants.com>
 */

namespace Mageants\PdfInvoice\Model;

use \Mageants\PdfInvoice\Model\Api\AttachmentContainerInterface as ContainerInterface;

class ContentAttacher
{
    public const MIME_PDF = 'application/pdf';
    public const TYPE_OCTETSTREAM = 'application/octet-stream';
    public const MIME_TXT = 'text/plain';
    public const MIME_HTML = 'text/html; charset=UTF-8';

    /**
     * @var AttachmentFactory $attachmentFactory
     */
    private $attachmentFactory;

    /**
     * Constructor function
     *
     * @param AttachmentFactory $attachmentFactory
     */
    public function __construct(
        AttachmentFactory $attachmentFactory
    ) {
        $this->attachmentFactory = $attachmentFactory;
    }
    /**
     * Add Files function
     *
     * @param mixed $content
     * @param mixed $filename
     * @param mixed $mimeType
     * @param ContainerInterface $attachmentContainer
     * @return void
     */
    public function addGeneric($content, $filename, $mimeType, ContainerInterface $attachmentContainer)
    {
        
        $attachment = $this->attachmentFactory->create(
            [
                'content' => $content,
                'mimeType' => $mimeType,
                'fileName' => $filename
            ]
        );

        $attachmentContainer->addAttachment($attachment);
    }

    /**
     * Add Pdf function
     *
     * @param string $pdfString
     * @param string $pdfFilename
     * @param ContainerInterface $attachmentContainer
     * @return void
     */
    public function addPdf($pdfString, $pdfFilename, ContainerInterface $attachmentContainer)
    {
        $this->addGeneric($pdfString, $pdfFilename, self::MIME_PDF, $attachmentContainer);
    }

    /**
     * Add Text function
     *
     * @param string $text
     * @param string $filename
     * @param ContainerInterface $attachmentContainer
     * @return void
     */
    public function addText($text, $filename, ContainerInterface $attachmentContainer)
    {
        $this->addGeneric($text, $filename, self::MIME_PDF, $attachmentContainer);
    }

    /**
     * Add Html function
     *
     * @param mixed $html
     * @param string $filename
     * @param ContainerInterface $attachmentContainer
     * @return void
     */
    public function addHtml($html, $filename, ContainerInterface $attachmentContainer)
    {
        $this->addGeneric($html, $filename, self::MIME_HTML, $attachmentContainer);
    }
}
