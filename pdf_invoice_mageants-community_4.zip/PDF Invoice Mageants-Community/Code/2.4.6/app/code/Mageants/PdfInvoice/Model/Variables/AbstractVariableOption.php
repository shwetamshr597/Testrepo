<?php

/**
 * @category  Mageants PdfInvoice
 * @package   Mageants_PdfInvoice
 * @copyright Copyright (c) 2018 mageants
 * @author Mageants Team <info@mageants.com>
 */

namespace Mageants\PdfInvoice\Model\Variables;

abstract class AbstractVariableOption implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * @var string
     */
    public const PREFIX_VAR_CUSTOMER = 'customer';
    /**
     * @var string
     */
    public const PREFIX_VAR_ORDER = 'order';
    /**
     * @var string
     */
    public const PREFIX_VAR_INVOICE = 'invoice';
    /**
     * @var string
     */
    public const PREFIX_VAR_CREDITMEMO = 'creditmemo';
    /**
     * @var string
     */
    public const PREFIX_VAR_SHIPMENT = 'shipment';
    /**
     * @var string
     */
    public const PREFIX_VAR_QUOTE = 'quote';
    /**
     * @var string
     */
    public const PREFIX_VAR_ITEMS = 'items';
    /**
     * @var string
     */
    protected $_prefixVar = '';
    /**
     * @var array
     */
    protected $_additional_vars = [];
    /**
     * @var string
     */
    protected $_tableVar = '';
    /**
     * @var \Mageants\PdfInvoice\Model\Variables\Source\VariableList
     */
    protected $_resourceVariableList;

    /**
     * AbstractVariable constructor.
     *
     * @param \Mageants\PdfInvoice\Model\Variables\Source\VariableList $resourceVariableList
     */
    public function __construct(\Mageants\PdfInvoice\Model\Variables\Source\VariableList $resourceVariableList)
    {
        $this->_resourceVariableList = $resourceVariableList;
    }

    /**
     * Get Option Array function
     *
     * @return array
     */
    public function toOptionArray()
    {
        $options = [];

        foreach ($this->_resourceVariableList->getVariableList($this->_tableVar) as $item) {
            $options[] = [
                'value' => "{{var " . $this->getPrefixVariable() . "_{$item['COLUMN_NAME']}}}",
                'label' => $item['COLUMN_COMMENT']
                    ? $item['COLUMN_COMMENT'] : __(ucwords(str_replace('_', ' ', $item['COLUMN_NAME'])))
            ];
        }

        //add additional vars
        foreach ($this->getAdditionalVar() as $key => $var) {
            $options[] = [
                'value' => "{{var " . $this->getPrefixVariable() . "_{$key}}}",
                'label' => $var
            ];
        }

        return $options;
    }

    /**
     * Get OptionArray
     *
     * @return array
     */
    public function getAdditionalVar()
    {
        return [
            'payment_method' => __('Payment Method'),
            'shipping_method' => __('Shipping Method'),
            'currency' => __('Currency'),
            'billing_address' => __('Billing Address'),
            'shipping_address' => __('Shipping Address')
        ];
    }

    /**
     * Get prefix variable
     *
     * @return string
     */
    abstract public function getPrefixVariable();
}
