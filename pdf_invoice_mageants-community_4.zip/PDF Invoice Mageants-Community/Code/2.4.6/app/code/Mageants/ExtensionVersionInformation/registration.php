<?php
/**
 * @category   Mageants ExtensionVersionInformation
 * @package    Mageants_ExtensionVersionInformation
 * @copyright  Copyright (c) 2017 Mageants
 * @author     Mageants Team <support@Mageants.com>
 */
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Mageants_ExtensionVersionInformation',
    __DIR__
);
