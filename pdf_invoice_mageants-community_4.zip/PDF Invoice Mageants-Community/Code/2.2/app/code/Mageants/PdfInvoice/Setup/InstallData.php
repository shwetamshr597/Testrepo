<?php
 /**
 * @category  Mageants PdfInvoice
 * @package   Mageants_PdfInvoice
 * @copyright Copyright (c) 2018 mageants
 * @author Mageants Team <info@mageants.com>
 */

namespace Mageants\PdfInvoice\Setup;


use Mageants\PdfInvoice\Model\Defaulttemplates;
use Mageants\PdfInvoice\Model\DefaulttemplatesFactory;
use Magento\Framework\Module\Setup\Migration;
use Magento\Framework\Setup\InstallDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\App\Filesystem\DirectoryList;

class InstallData implements InstallDataInterface
{
    /**
     * Mageants\PdfInvoice\Model\DefaulttemplatesFactory
     */

    private $modelFactory;


    /**
     * Magento\Framework\Filesystem
     */

    private $filesystem;

    /**
     * Install Data constructor
     * @param DefaulttemplatesFactory $modelFactory
     */
    
    public function __construct(DefaulttemplatesFactory $modelFactory, \Magento\Framework\Filesystem $filesystem)
    {
        $this->modelFactory = $modelFactory;
        $this->filesystem = $filesystem;
    }
    
    /**
     * Install data
     * @param ModuleDataSetupInterface $setup
     * @param ModuleContextInterface$ #context
     */
    
    public function install(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
    	 $template01 = $this->filesystem->getDirectoryWrite(DirectoryList::LIB_INTERNAL)->getAbsolutePath('Pdf_templates/Template01.html');
    	 $template02 = $this->filesystem->getDirectoryWrite(DirectoryList::LIB_INTERNAL)->getAbsolutePath('Pdf_templates/Template02.html');
    	 $template03 = $this->filesystem->getDirectoryWrite(DirectoryList::LIB_INTERNAL)->getAbsolutePath('Pdf_templates/Template03.html');
    	 $template04 = $this->filesystem->getDirectoryWrite(DirectoryList::LIB_INTERNAL)->getAbsolutePath('Pdf_templates/Template04.html');
    	 
         $modeldata = [
            [
                'default_template_data' => file_get_contents($template01),
            ],
            [
                'default_template_data' => file_get_contents($template02),
            ],
            [
                'default_template_data' => file_get_contents($template03),
            ],
            [
                'default_template_data' => file_get_contents($template04),
            ]
         ];
         
         foreach ($modeldata as $data) {
            $this->modelFactory->create()->setData($data)->save();
        }
    }
}