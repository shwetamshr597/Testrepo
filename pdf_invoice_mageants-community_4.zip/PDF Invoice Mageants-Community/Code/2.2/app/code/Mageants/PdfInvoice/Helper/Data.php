<?php 
/**
 * @category  mageants Pdf Invoice
 * @package   Mageants_PdfInvoice
 * @copyright Copyright (c) 2018 mageants
 * @author Mageants Team <info@mageants.com>
 */
namespace Mageants\PdfInvoice\Helper; 

use \Magento\Framework\App\Config\ScopeConfigInterface;
use \Magento\Framework\App\Helper\Context;
use \Mageants\PdfInvoice\Model\Source\Orientation;
use \Mageants\PdfInvoice\Model\Source\PaperSize;
use Magento\Email\Model\Template as EmailTemplate;
use \Magento\Store\Model\ScopeInterface;
		
class Data extends \Magento\Framework\App\Helper\AbstractHelper 
{
	/** 
	* @var \Magento\Framework\App\Config\ScopeConfigInterfac 
	*/ 
	protected $_scopeConfig;
	
	/** 
	* @var array
	*/ 
	protected $_pdftemplatesConfig; 
	
	/** 
	* @var \Magento\Backend\Helper\Data
	*/ 
	protected $_helperBackend; 
	/** 
	* @var \Magento\Store\Model\StoreManagerInterface 
	*/ 
	protected $storeManager; 

	/*Extention Enable Disable Constant*/
	
    CONST ENABLE = 'mageants_pdfinvoice/general/enable'; 

	/*Order variable Constant*/
	
    CONST ORDER_VARIABLE = 'mageants_pdfinvoice/variables/order_variables'; 

	/* CORE_PRINTS_DISABLE */
	
    CONST CORE_PRINTS_DISABLE = 'mageants_pdfinvoice/general/core_prints'; 

	/* send_pdf_attachment */

	CONST SEND_PDF_ATTACHMENT = 'mageants_pdfinvoice/general/send_pdf_attachment';

    /* Company Name */    
    
    CONST COMPANY_NAME = 'mageants_pdfinvoice/business_info/company_name';

    /* Company Address */    

    CONST COMPANY_ADDRESS = 'mageants_pdfinvoice/business_info/address';

    /* Vat Number */    
    CONST VAT_NUMBER = 'mageants_pdfinvoice/business_info/vat_number';

    /* Vat Office */    
    CONST VAT_OFFICE = 'mageants_pdfinvoice/business_info/var_office';

    /* Business ID */    
    CONST BUSINESS_ID = 'mageants_pdfinvoice/business_info/business_id';

    /* Company Log */    
    CONST BUSINESS_LOGO = 'mageants_pdfinvoice/business_info/company_logo';

    /* Company Email */    
    CONST BUSINESS_EMAIL = 'mageants_pdfinvoice/business_contact/email';

    /* Company Phone */    
    CONST COMPANY_PHONE = 'mageants_pdfinvoice/business_contact/phone';

    /* Company Fax */    
    CONST COMPANY_FAX = 'mageants_pdfinvoice/business_contact/Fax';

      /**
     * NOTES
     * 
     */   
    const NOTES = 'mageants_pdfinvoice/business_info/notes';

     /**
     * TERMS_AND_CONDITIONS
     * 
     */   
    const TERMS_AND_CONDITIONS = 'mageants_pdfinvoice/business_info/terms_and_condition';

	/**
	 *	construct
	 *
     * @param Context $context,
	 * @param ScopeConfigInterface $scopeConfig 
	 * @param Data $HelperBackend
     * @param Json $serialize
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Email\Model\Source\Variables $storeVariables
     * @param \Magento\Variable\Model\Variable $customVariables
     */
	public function __construct( 
		Context $context, 	
		\Magento\Backend\Helper\Data $HelperBackend,
		\Magento\Store\Model\StoreManagerInterface $storeManager,
		\Magento\Email\Model\Source\Variables $storeVariables,
		\Magento\Variable\Model\Variable $customVariables
	) 
	{
		parent::__construct($context); 
		 
		$this->_scopeConfig = $context->getscopeConfig();
		$this->_helperBackend = $HelperBackend;
		$this->storeVariables = $storeVariables;
		$this->_pdftemplatesConfig['width'] = '10';
		$this->_pdftemplatesConfig['height'] = '25';
		$this->_pdftemplatesConfig['filename'] = 'invoice {{var invoice.increment_id}} ';
		$this->_pdftemplatesConfig['orientation'] = Orientation::USE_VERTICLE;
		$this->_pdftemplatesConfig['paper_size'] = PaperSize::USE_A4;
		$this->_pdftemplatesConfig['margin_top'] = '10';
		$this->_pdftemplatesConfig['margin_bottom'] = '10';
		$this->_pdftemplatesConfig['margin_left'] = '15';
		$this->_pdftemplatesConfig['margin_right'] = '15';
		$this->storeManager = $storeManager;
		$this->customVariables =$customVariables;
    }
	
	/**
     * Retrieve extention enable or disable
     *
     * @return boolean
     */
    public function isExtentionEnable()
	{
		return $this->_scopeConfig->getValue(self::ENABLE,ScopeInterface::SCOPE_STORE);
    }
	
	/**
     * Retrieve default pdftemplate configuration
     *
     * @return array
     */
    public function getDefaultSetting()
	{
			return $this->_pdftemplatesConfig;
    }
	
    /**
     * get order variables
     *
     * @return array
     */
    public function getOrderVariables()
	{
		return $this->_scopeConfig->getValue(self::ORDER_VARIABLE,ScopeInterface::SCOPE_STORE);
    }


    /**
     * is Default Printing Disable
     *
     * @return array
     */
    public function isDefaultPrintingDisable()
	{
		return $this->_scopeConfig->getValue(self::CORE_PRINTS_DISABLE,ScopeInterface::SCOPE_STORE);
    }

    /**
     * is allowed to attached in email
     *
     * @return array
     */
    public function isAllowedToAttachedInEmail()
	{
		return $this->_scopeConfig->getValue(self::SEND_PDF_ATTACHMENT,ScopeInterface::SCOPE_STORE);
    }

    /**
     * get Congig values
     *
     * @return array
     *
     */
    public function getConfigValues(){
    	$values['{{var '.self::COMPANY_NAME.'}}'] = $this->_scopeConfig->getValue(self::COMPANY_NAME,ScopeInterface::SCOPE_STORE);
    	$values['{{var '.self::COMPANY_ADDRESS.'}}'] = $this->_scopeConfig->getValue(self::COMPANY_ADDRESS,ScopeInterface::SCOPE_STORE);
    	$values['{{var '.self::VAT_NUMBER.'}}'] = $this->_scopeConfig->getValue(self::VAT_NUMBER,ScopeInterface::SCOPE_STORE);
    	$values['{{var '.self::VAT_OFFICE.'}}'] = $this->_scopeConfig->getValue(self::COMPANY_ADDRESS,ScopeInterface::SCOPE_STORE);
    	$values['{{var '.self::BUSINESS_ID.'}}'] =  $this->_scopeConfig->getValue(self::BUSINESS_ID,ScopeInterface::SCOPE_STORE);
    	$values['{{var '.self::BUSINESS_LOGO.'}}'] = $this->storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA) . 'mageants/pdfinvoice/logo/' . $this->_scopeConfig->getValue(self::BUSINESS_LOGO,ScopeInterface::SCOPE_STORE);
    	$values['{{var '.self::BUSINESS_EMAIL.'}}'] = $this->_scopeConfig->getValue(self::BUSINESS_EMAIL,ScopeInterface::SCOPE_STORE);
    	$values['{{var '.self::COMPANY_PHONE.'}}'] = $this->_scopeConfig->getValue(self::COMPANY_PHONE,ScopeInterface::SCOPE_STORE);
    	$values['{{var '.self::COMPANY_FAX.'}}'] = $this->_scopeConfig->getValue(self::COMPANY_FAX,ScopeInterface::SCOPE_STORE);
        $values['{{var '.self::NOTES.'}}'] = $this->_scopeConfig->getValue(self::NOTES,ScopeInterface::SCOPE_STORE);
        $values['{{var '.self::TERMS_AND_CONDITIONS.'}}'] = $this->_scopeConfig->getValue(self::TERMS_AND_CONDITIONS,ScopeInterface::SCOPE_STORE);

    	$storeVariables = $this->storeVariables->toOptionArray(true);
    	$storeValues = $storeVariables['value'];
    	foreach ($storeValues as $storeValue) {
        	$valuestring = explode('=', $storeValue['value']);   
    		$configvariable= substr($valuestring[1], 1, -3);
    		$values[$storeValue['value']] = $this->_scopeConfig->getValue($configvariable,ScopeInterface::SCOPE_STORE);
    	}
        $customVariables = $this->customVariables->getVariablesOptionArray(true);
        if($customVariables){
        	$customValues = $customVariables['value'];
        	foreach ($customValues as $customValue) {
        		$valuestring = explode('=', $customValue['value']);
        		$custvar = substr($valuestring[1], 0, -2);
        		 $this->customVariables->setStoreId(ScopeInterface::SCOPE_STORE);

        		if($this->customVariables->loadByCode($custvar)->getHtmlValue()){
        			$values[$customValue['value']]=	$this->customVariables->loadByCode($custvar)->getHtmlValue();
        		}elseif ($this->customVariables->loadByCode($custvar)->getPlainValue()) {
        			$values[$customValue['value']]=	$this->customVariables->loadByCode($custvar)->getPlainValue();
        		}
        	}
        }
    	return $values;
    }
}