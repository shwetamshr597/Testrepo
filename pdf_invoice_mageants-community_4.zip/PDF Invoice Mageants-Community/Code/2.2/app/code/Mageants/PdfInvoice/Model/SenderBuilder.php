<?php
/**
 * @category  mageants Pdf Invoice
 * @package   Mageants_PdfInvoice
 * @copyright Copyright (c) 2018 mageants
 * @author Mageants Team <info@mageants.com>
 */
namespace Mageants\PdfInvoice\Model;

use Magento\Framework\App\Filesystem\DirectoryList;

class SenderBuilder extends \Magento\Sales\Model\Order\Email\SenderBuilder
{
    /**
     * @var Api\AttachmentContainerInterface
     */
    protected $attachmentContainer;

    /**
    * @var \Magento\Sales\Model\Order\Email\Container\Template
    */
    protected $templateContainer;

    /**
    * @var \Mageants\PdfInvoice\Helper\Pdf
    */
    protected $pdfhelper;

    /**
    * @var \Mageants\PdfInvoice\Model\Pdftemplate
    */
    protected $pdfTemplate;


    /**
    * @var \Magento\Store\Model\StoreManagerInterface
    */
    protected $storeManager;


    /**
    * @var \Magento\Framework\Stdlib\DateTime\DateTime
    */
    protected $datetime;


    /**
    * @var Api\AttachmentContainerInterface
    */
    protected $fileFactory;


    /**
    * @var  Magento\Framework\App\Filesystem\DirectoryList
    */
    protected $directory_list;


    /**
    * @var \Magento\Framework\App\RequestInterface
    */
    protected $requestInterface;


    /**
    * @var  \Magento\Sales\Model\Order
    */
    protected $order;


    /**
    * @var \Magento\Sales\Api\InvoiceRepositoryInterface
    */
    protected $invoiceRepositoryInterface;


    /**
    * @var Magento\Sales\Model\Order\Creditmemo
    */
    protected $creditmemo;


    /**
    * @var Magento\Sales\Model\Order\Shipment
    */
    protected $shipment;


    /**
    * @var Mageants\PdfInvoice\Helper\Data
    */
    protected $invoicehelper;


    
    /**
     * @param \Magento\Sales\Model\Order\Email\Container\Template $templateContainer,
     * @param \Magento\Sales\Model\Order\Email\Container\IdentityInterface $identityContainer,
     * @param \Mageants\PdfInvoice\Model\TransportBuilder $transportBuilder,
     * @param \Mageants\PdfInvoice\Helper\Pdf $pdf,
     * @param \Mageants\PdfInvoice\Model\Pdftemplate $pdfTemplate,
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager,
     * @param \Magento\Framework\Stdlib\DateTime\DateTime $datetime,
     * @param \Magento\Framework\App\Response\Http\FileFactory $fileFactory,
     * @param \Magento\Framework\App\RequestInterface $requestInterface,
     * @param \Magento\Sales\Model\Order $order,
     * @param DirectoryList $directory_list,
     * @param \Magento\Sales\Api\InvoiceRepositoryInterface $invoiceRepositoryInterface,
     * @param \Magento\Sales\Model\Order\Creditmemo $creditmemo,
     * @param \Magento\Sales\Model\Order\Shipment $shipment,
     * @param \Mageants\PdfInvoice\Helper\Data $data
     */
    public function __construct(
        \Magento\Sales\Model\Order\Email\Container\Template $templateContainer,
        \Magento\Sales\Model\Order\Email\Container\IdentityInterface $identityContainer,
        \Mageants\PdfInvoice\Model\TransportBuilder $transportBuilder,
        \Mageants\PdfInvoice\Helper\Pdf $pdf,
        \Mageants\PdfInvoice\Model\Pdftemplate $pdfTemplate,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Stdlib\DateTime\DateTime $datetime,
        \Magento\Framework\App\Response\Http\FileFactory $fileFactory,
        \Magento\Framework\App\RequestInterface $requestInterface,
        \Magento\Sales\Model\Order $order,
        DirectoryList $directory_list,
        \Magento\Sales\Api\InvoiceRepositoryInterface $invoiceRepositoryInterface,
        \Magento\Sales\Model\Order\Creditmemo $creditmemo,
        \Magento\Sales\Model\Order\Shipment $shipment,
        \Mageants\PdfInvoice\Helper\Data $data
    ) {
        $this->templateContainer = $templateContainer;
        $this->pdfhelper = $pdf;
        $this->pdfTemplate = $pdfTemplate;
        $this->storeManager=$storeManager;
        $this->datetime = $datetime;
        $this->fileFactory = $fileFactory;
        $this->directory_list =$directory_list;
        $this->requestInterface =$requestInterface;
        $this->order = $order;
        $this->invoiceRepositoryInterface = $invoiceRepositoryInterface;
        $this->creditmemo = $creditmemo;
        $this->shipment = $shipment;
        $this->invoicehelper = $data;
        parent::__construct($templateContainer, $identityContainer, $transportBuilder);
    }

    /**
     * @return Api\AttachmentContainerInterface
     */
    public function getAttachmentContainer()
    {
        return $this->attachmentContainer;
    }

    /**
     * attach our attachments from the current sender to the message
     */
    public function send()
    {
        if ($this->invoicehelper->isExtentionEnable() && $this->invoicehelper->isAllowedToAttachedInEmail()) {
            $vars = $this->templateContainer->getTemplateVars();
            $order=null;
            $invoice=null;
            $creditmemo =null;
            $shipment = null;
            $template = $this->pdfTemplate->getCollection()->addFieldToFilter('status', 1)->addFieldToFilter('store_id', array('in',array(0, $this->storeManager->getStore()->getId())))->getLastItem();
            if ($template->getData()) {
                foreach ($vars as $var) {
                    if (is_object($var)) {
                        if ($var->getOrder()) {
                            $order = $var->getOrder();
                            break;
                        }
                    }
                }
                if ($this->requestInterface->getParam('order_id')) {
                    $order = $this->order->load($this->requestInterface->getParam('order_id'));
                }

                if ($order) {
                    if ($order->hasInvoices()) {
                        $invoiceCollection = $order->getInvoiceCollection();
                        foreach ($invoiceCollection as $invoices) {
                            $invoice = $this->invoiceRepositoryInterface->get($invoices->getId());
                        }
                    }
                    if ($order->hasCreditmemos()) {
                        $memoCollection = $order->getCreditmemosCollection();
                        foreach ($memoCollection as $memos) {
                            $creditmemo = $this->creditmemo->load($memos->getId());
                        }
                    }
                    if ($order->hasShipments()) {
                        $shipmentCollection = $order->getShipmentsCollection();
                        foreach ($shipmentCollection as $shipments) {
                            $shipment = $this->shipment->load($shipments->getId());
                        }
                    }
                    if ($order && !$this->requestInterface->getParam('invoice_id') && !$this->requestInterface->getParam('creditmemo_id') && !$this->requestInterface->getParam('shipment_id')) {
                        $this->pdfhelper->setOrderTemplate($order);
                        $this->pdfhelper->setTemplate($template);
                        $pdfFileData = $this->pdfhelper->generateEmailPdfData('order');
                        
                        $this->directory_list->getPath('var');
                        $fileattached = $this->directory_list->getPath('var').'/'.$pdfFileData;
                      
                        $this->transportBuilder->addAttachment($fileattached, 'Order'.$order->getIncrementId());
                    }
                }

                if ($this->requestInterface->getParam('invoice_id')) {
                    $invoice = $this->invoiceRepositoryInterface->get($this->requestInterface->getParam('invoice_id'));
                }
                if ($this->requestInterface->getParam('creditmemo_id')) {
                    $creditmemo = $this->creditmemo->load($this->requestInterface->getParam('creditmemo_id'));
                }
                if ($this->requestInterface->getParam('shipment_id')) {
                    $shipment = $this->shipment->load($this->requestInterface->getParam('shipment_id'));
                }

                if ($invoice && $this->requestInterface->getParam('invoice_id')) {
                    $this->pdfhelper->setInvoice($invoice);
                    $this->pdfhelper->setTemplate($template);
                    $pdfFileData = $this->pdfhelper->generateEmailPdfData('invoice');
                    
                    $this->directory_list->getPath('var');
                    $fileattached = $this->directory_list->getPath('var').'/'.$pdfFileData;
                  
                    $this->transportBuilder->addAttachment($fileattached, 'Invoice'.$invoice->getIncrementId());
                }
               
                if ($creditmemo && $this->requestInterface->getParam('creditmemo_id')) {
                    $this->pdfhelper->setCreditMemo($creditmemo);
                    $this->pdfhelper->setTemplate($template);
                    $pdfFileData = $this->pdfhelper->generateEmailPdfData('memo');
                    
                    $this->directory_list->getPath('var');
                    $fileattached = $this->directory_list->getPath('var').'/'.$pdfFileData;
                  
                    $this->transportBuilder->addAttachment($fileattached, 'Credit Memo'.$creditmemo->getIncrementId());
                }

                if ($shipment && $this->requestInterface->getParam('shipment_id')) {
                    $this->pdfhelper->setShipment($shipment);
                    $this->pdfhelper->setTemplate($template);
                    $pdfFileData = $this->pdfhelper->generateEmailPdfData('shipment');
                    
                    $this->directory_list->getPath('var');
                    $fileattached = $this->directory_list->getPath('var').'/'.$pdfFileData;
                  
                    $this->transportBuilder->addAttachment($fileattached, 'Packing Slip'.$shipment->getIncrementId());
                }
            }
        }
        parent::send();
    }


    /**
    * attach our attachments from the current sender to the message
    */
    public function sendCopyTo()
    {
        if ($this->invoicehelper->isExtentionEnable() && $this->invoicehelper->isAllowedToAttachedInEmail()) {
            $vars = $this->templateContainer->getTemplateVars();
            $order=null;
            $invoice=null;
            $creditmemo =null;
            $shipment = null;
            $template = $this->pdfTemplate->getCollection()->addFieldToFilter('status', 1)->addFieldToFilter('store_id', array('in',array(0, $this->storeManager->getStore()->getId())))->getLastItem();
            if ($template->getData()) {
                foreach ($vars as $var) {
                    if (is_object($var)) {
                        if ($var->getOrder()) {
                            $order = $var->getOrder();
                            break;
                        }
                    }
                }
                if ($this->requestInterface->getParam('order_id')) {
                    $order = $this->order->load($this->requestInterface->getParam('order_id'));
                }

                if ($order) {
                    if ($order->hasInvoices()) {
                        $invoiceCollection = $order->getInvoiceCollection();
                        foreach ($invoiceCollection as $invoices) {
                            $invoice = $this->invoiceRepositoryInterface->get($invoices->getId());
                        }
                    }
                    if ($order->hasCreditmemos()) {
                        $memoCollection = $order->getCreditmemosCollection();
                        foreach ($memoCollection as $memos) {
                            $creditmemo = $this->creditmemo->load($memos->getId());
                        }
                    }
                    if ($order->hasShipments()) {
                        $shipmentCollection = $order->getShipmentsCollection();
                        foreach ($shipmentCollection as $shipments) {
                            $shipment = $this->shipment->load($shipments->getId());
                        }
                    }
                    $this->pdfhelper->setOrderTemplate($order);
                    $this->pdfhelper->setTemplate($template);
                    $pdfFileData = $this->pdfhelper->generateEmailPdfData('order');
                    
                    $this->directory_list->getPath('var');
                    $fileattached = $this->directory_list->getPath('var').'/'.$pdfFileData;
                  
                    $this->transportBuilder->addAttachment($fileattached, 'order');
                }
                if ($this->requestInterface->getParam('invoice_id')) {
                    $invoice = $this->invoiceRepositoryInterface->get($this->requestInterface->getParam('invoice_id'));
                }
                if ($this->requestInterface->getParam('creditmemo_id')) {
                    $creditmemo = $this->creditmemo->load($this->requestInterface->getParam('creditmemo_id'));
                }
                if ($this->requestInterface->getParam('shipment_id')) {
                    $shipment = $this->shipment->load($this->requestInterface->getParam('shipment_id'));
                }
                if ($invoice) {
                    $this->pdfhelper->setInvoice($invoice);
                    $this->pdfhelper->setTemplate($template);
                    $pdfFileData = $this->pdfhelper->generateEmailPdfData('invoice');
                    
                    $this->directory_list->getPath('var');
                    $fileattached = $this->directory_list->getPath('var').'/'.$pdfFileData;
                  
                    $this->transportBuilder->addAttachment($fileattached, 'invoice');
                }
               
                if ($creditmemo) {
                    $this->pdfhelper->setCreditMemo($creditmemo);
                    $this->pdfhelper->setTemplate($template);
                    $pdfFileData = $this->pdfhelper->generateEmailPdfData('memo');
                    
                    $this->directory_list->getPath('var');
                    $fileattached = $this->directory_list->getPath('var').'/'.$pdfFileData;
                  
                    $this->transportBuilder->addAttachment($fileattached, 'refund');
                }

                if ($shipment) {
                    $this->pdfhelper->setShipment($shipment);
                    $this->pdfhelper->setTemplate($template);
                    $pdfFileData = $this->pdfhelper->generateEmailPdfData('shipment');
                    
                    $this->directory_list->getPath('var');
                    $fileattached = $this->directory_list->getPath('var').'/'.$pdfFileData;
                  
                    $this->transportBuilder->addAttachment($fileattached, 'shipment');
                }
            }
        }
        parent::sendCopyTo();
    }
}
