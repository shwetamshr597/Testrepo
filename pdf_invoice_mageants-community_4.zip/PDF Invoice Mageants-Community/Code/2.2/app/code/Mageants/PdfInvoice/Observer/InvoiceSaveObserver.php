<?php
/**
 * @category  mageants Pdf Invoice
 * @package   Mageants_PdfInvoice
 * @copyright Copyright (c) 2018 mageants
 * @author Mageants Team <info@mageants.com>
 */
namespace Mageants\PdfInvoice\Observer;

use Magento\Framework\Event\ObserverInterface;

class InvoiceSaveObserver implements ObserverInterface
{
    /**
    * @var \Magento\Framework\Registry
    */

    protected $request;

    public function __construct(
        \Magento\Framework\App\RequestInterface $request
    ) {
        $this->request = $request;
    }

    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $invoice = $observer->getEvent()->getInvoice();
        $invoice_id = $invoice->getId();
        $this->request->setParam('invoice_id', $invoice_id);
        return $this;
    }
}
