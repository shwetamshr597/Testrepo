<?php
/**
 * @category  mageants Pdf Invoice
 * @package   Mageants_PdfInvoice
 * @copyright Copyright (c) 2018 mageants
 * @author Mageants Team <info@mageants.com>
 */
namespace Mageants\PdfInvoice\Observer;

use Magento\Framework\Event\ObserverInterface;

class CreditmemoSaveObserver implements ObserverInterface
{
    /**
    * @var \Magento\Framework\Registry
    */

    protected $request;

    public function __construct(
        \Magento\Framework\App\RequestInterface $request
    ) {
        $this->request = $request;
    }

    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $creditmemo = $observer->getEvent()->getCreditmemo();
        $creditmemoId = $creditmemo->getId();
        $this->request->setParam('creditmemo_id', $creditmemoId);
        return $this;
    }
}
