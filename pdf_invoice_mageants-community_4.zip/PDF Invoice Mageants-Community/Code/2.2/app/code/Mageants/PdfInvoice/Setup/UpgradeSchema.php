<?php
 /**
 * @category  Mageants PdfInvoice
 * @package   Mageants_PdfInvoice
 * @copyright Copyright (c) 2018 mageants
 * @author Mageants Team <info@mageants.com>
 */

namespace Mageants\PdfInvoice\Setup;

use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

class UpgradeSchema implements UpgradeSchemaInterface
{
	
	
    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        if (version_compare($context->getVersion(), '2.0.1', '<'))
        {
            $installer = $setup;
            $installer->startSetup();
            $pdfTemplate = $setup->getTable('mageants_pdftemplate');
            if ($setup->getConnection()->isTableExists($pdfTemplate) == true) {
              $connection = $setup->getConnection();
              $connection->dropColumn($pdfTemplate, 'template_data');
              
             $installer->getConnection()->addColumn(
                    $pdfTemplate,
                    'default_template_id',
                    [
                        'type' => \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                        'length' => 10,
                        'nullable' => true,
                        'comment' => 'Default Template Id'
                    ]
                );
            }


            /*Pdf Invoice Template Table*/
            
            $table  = $installer->getConnection()
                ->newTable($installer->getTable('mageants_order_pdftemplate'))
                ->addColumn(
                    'id',
                    \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                    null,
                    ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
                    'Id'
                )
                ->addColumn(
                    'orderfilename',
                    \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    255,
                    ['default' => null, 'nullable' => false],
                    'Pdf Template Name'
                )
                ->addColumn(
                    'invoice_order_data',
                    \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    null,
                    ['default' => null, 'nullable' => false],
                    'Pdf Template html' 
                )->addColumn(
                    'order_horizontal_barcode',
                    \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                    10,
                    ['default' => 0, 'nullable' => false],
                    'Horizontal Barcode' 
                )->addColumn(
                    'order_vertical_barcode',
                    \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                    10,
                    ['default' => 0, 'nullable' => false],
                    'Vertical Barcode place' 
                )->addColumn(
                    'template_id',
                    \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                    null,
                    ['unsigned' => true, 'nullable' => false],
                    'pdf template id' 
                )->addForeignKey(
                    $setup->getFkName('mageants_order_pdftemplate', 'template_id', 'mageants_pdftemplate', 'template_id'),
                    'template_id',
                    $setup->getTable('mageants_pdftemplate'),
                    'template_id',
                    \Magento\Framework\DB\Ddl\Table::ACTION_CASCADE
                )
                ->addIndex(  
                    $installer->getIdxName(  
                        $installer->getTable('mageants_order_pdftemplate'),  
                        ['orderfilename'],  
                        \Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_FULLTEXT  
                    ),  
                    ['orderfilename'],
                    ['type' => \Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_FULLTEXT]
                );
                
            $installer->getConnection()->createTable($table);

            /*Pdf Invoice Template Table*/
            
            $table  = $installer->getConnection()
                ->newTable($installer->getTable('mageants_invoice_pdftemplate'))
                ->addColumn(
                    'id',
                    \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                    null,
                    ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
                    'Id'
                )
                ->addColumn(
                    'invoicefilename',
                    \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    255,
                    ['default' => null, 'nullable' => false],
                    'Pdf Template Name'
                )->addColumn(
                    'invoice_template_data',
                    \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    null,
                    ['default' => null, 'nullable' => false],
                    'Pdf Template data HTML' 
                )->addColumn(
                    'invoice_horizontal_barcode',
                    \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                    10,
                    ['default' => 0, 'nullable' => false],
                    'Horizontal Barcode' 
                )->addColumn(
                    'invoice_vertical_barcode',
                    \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                    10,
                    ['default' => 0, 'nullable' => false],
                    'Vertical Barcode place' 
                )->addColumn(
                    'template_id',
                    \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                    null,
                    ['unsigned' => true, 'nullable' => false],
                    'pdf template id' 
                )->addForeignKey(
                    $setup->getFkName('mageants_invoice_pdftemplate', 'template_id', 'mageants_pdftemplate', 'template_id'),
                    'template_id',
                    $setup->getTable('mageants_pdftemplate'),
                    'template_id',
                    \Magento\Framework\DB\Ddl\Table::ACTION_CASCADE
                )
                ->addIndex(  
                    $installer->getIdxName(  
                        $installer->getTable('mageants_invoice_pdftemplate'),  
                        ['invoicefilename'],  
                        \Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_FULLTEXT  
                    ),  
                    ['invoicefilename'],
                    ['type' => \Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_FULLTEXT]
                );
                
            $installer->getConnection()->createTable($table);
    		
    		/*Pdf Shipment Template Table*/
    		
            $table  = $installer->getConnection()
                ->newTable($installer->getTable('mageants_shipment_pdftemplate'))
                ->addColumn(
                    'id',
                    \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                    null,
                    ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
                    'Id'
                )
                ->addColumn(
                    'shipmentfilename',
                    \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    255,
                    ['default' => null, 'nullable' => false],
                    'Pdf Template Name'
                )
                ->addColumn(
                    'shipment_template_data',
                    \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    null,
                    ['default' => null, 'nullable' => false],
                    'Pdf Template Data HTML' 
                )->addColumn(
                    'shipment_horizontal_barcode',
                    \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                    10,
                    ['default' => 0, 'nullable' => false],
                    'Horizontal Barcode' 
                )->addColumn(
                    'shipment_vertical_barcode',
                    \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                    10,
                    ['default' => 0, 'nullable' => false],
                    'Vertical Barcode place' 
                )->addColumn(
                    'template_id',
                    \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                    null,
                    ['unsigned' => true, 'nullable' => false],
                    'Pdf Template id' 
                )->addForeignKey(
                    $setup->getFkName('mageants_shipment_pdftemplate', 'template_id', 'mageants_pdftemplate', 'template_id'),
                    'template_id',
                    $setup->getTable('mageants_pdftemplate'),
                    'template_id',
                    \Magento\Framework\DB\Ddl\Table::ACTION_CASCADE
                )
    			->addIndex(  
    				$installer->getIdxName(  
    					$installer->getTable('mageants_shipment_pdftemplate'),  
    					['shipmentfilename'],  
    					\Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_FULLTEXT  
    				),  
    				['shipmentfilename'],
    				['type' => \Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_FULLTEXT]
    			);
    			
            $installer->getConnection()->createTable($table);

            /*Pdf Creditmemo Template Table*/
            
            $table  = $installer->getConnection()
                ->newTable($installer->getTable('mageants_creditmemo_pdftemplate'))
                ->addColumn(
                    'id',
                    \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                    null,
                    ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
                    'Id'
                )
                ->addColumn(
                    'memofilename',
                    \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    255,
                    ['default' => null, 'nullable' => false],
                    'Pdf Template Name'
                )
                ->addColumn(
                    'creditmemo_template_data',
                    \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    null,
                    ['default' => null, 'nullable' => false],
                    'Pdf Template Setting  Data HTML' 
                )->addColumn(
                    'memo_horizontal_barcode',
                    \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                    10,
                    ['default' => 0, 'nullable' => false],
                    'Horizontal Barcode' 
                )->addColumn(
                    'memo_vertical_barcode',
                    \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                    10,
                    ['default' => 0, 'nullable' => false],
                    'Vertical Barcode place' 
                )->addColumn(
                    'template_id',
                    \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                    null,
                    ['unsigned' => true, 'nullable' => false],
                    'Pdf Template Id' 
                )->addForeignKey(
                    $setup->getFkName('mageants_creditmemo_pdftemplate', 'template_id', 'mageants_pdftemplate', 'template_id'),
                    'template_id',
                    $setup->getTable('mageants_pdftemplate'),
                    'template_id',
                    \Magento\Framework\DB\Ddl\Table::ACTION_CASCADE
                )
                ->addIndex(  
                    $installer->getIdxName(  
                        $installer->getTable('mageants_shipment_pdftemplate'),  
                        ['memofilename'],  
                        \Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_FULLTEXT  
                    ),  
                    ['memofilename'],
                    ['type' => \Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_FULLTEXT]
                );
                
            $installer->getConnection()->createTable($table);


            $table  = $installer->getConnection()
                ->newTable($installer->getTable('mageants_default_template'))
                ->addColumn(
                    'id',
                    \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                    null,
                    ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
                    'Id'
                )
                ->addColumn(
                    'default_template_data',
                    \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    null,
                    ['default' => null, 'nullable' => false],
                    'Pdf Template Setting  in serialize form' 
                );
                
            $installer->getConnection()->createTable($table);
            $installer->endSetup();
        }
    }
}
