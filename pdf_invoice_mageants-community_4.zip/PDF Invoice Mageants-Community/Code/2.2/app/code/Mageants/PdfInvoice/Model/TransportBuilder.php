<?php
/**
 * @category  mageants Pdf Invoice
 * @package   Mageants_PdfInvoice
 * @copyright Copyright (c) 2018 mageants
 * @author Mageants Team <info@mageants.com>
 */
 
namespace Mageants\PdfInvoice\Model;
 
class TransportBuilder extends \Magento\Framework\Mail\Template\TransportBuilder
{
	/**
 	* @param Api\AttachmentInterface $attachment
 	*/
	public function addAttachment($pdfString, $type='')
	{
        $fileattached =  @file_get_contents($pdfString);
        $this->message->createAttachment(
        	$fileattached,
        	'application/pdf',
            \Zend_Mime::DISPOSITION_ATTACHMENT,
            \Zend_Mime::ENCODING_BASE64,
        	$type.'.pdf'
    	);
    	return $this;
	}
    /**
     * clear header
     * @param $headername
     */
    public function clearHeader($headerName)
	{
    	if (isset($this->_headers[$headerName])){
            unset($this->_headers[$headerName]);
    	}
    	return $this;
	}
}