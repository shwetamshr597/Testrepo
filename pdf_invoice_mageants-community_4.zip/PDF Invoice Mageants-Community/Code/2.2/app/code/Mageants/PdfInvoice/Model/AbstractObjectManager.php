<?php
/**
 * @category  Mageants PdfInvoice
 * @package   Mageants_PdfInvoice
 * @copyright Copyright (c) 2018 mageants
 * @author Mageants Team <info@mageants.com>
 */

namespace Mageants\PdfInvoice\Model;


abstract class AbstractObjectManager
{
    /**
     * Map of types which are references to classes.
     *
     * @var array
     */
    protected $_typeMap = [];

    /**
     * @var \Magento\Framework\ObjectManagerInterface
     */
    protected $_objectManager;

    /**
     * OptionManager constructor.
     *
     * @param \Magento\Framework\ObjectManagerInterface $objectManager
     * @param array $typeMap
     */
    public function __construct(
        \Magento\Framework\ObjectManagerInterface $objectManager,
        array $typeMap = []
    )
    {
        $this->_objectManager = $objectManager;
        $this->mergeTypes($typeMap);
    }

    /**
     * Add or override object types.
     *
     * @param array $typeMap
     */
    protected function mergeTypes(array $typeMap)
    {
        foreach ($typeMap as $typeInfo) {
            if (isset($typeInfo['type']) && isset($typeInfo['class'])) {
                $this->_typeMap[$typeInfo['type']] = $typeInfo['class'];
            }
        }
    }

    /**
     * @param $type
     *
     * @return mixed
     */
    abstract public function get($type);
}