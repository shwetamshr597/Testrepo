<?php
/**
 * @category  Mageants PdfInvoice
 * @package   Mageants_PdfInvoice
 * @copyright Copyright (c) 2018 Mageants
 * @author Mageants Team <info@mageants.com>
 */


\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Mageants_PdfInvoice',
    __DIR__
);