<?php
/**
 * @category  Mageants PdfInvoice
 * @package   Mageants_PdfInvoice
 * @copyright Copyright (c) 2018 mageants
 * @author Mageants Team <info@mageants.com>
 */

namespace Mageants\PdfInvoice\Helper;

use Mageants\PdfInvoice\Model\Template\Processor;
use Magento\Payment\Helper\Data as PaymentHelper;
use Magento\Sales\Model\Order\Email\Container\InvoiceIdentity;
use Magento\Sales\Model\Order\Address\Renderer;
use Magento\Framework\App\Helper\Context;
use Magento\Framework\App\Helper\AbstractHelper;
use \Mageants\PdfInvoice\Model\Source\Orientation;
use \Mageants\PdfInvoice\Model\Pdftemplate;
use \Mageants\PdfInvoice\Helper\Data;
use Magento\Framework\App\Filesystem\DirectoryList;
use \Mageants\PdfInvoice\Model\OptionManager;
use Magento\Sales\Model\OrderFactory as OrderFactory;

class Pdf extends AbstractHelper
{
  
    /**
     * Paper orientation
     */
    const PAPER_ORI = [
        0 => 'P',
        1 => 'L'
    ];

    /**
     * Paper size
     */
    const PAPER_SIZE = [
        0 => 'A4',
        1 => 'A3',
        2 => 'A5',
        3 => 'A6',
        4 => 'LETTER',
        5 => 'LEGAL'
    ];


    /* fonts */
    
    const FONTS = 'mageants_pdfinvoice/setting/choose_fonts';

    /* orientation */
    
    const ORIENTATION = 'mageants_pdfinvoice/setting/orientation';

    /* PAPER SIZE */

    const PAPERSIZE = 'mageants_pdfinvoice/setting/paper_size';

    /* PAPER SIZE */

    const FONTSIZE = 'mageants_pdfinvoice/setting/font_size';

    /* TOP MARGIN */

    const TOP_MARGIN = 'mageants_pdfinvoice/setting/top_margin';

    /* BOTTOM MARGIN */

    const BOTTOM_MARGIN = 'mageants_pdfinvoice/setting/bottom_margin';

    /* LEFT MARGIN */

    const LEFT_MARGIN = 'mageants_pdfinvoice/setting/left_margin';

    /* RIGHT MARGIN */

    const RIGHT_MARGIN = 'mageants_pdfinvoice/setting/right_margin';

    /* SCRIPT DIRECTION [LTR || RTL]*/

    const SCRIPT_DIR = 'mageants_pdfinvoice/setting/lang_direction';

    /* COMPANY NAME */

    const COMPANY_NAME = 'mageants_pdfinvoice/business_info/company_name';

    /* COMPANY ADDRESS */
    
    const COMPANY_ADDRESS = 'mageants_pdfinvoice/business_info/address';

    /* VAT MUMBER */
    
    const VAT_NUMBER = 'mageants_pdfinvoice/business_info/vat_number';

    /* VAT OFFICE */
    
    const VAT_OFFICE = 'mageants_pdfinvoice/business_info/var_office';

    /* BUSINESS ID */

    const BUSINESS_ID = 'mageants_pdfinvoice/business_info/business_id';

    /* BUSINESS LOGO */
    const BUSINESS_LOGO = 'mageants_pdfinvoice/business_info/company_logo';

    /* BUSINESS EMAIL */
    const BUSINESS_EMAIL = 'mageants_pdfinvoice/business_contact/email';

    /* COMPANY PHONE */

    const COMPANY_PHONE = 'mageants_pdfinvoice/business_contact/phone';

    /* COMPANY FAX */

    const COMPANY_FAX = 'mageants_pdfinvoice/business_contact/Fax';

    /* BARCODE_HORIZONTAL */

    const SHOW_BARCODE = 'mageants_pdfinvoice/barcode/show_barcode';

    /* SHOW_TEXT_BARCODE */

    const SHOW_TEXT_BARCODE = 'mageants_pdfinvoice/barcode/show_text_barcode';

    /* SHOW_TEXT_BARCODE */

    const SIZE_BARCODE = 'mageants_pdfinvoice/barcode/size_barcode';

    /* SHOW_TEXT_BARCODE */

    const HEIGHT_BARCODE = 'mageants_pdfinvoice/barcode/height';

    /* SHOW_TEXT_BARCODE */

    const TYPE_BARCODE = 'mageants_pdfinvoice/barcode/btype';

    /**
    * NOTES
    *
    */
    const NOTES = 'mageants_pdfinvoice/business_info/notes';

    /**
    * TERMS_AND_CONDITIONS
    *
    */
    const TERMS_AND_CONDITIONS = 'mageants_pdfinvoice/business_info/terms_and_condition';

    /**
     * @var \Magento\Sales\Model\Order
     */

    protected $order;

    /**
     * @var \Magento\Sales\Model\Order\Invoice
     */
    protected $invoice;

    /**
     * @var \Mageants\PdfInvoice\Model\Pdftemplate
     */
    protected $template;

    /**
     * @var \Magento\Sales\Model\Order\Email\Container\InvoiceIdentity
     */
    protected $identityContainer;

    /**
     * @var mPDF
     */
    public $_mPDF;

    /**
     * @var \Magento\Payment\Helper\Data
     */
    protected $paymentHelper;

    /**
     * @var \Magento\Sales\Model\Order\Address\Renderer
     */
    protected $addressRenderer;

    /**
     * @var \Mageants\PdfInvoice\Model\Template\Processor
     */
    protected $processor;

    /**
     * @var \Mageants\PdfInvoice\Helper\Data
     */
    protected $helper;

    /**
     * @var \Magento\Framework\Filesystem
     */
    protected $_filesystem;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $scopeConfig;

    /**
     * @var \Mageants\PdfInvoice\Model\OptionManager
     */
    protected $optionManager;

    /**
     * @var \Magento\Framework\Pricing\Helper\Data
     */
    protected $priceHelper;


    /**
     * @var \Mageants\PdfInvoice\Model\Config\FontList
     */
    protected $fontlist;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $storeManager;


    /**
     * @var \Magento\Framework\Stdlib\DateTime\DateTime
     */
    protected $datetime;

    /**
     * pdf library
     */
    protected $pdf;

    /**
     * pdf config
     */
    protected $config;

    /**
     * pdf ucdn
     */
    protected $ucdn;

    /**
     * default CSS
     */
    protected $defaultCss;

    /**
     * size Convertor
     */
    protected $sizeConvertor;

    /**
     * color
     */
    protected $color;

    /**
     * gradient
     */
    protected $gradient;

    /**
     * table of contents
     */
    protected $tableOfContents;

    /**
     * cache
     */
    protected $cache;

    /**
     * font cache
     */
    protected $fontCache;

    /**
     * fonts file finder
     */
    protected $fontsFileFinder;

    /**
     * css Manager
     */
    protected $cssManager;

    /**
     * otl
     */
    protected $otl;

    /**
     * form
     */
    protected $form;

    /**
     * hyphenator
     */
    protected $hyphenator;

    /**
     * tag
     */
    protected $tag;

    /**
     * namedcolors
     */
    protected $namedcolors;

    /**
     * pageformat
     */
    protected $pageformat;

    /**
     * font variables
     */
    protected $fontVariables;

    /**
     * text vars
     */
    protected $textvars;

    /**
     * border
     */
    protected $border;

    /**
     * log context
     */
    protected $logcontext;

    /**
     * tt font file
     */
    protected $ttfotfile;

    /**
     * destonation
     */
    protected $destination;

    /**
     * pdf exception
     */
    protected $pdfexception;

    /**
     * metrix generator
     */
    protected $metrixGenerator;

    /**
     * glyph operator
     */
    protected $GlyphOperator;

    /**
     * script to lang
     */
    protected $ScriptToLang;

    /**
     * lang to font
     */
    protected $LangToFont;

    /**
     * barcode
     */
    protected $barcode;

    /**
     * Pdf constructor.
     * @param Context $context
     * @param Renderer $addressRenderer
     * @param PaymentHelper $paymentHelper
     * @param InvoiceIdentity $identityContainer
     * @param Processor $templateFactory
     * @param Data $helper
     * @param \Magento\Framework\Filesystem $filesystem
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Magento\Framework\Pricing\Helper\Data $priceHelper
     * @param OptionManager $optionManager
     * @param \Mageants\PdfInvoice\Model\Config\FontList $fontlist
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Framework\Stdlib\DateTime\DateTime $datetime
     */
    public function __construct(
        Context $context,
        Renderer $addressRenderer,
        PaymentHelper $paymentHelper,
        InvoiceIdentity $identityContainer,
        Processor $templateFactory,
        Data $helper,
        \Magento\Framework\Filesystem $filesystem,
        \Magento\Framework\Pricing\Helper\Data $priceHelper,
        OptionManager $optionManager,
        \Mageants\PdfInvoice\Model\Config\FontList $fontlist,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Stdlib\DateTime\DateTime $datetime,
        \Magento\Sales\Model\Order\Shipment $modelShipment,
        \Magento\Sales\Model\Order\Creditmemo $modelCreditmemo,
        \Magento\Sales\Api\InvoiceRepositoryInterface $invoiceRepository,
        \Magento\Sales\Api\Data\OrderInterface $orderInterface,
        \Magento\Sales\Model\Order $ordersdata,
        OrderFactory $orderFactory
    ) {
        $this->processor = $templateFactory;
        $this->paymentHelper = $paymentHelper;
        $this->identityContainer = $identityContainer;
        $this->addressRenderer = $addressRenderer;
        $this->helper = $helper;
        $this->ordersdata = $ordersdata;
        $this->_filesystem = $filesystem;
        $this->scopeConfig = $context->getScopeConfig();
        $this->optionManager = $optionManager;
        $this->priceHelper = $priceHelper;
        $this->fontlist = $fontlist->toOptionArray();
        $this->storeManager = $storeManager;
        $this->datetime = $datetime;
        $this->modelShipment = $modelShipment;
        $this->modelCreditmemo = $modelCreditmemo;
        $this->invoiceRepository = $invoiceRepository;
        $this->orderInterface = $orderInterface;
        $this->orderFactory = $orderFactory;
        $this->request = $context->getRequest();
        $this->_construct();
        parent::__construct($context);
    }

    /**
     * @construct
     * initialization of MPDF LIBRARY
     */
    protected function _construct()
    {
        $this->pdf =  $this->_filesystem->getDirectoryWrite(DirectoryList::LIB_INTERNAL)
            ->getAbsolutePath('Mpdf/Mpdf.php');
        $this->config = $this->_filesystem->getDirectoryWrite(DirectoryList::LIB_INTERNAL)->getAbsolutePath('Mpdf\Config\ConfigVariables.php');
        $this->ucdn = $this->_filesystem->getDirectoryWrite(DirectoryList::LIB_INTERNAL)->getAbsolutePath('Mpdf\Ucdn.php');
        $this->defaultCss = $this->_filesystem->getDirectoryWrite(DirectoryList::LIB_INTERNAL)->getAbsolutePath('Mpdf\Css\DefaultCss.php');
        $this->sizeConvertor = $this->_filesystem->getDirectoryWrite(DirectoryList::LIB_INTERNAL)->getAbsolutePath('Mpdf\SizeConvertor.php');
        $this->color = $this->_filesystem->getDirectoryWrite(DirectoryList::LIB_INTERNAL)->getAbsolutePath('Mpdf\Color\ColorConvertor.php');
        $this->gradient = $this->_filesystem->getDirectoryWrite(DirectoryList::LIB_INTERNAL)->getAbsolutePath('Mpdf\Gradient.php');
        $this->tableOfContents = $this->_filesystem->getDirectoryWrite(DirectoryList::LIB_INTERNAL)->getAbsolutePath('Mpdf\TableOfContents.php');
        $this->cache = $this->_filesystem->getDirectoryWrite(DirectoryList::LIB_INTERNAL)->getAbsolutePath('Mpdf\Cache.php');
        $this->fontCache = $this->_filesystem->getDirectoryWrite(DirectoryList::LIB_INTERNAL)->getAbsolutePath('Mpdf\Fonts\FontCache.php');
        $this->fontsFileFinder = $this->_filesystem->getDirectoryWrite(DirectoryList::LIB_INTERNAL)->getAbsolutePath('Mpdf\Fonts\FontFileFinder.php');
        $this->cssManager = $this->_filesystem->getDirectoryWrite(DirectoryList::LIB_INTERNAL)->getAbsolutePath('Mpdf\CssManager.php');
        $this->otl = $this->_filesystem->getDirectoryWrite(DirectoryList::LIB_INTERNAL)->getAbsolutePath('Mpdf\Otl.php');
        $this->form = $this->_filesystem->getDirectoryWrite(DirectoryList::LIB_INTERNAL)->getAbsolutePath('Mpdf\Form.php');
        $this->hyphenator = $this->_filesystem->getDirectoryWrite(DirectoryList::LIB_INTERNAL)->getAbsolutePath('Mpdf\Hyphenator.php');
        $this->tag = $this->_filesystem->getDirectoryWrite(DirectoryList::LIB_INTERNAL)->getAbsolutePath('Mpdf\Tag.php');
        $this->namedcolors = $this->_filesystem->getDirectoryWrite(DirectoryList::LIB_INTERNAL)->getAbsolutePath('Mpdf\Color\NamedColors.php');
        $this->pageformat = $this->_filesystem->getDirectoryWrite(DirectoryList::LIB_INTERNAL)->getAbsolutePath('Mpdf\PageFormat.php');
        $this->fontVariables = $this->_filesystem->getDirectoryWrite(DirectoryList::LIB_INTERNAL)->getAbsolutePath('Mpdf\Config\FontVariables.php');
        $this->textvars = $this->_filesystem->getDirectoryWrite(DirectoryList::LIB_INTERNAL)->getAbsolutePath('Mpdf\Css\TextVars.php');
        $this->border = $this->_filesystem->getDirectoryWrite(DirectoryList::LIB_INTERNAL)->getAbsolutePath('Mpdf\Css\Border.php');
        $this->logcontext = $this->_filesystem->getDirectoryWrite(DirectoryList::LIB_INTERNAL)->getAbsolutePath('Mpdf\Log\Context.php');
        $this->ttfotfile = $this->_filesystem->getDirectoryWrite(DirectoryList::LIB_INTERNAL)->getAbsolutePath('Mpdf\TTFontFile.php');
        $this->destination = $this->_filesystem->getDirectoryWrite(DirectoryList::LIB_INTERNAL)->getAbsolutePath('Mpdf\Output\Destination.php');
        $this->pdfexception = $this->_filesystem->getDirectoryWrite(DirectoryList::LIB_INTERNAL)->getAbsolutePath('Mpdf\MpdfException.php');
        $this->metrixGenerator = $this->_filesystem->getDirectoryWrite(DirectoryList::LIB_INTERNAL)->getAbsolutePath('Mpdf\Fonts\MetricsGenerator.php');
        $this->GlyphOperator = $this->_filesystem->getDirectoryWrite(DirectoryList::LIB_INTERNAL)->getAbsolutePath('Mpdf\Fonts\GlyphOperator.php');
        $this->ScriptToLang = $this->_filesystem->getDirectoryWrite(DirectoryList::LIB_INTERNAL)->getAbsolutePath('Mpdf\ScriptToLang.php');
        $this->LangToFont = $this->_filesystem->getDirectoryWrite(DirectoryList::LIB_INTERNAL)->getAbsolutePath('Mpdf\LangToFont.php');
        $this->barcode = $this->_filesystem->getDirectoryWrite(DirectoryList::LIB_INTERNAL)->getAbsolutePath('Mpdf\Barcode.php');
        $this->barc = $this->_filesystem->getDirectoryWrite(DirectoryList::LIB_INTERNAL)->getAbsolutePath('Barcode\barcode.php');
        require_once $this->pdf;
        require_once $this->config;
        require_once $this->ucdn;
        require_once $this->defaultCss;
        require_once $this->sizeConvertor;
        require_once $this->color;
        require_once $this->gradient;
        require_once $this->tableOfContents;
        require_once $this->cache;
        require_once $this->fontCache;
        require_once $this->fontsFileFinder;
        require_once $this->cssManager;
        require_once $this->otl;
        require_once $this->form;
        require_once $this->hyphenator;
        require_once $this->tag;
        require_once $this->namedcolors;
        require_once $this->pageformat;
        require_once $this->fontVariables;
        require_once $this->textvars;
        require_once $this->border;
        require_once $this->logcontext;
        require_once $this->ttfotfile;
        require_once $this->destination;
        require_once $this->pdfexception;
        require_once $this->metrixGenerator;
        require_once $this->GlyphOperator;
        require_once $this->ScriptToLang;
        require_once $this->LangToFont;
        require_once $this->barcode;
        
        
        error_reporting(E_ERROR | E_PARSE);
    }

    /**
     * @param \Magento\Sales\Model\Order\Invoice $invoice
     * @return $this
     */
    public function setInvoice(\Magento\Sales\Model\Order\Invoice $invoice)
    {
        $this->invoice = $invoice;
        
        $this->setOrder($invoice->getOrder());
        
        return $this;
    }


    /**
     * @param \Magento\Sales\Model\Order\Shipment $shipment
     * @return $this
     */
    public function setShipment(\Magento\Sales\Model\Order\Shipment $shipment)
    {
        $this->shipment = $shipment;
        
        $this->setOrder($shipment->getOrder());
        
        return $this;
    }

    /**
    * @param \Magento\Sales\Model\Order\Creditmemo $creditmemo
    * @return $this
    */
    public function setCreditMemo(\Magento\Sales\Model\Order\Creditmemo $creditmemo)
    {
        $this->memo = $creditmemo;
        $this->setOrder($creditmemo->getOrder());

        return $this;
    }

    /**
    * @param \Magento\Sales\Model\Order\Creditmemo $creditmemo
    * @return $this
    */
    public function setOrderTemplate(\Magento\Sales\Model\Order $orderTemplate)
    {
        $this->orderTemplate = $orderTemplate;
        
        $this->setOrder($orderTemplate);
        
        return $this;
    }

    /**
     * @param \Magento\Sales\Model\Order $order
     * @return $this
     */
    public function setOrder(\Magento\Sales\Model\Order $order)
    {
        $this->order = $order;
        
        return $this;
    }

    /**
     * @return mixed
     * get the pdf template body
     */
    public function setTemplateData()
    {
    }
    
    /**
     * @param \Mageants\PdfInvoice\Model\Pdftemplate $template
     * @return $this
     */
    public function setTemplate(Pdftemplate $template)
    {
        $this->template = $template;
        $template_data = $this->template->getData();
    
        $helper = $this->helper;
        
        //$template_data = $helper->unserializeSetting($template_data);
        
        $this->template->addData($template_data);
        $this->processor->setPDFTemplate($this->template);
        
        return $this;
    }

    /**
     * Filename of the pdf and the stream to sent to the download
     *
     * @return array
     */
    public function generatePdfData($type='')
    {
        /**transport use to get the variables $order object, $invoice object and the template model object*/
        $parts = $this->_transport($type);
        

        /** instantiate the mPDF class and add the processed html to get the pdf*/
        $applySettings = $this->getPDFSettings($parts);

        $fileParts = [
            'filestream' => $applySettings,
            'filename' => filter_var($parts['filename'], FILTER_SANITIZE_URL)
        ];

        return $fileParts;
    }

    /**
    * Filename of the pdf and the stream to sent to the download
    *
    * @return array
    */
    public function generateEmailPdfData($type='')
    {
        /**transport use to get the variables $order object, $invoice object and the template model object*/
        $parts = $this->_transport($type);
        

        /** instantiate the mPDF class and add the processed html to get the pdf*/
        $applySettings = $this-> getEmailPDFSettings($parts, $type);
        $fileParts = [
            'filestream' => $applySettings,
            'filename' => filter_var($parts['filename'], FILTER_SANITIZE_URL)
        ];

        return $applySettings;
    }


    /**
     *
     * This will proces the template and the variables from the entity's
     *
     * @return array
     */
    protected function _transport($type='')
    {
        if ($type=='invoice') {
            $pdfElement = $this->invoice;
        }

        if ($type=='shipment') {
            $pdfElement =$this->shipment;
        }
        if ($type=='memo') {
            $pdfElement =$this->memo;
        }
        if ($type=='order') {
            $pdfElement = $this->orderTemplate;
        }
        $order = $this->order;
        if ($this->request->getParam('order_id')) {
            $order_id = $this->request->getParam('order_id');
        } else {
            $invoiceVariablesValue = $this->optionManager->get(OptionManager::OPTION_VARIABLE_INVOICE)->toOptionArray();
            foreach ($invoiceVariablesValue as $invoiceVariable) {
                $str = substr($invoiceVariable['value'], 2, -2);
                $newstr = explode('_', $str);
                $parts = preg_split('/\s+/', $str);
                $var_to_set = array_splice($parts, 1);
                $varstr = array_splice($newstr, 1);
                $invoice_variable = implode('_', $varstr);
                if ($invoice_variable == 'order_id') {
                    $orderId = $pdfElement->getData($invoice_variable);
                }
            }
            if (isset($orderId) && $orderId != '') {
                $order_id = $orderId;
            } else {
                $order_id = 0;
            }
        }
        if ($order_id != 0) {
            if ($type=='invoice') {
                $order = $this->orderFactory->create()->load($order_id);
                $history = [];
                $orderComment = [];
                foreach ($order->getInvoiceCollection() as $_invoice) {
                    foreach ($_invoice->getCommentsCollection() as $_comment) {
                        $history[] = $_comment->getComment();
                    }
                }
                $invoiceHistories = [];
                if (!empty($history)) {
                    $totalHistory = count($history);
                    for ($i = ($totalHistory-1); $i >= 0 ; $i--) {
                        $invoiceHistories[] = $history[$i];
                    }
                }
            }
        }
        if (!empty($invoiceHistories)) {
            $comment  = implode(",", $invoiceHistories);
        } else {
            $comment  = ($pdfElement!=null) ? ($pdfElement->getCustomerNoteNotify() ? $pdfElement->getCustomerNote() : '') : '';
        }

        if (!empty($this->shipment)) {
            $ordersshipment = $this->ordersdata->load($this->shipment->getData('order_id'));
            $transport = [
                'order' => $ordersshipment,
                'invoice' => $pdfElement,
                'comment' => str_replace(',', '<br />', $comment),
                'billing' => $order->getBillingAddress(),
                'payment_html' => $this->getPaymentHtml($order),
                'store' => $order->getStore(),
                'formattedShippingAddress' => $this->getFormattedShippingAddress($order),
                'formattedBillingAddress' => $this->getFormattedBillingAddress($order)
            ];
        } elseif (!empty($this->memo)) {
            $ordersmemo = $this->ordersdata->load($this->memo->getData('order_id'));
            $transport = [
                'order' => $ordersmemo,
                'comment' => str_replace(',', '<br />', $comment),
                'billing' => $order->getBillingAddress(),
                'payment_html' => $this->getPaymentHtml($order),
                'store' => $order->getStore(),
                'formattedShippingAddress' => $this->getFormattedShippingAddress($order),
                'formattedBillingAddress' => $this->getFormattedBillingAddress($order)
            ];
        } else {
            $transport = [
                'order' => $order,
                'invoice' => $pdfElement,
                'comment' => str_replace(',', '<br />', $comment),
                'billing' => $order->getBillingAddress(),
                'payment_html' => $this->getPaymentHtml($order),
                'store' => $order->getStore(),
                'formattedShippingAddress' => $this->getFormattedShippingAddress($order),
                'formattedBillingAddress' => $this->getFormattedBillingAddress($order)
            ];
        }

        //$QRCode = new \QRCode;
        //$png = $QRCode->png('this is test');
        $invoiceVariables = $this->optionManager->get(OptionManager::OPTION_VARIABLE_INVOICE)->toOptionArray();
        $shipmentVariables = $this->optionManager->get(OptionManager::OPTION_VARIABLE_SHIPMENT)->toOptionArray();
        $memoVariables = $this->optionManager->get(OptionManager::OPTION_VARIABLE_CREDITMEMO)->toOptionArray();
        $orderVariables = $this->optionManager->get(OptionManager::OPTION_VARIABLE_ORDER)->toOptionArray();
        $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
        $transport[self::COMPANY_NAME]= $this->scopeConfig->getValue(self::COMPANY_NAME, $storeScope);
        $transport[self::COMPANY_ADDRESS]= $this->scopeConfig->getValue(self::COMPANY_ADDRESS, $storeScope);
        $transport[self::VAT_NUMBER]= $this->scopeConfig->getValue(self::VAT_NUMBER, $storeScope);
        $transport[self::VAT_OFFICE]= $this->scopeConfig->getValue(self::VAT_OFFICE, $storeScope);
        $transport[self::BUSINESS_LOGO]= $this->storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA) . 'mageants/pdfinvoice/logo/' . $this->scopeConfig->getValue(self::BUSINESS_LOGO, $storeScope);
        $transport[self::BUSINESS_EMAIL]= $this->scopeConfig->getValue(self::BUSINESS_EMAIL, $storeScope);
        $transport[self::COMPANY_PHONE]= $this->scopeConfig->getValue(self::COMPANY_PHONE, $storeScope);
        $transport[self::COMPANY_FAX]= $this->scopeConfig->getValue(self::COMPANY_FAX, $storeScope);
        $transport[self::NOTES]= $this->scopeConfig->getValue(self::NOTES, $storeScope);
        $transport[self::TERMS_AND_CONDITIONS]= $this->scopeConfig->getValue(self::TERMS_AND_CONDITIONS, $storeScope);
        
        foreach ($invoiceVariables as $invoiceVariable) {
            $str = substr($invoiceVariable['value'], 2, -2);
            $newstr = explode('_', $str);
            $parts = preg_split('/\s+/', $str);
            $var_to_set = array_splice($parts, 1);
            $varstr = array_splice($newstr, 1);
            $invoice_variable = implode('_', $varstr);
            if ($invoice_variable != 'customer_note') {
                if ($pdfElement->getData($invoice_variable)) {
                    if (is_numeric($pdfElement->getData($invoice_variable)) && $invoice_variable!='entity_id' && $invoice_variable!='store_id' && $invoice_variable!='billing_address_id' && $invoice_variable!='order_id' && $invoice_variable!='state' && $invoice_variable!='shipping_address_id' && $invoice_variable!='increment_id' && $invoice_variable!='increment_id' && $invoice_variable != 'store_to_order_rate') {
                        $transport[implode("_", $var_to_set)] = $this->priceHelper->currency($pdfElement->getData($invoice_variable), true, false);
                    } else {
                        $transport[implode("_", $var_to_set)] = $pdfElement->getData($invoice_variable);
                    }
                }
            }
        }
        foreach ($shipmentVariables as $shipmentVariable) {
            $str = substr($shipmentVariable['value'], 2, -2);
            $newstr = explode('_', $str);
            $parts = preg_split('/\s+/', $str);

            $var_to_set = array_splice($parts, 1);
            $varstr = array_splice($newstr, 1);
            $shipment_variable = implode('_', $varstr);
            
            if ($pdfElement->getData($shipment_variable)) {
                $transport[implode("_", $var_to_set)] = $pdfElement->getData($shipment_variable);
            }
        }
        foreach ($memoVariables as $memoVariable) {
            $str = substr($memoVariable['value'], 2, -2);
            $newstr = explode('_', $str);
            $parts = preg_split('/\s+/', $str);

            $var_to_set = array_splice($parts, 1);
            $varstr = array_splice($newstr, 1);
            $ordervar = implode('_', $varstr);
            
            if ($pdfElement->getData($ordervar)) {
                if (is_numeric($pdfElement->getData($ordervar)) && $ordervar!='entity_id' && $ordervar!='store_id' && $ordervar!='billing_address_id' && $ordervar!='order_id' && $ordervar!='state' && $ordervar!='shipping_address_id' && $memoVariable!='increment_id' && $ordervar!='increment_id' && $ordervar != 'store_to_order_rate') {
                    $transport[implode("_", $var_to_set)] = $this->priceHelper->currency($pdfElement->getData($ordervar), true, false);
                } else {
                    $transport[implode("_", $var_to_set)] = $pdfElement->getData($ordervar);
                }
            }
        }

        foreach ($orderVariables as $orderVariable) {
            $str = substr($orderVariable['value'], 2, -2);
            $newstr = explode('_', $str);
            $parts = preg_split('/\s+/', $str);
            
            $var_to_set = array_splice($parts, 1);

            $varstr = array_splice($newstr, 1);
            $orderVariable = implode('_', $varstr);
            
            if ($pdfElement->getBillingAddress()) {
                $transport['order_billing_address'] =  $this->addressRenderer->format($pdfElement->getBillingAddress(), 'html');
            }
            if ($pdfElement->getShippingAddress()) {
                $transport['order_shipping_address'] =  $this->addressRenderer->format($pdfElement->getShippingAddress(), 'html');
            }
            if ($pdfElement->getData($orderVariable)) {
                if (is_numeric($pdfElement->getData($orderVariable)) && $orderVariable!='entity_id' && $orderVariable!='store_id' && $orderVariable!='customer_id' && $orderVariable!='store_to_order_rate' && $orderVariable!='total_qty_ordered' && $orderVariable!='customer_note_notify' && $orderVariable!='billing_address_id' && $orderVariable!='customer_group_id' && $orderVariable != 'send_email' &&  $orderVariable != 'shipping_address_id' && $orderVariable != 'weight' && $orderVariable != 'increment_id' && $orderVariable != 'total_item_count' && $orderVariable != 'customer_gender') {
                    $transport[implode("_", $var_to_set)] = $this->priceHelper->currency($pdfElement->getData($orderVariable), true, false);
                } else {
                    $transport[implode("_", $var_to_set)] = $pdfElement->getData($orderVariable);
                }
            }
            if ($orderVariable=='payment_method') {
                if ($pdfElement->getPayment()) {
                    $transport['order_payment_method']=$pdfElement->getPayment()->getMethod();
                }
            }
        }
        $processor = $this->processor;
        
        $processor->setVariables($transport);
        
        $processor->setTemplate($this->template);
        
        $parts = $processor->processTemplate($type);

        return $parts;
    }

    /**
     * @param $parts
     * @return object
     */
    protected function getPDFSettings($parts)
    {
        $templateModel = $this->template;
        $xpos ='';
        $ypos = '';

        if ($this->shipment) {
            $increment_id = $this->shipment->getData('increment_id');
            if ((int)$this->template->getData('shipment_horizontal_barcode') > 0) {
                $xpos =$this->template->getData('shipment_horizontal_barcode');
            }
            if ((int)$this->template->getData('shipment_vertical_barcode') > 0) {
                $ypos =$this->template->getData('shipment_vertical_barcode');
            }
        }

        if ($this->invoice) {
            $increment_id = $this->invoice->getData('increment_id');
            if ((int)$this->template->getData('invoice_horizontal_barcode') > 0) {
                $xpos =$this->template->getData('invoice_horizontal_barcode');
            }
            if ((int)$this->template->getData('invoice_vertical_barcode') > 0) {
                $ypos =$this->template->getData('invoice_vertical_barcode');
            }
        }

        if ($this->memo) {
            $increment_id = $this->memo->getData('increment_id');
            if ((int)$this->template->getData('memo_horizontal_barcode') > 0) {
                $xpos =$this->template->getData('memo_horizontal_barcode');
            }
            if ((int)$this->template->getData('memo_vertical_barcode') > 0) {
                $ypos =$this->template->getData('memo_vertical_barcode');
            }
        }

        if ($this->orderTemplate) {
            $increment_id = $this->orderTemplate->getData('increment_id');
            if ((int)$this->template->getData('order_horizontal_barcode') > 0) {
                $xpos =$this->template->getData('order_horizontal_barcode');
            }
            if ((int)$this->template->getData('order_horizontal_barcode') > 0) {
                $ypos =$this->template->getData('order_horizontal_barcode');
            }
        }
        // print_r($this->shipment->getData());
        $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
        $fontSize = $this->scopeConfig->getValue(self::FONTSIZE, $storeScope);
        if ($fontSize == '') {
            $fontSize = 10;
        }
        $config = [
            'mode' => '',
            'format' => self::PAPER_SIZE[$this->scopeConfig->getValue(self::PAPERSIZE, $storeScope)],
            'default_font_size' => $fontSize,
            'default_font' => $this->scopeConfig->getValue(self::FONTS, $storeScope),
            'margin_left' => $this->scopeConfig->getValue(self::LEFT_MARGIN, $storeScope),
            'margin_right' => $this->scopeConfig->getValue(self::RIGHT_MARGIN, $storeScope),
            'margin_top' => $this->scopeConfig->getValue(self::TOP_MARGIN, $storeScope),
            'margin_bottom' => $this->scopeConfig->getValue(self::BOTTOM_MARGIN, $storeScope),
            'allow_charset_conversion' => true,
            'orientation' => self::PAPER_ORI[$this->scopeConfig->getValue(self::ORIENTATION, $storeScope)],
            'showBarcodeNumbers'=>false
        ];

        $pdf = new \Mpdf\Mpdf($config);
        $pdf->charset_in = 'UTF-8';
        $pdf->SetDirectionality($this->scopeConfig->getValue(self::SCRIPT_DIR, $storeScope));
        $fontdata = $this->scopeConfig->getValue(self::FONTS, $storeScope);
        $fonttoapply=array();
        foreach ($this->fontlist as $font_list) {
            if ($font_list['value']==$fontdata) {
                $fonttoapply[$fontdata]=$font_list['label'];
                break;
            }
        }
        $pdf->autoScriptToLang = true;
        $pdf->autoLangToFont   = true;
      
        foreach ($fonttoapply as $f => $fs) {
            // add to fontdata array
            $pdf->fontdata[$fs] = $f;

            // add to available fonts array
            foreach (['R', 'B', 'I', 'BI'] as $style) {
                if (isset($fs[$style]) && $fs[$style]) {
                    $pdf->available_unifonts[] = $f . trim($style, 'R');
                }
            }
        }
        $pdf->SetHTMLHeader($parts['header']);
        $pdf->SetHTMLFooter($parts['footer']);
        $pdf->WriteHTML(html_entity_decode($parts["body"]));
        if ($this->scopeConfig->getValue(self::SHOW_BARCODE, $storeScope)) {
            $pdf->writeBarcode($increment_id, $this->scopeConfig->getValue(self::SHOW_TEXT_BARCODE, $storeScope), $xpos, $ypos, $this->scopeConfig->getValue(self::SIZE_BARCODE, $storeScope), 0, 1, 1, 2, 2, $this->scopeConfig->getValue(self::HEIGHT_BARCODE, $storeScope), false, false, $this->scopeConfig->getValue(self::TYPE_BARCODE, $storeScope), '0', '', 1);
        }

        $pdfToOutput = $pdf->Output('', 'S');

        return $pdfToOutput;
    }

    /**
    * @param $parts
    * @return object
    */
    protected function getEmailPDFSettings($parts, $type='')
    {
        $templateModel = $this->template;
    
        $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;

        $fontSize = $this->scopeConfig->getValue(self::FONTSIZE, $storeScope);
        if ($fontSize == '') {
            $fontSize = 10;
        }
        if ($this->orderTemplate) {
            $increment_id = $this->orderTemplate->getData('increment_id');
            if ((int)$this->template->getData('order_horizontal_barcode') > 0) {
                $xpos =$this->template->getData('order_horizontal_barcode');
            }
            if ((int)$this->template->getData('order_horizontal_barcode') > 0) {
                $ypos =$this->template->getData('order_horizontal_barcode');
            }
        }

        $config = [
            'mode' => '',
            'format' => self::PAPER_SIZE[$this->scopeConfig->getValue(self::PAPERSIZE, $storeScope)],
            'default_font_size' => $fontSize,
            'default_font' => $this->scopeConfig->getValue(self::FONTS, $storeScope),
            'margin_left' => $this->scopeConfig->getValue(self::LEFT_MARGIN, $storeScope),
            'margin_right' => $this->scopeConfig->getValue(self::RIGHT_MARGIN, $storeScope),
            'margin_top' => $this->scopeConfig->getValue(self::TOP_MARGIN, $storeScope),
            'margin_bottom' => $this->scopeConfig->getValue(self::BOTTOM_MARGIN, $storeScope),
            'allow_charset_conversion' => true,
            'orientation' => self::PAPER_ORI[$this->scopeConfig->getValue(self::ORIENTATION, $storeScope)]
        ];

        $pdf = new \Mpdf\Mpdf($config);
        $pdf->charset_in = 'UTF-8';
        $pdf->SetDirectionality($this->scopeConfig->getValue(self::SCRIPT_DIR, $storeScope));
        $fontdata = $this->scopeConfig->getValue(self::FONTS, $storeScope);
        $fonttoapply=array();
        foreach ($this->fontlist as $font_list) {
            if ($font_list['value']==$fontdata) {
                $fonttoapply[$fontdata]=$font_list['label'];
                break;
            }
        }
        $pdf->autoScriptToLang = true;
        $pdf->autoLangToFont   = true;
      
        foreach ($fonttoapply as $f => $fs) {
            // add to fontdata array
            $pdf->fontdata[$fs] = $f;

            // add to available fonts array
            foreach (['R', 'B', 'I', 'BI'] as $style) {
                if (isset($fs[$style]) && $fs[$style]) {
                    // warning: no suffix for regular style! hours wasted: 2
                    $pdf->available_unifonts[] = $f . trim($style, 'R');
                }
            }
        }
        $pdf->SetHTMLHeader($parts['header']);
        $pdf->SetHTMLFooter($parts['footer']);
        $pdf->WriteHTML(html_entity_decode($parts["body"]));

        if ($this->scopeConfig->getValue(self::SHOW_BARCODE, $storeScope)) {
            $pdf->writeBarcode($increment_id, $this->scopeConfig->getValue(self::SHOW_TEXT_BARCODE, $storeScope), $xpos, $ypos, $this->scopeConfig->getValue(self::SIZE_BARCODE, $storeScope), 0, 1, 1, 2, 2, $this->scopeConfig->getValue(self::HEIGHT_BARCODE, $storeScope), false, false, $this->scopeConfig->getValue(self::TYPE_BARCODE, $storeScope), '0', '', 1);
        }
        $pdfname = $type.$this->datetime->date('Y-m-d_H-i-s').'.pdf';
        $pdfToOutput = $pdf->Output(DirectoryList::VAR_DIR.'/'.$pdfname, 'F');

        return $pdfname;
    }


    /**
     * Get the format and orientation, ex: A4-L
     * @param $form
     * @param $ori
     * @return string
     */
    private function paperFormat($form, $ori)
    {
        $size = self::PAPER_SIZE;
        $oris = self::PAPER_ORI;

        if ($ori == Orientation::USE_VERTICLE) {
            return str_replace('-', '', $size[$form]);
        }

        $format = $size[$form] . $oris[$ori];

        return $format;
    }


    /**
     * @param \Magento\Sales\Model\Order $order
     * @return mixed
     */
    protected function getPaymentHtml(\Magento\Sales\Model\Order $order)
    {
        return $this->paymentHelper->getInfoBlockHtml(
            $order->getPayment(),
            $this->identityContainer->getStore()->getStoreId()
        );
    }

    /**
     * @param \Magento\Sales\Model\Order $order
     * @return null
     */
    protected function getFormattedShippingAddress(\Magento\Sales\Model\Order $order)
    {
        return $order->getIsVirtual()
            ? null
            : $this->addressRenderer->format($order->getShippingAddress(), 'html');
    }

    /**
     * @param \Magento\Sales\Model\Order $order
     * @return mixed
     */
    protected function getFormattedBillingAddress(\Magento\Sales\Model\Order $order)
    {
        return $this->addressRenderer->format($order->getBillingAddress(), 'html');
    }
    
    /**
    * @param \Magento\Sales\Model\Order\Creditmemo $creditmemo
    * @return $this
    */
    public function generateMassOrderPdf($massOrderIds, $orderTemplate)
    {
        $pdfOrdersData = array();

        $pdfOrdersData = $this->generatePdfDataMass('order', $massOrderIds, $orderTemplate);
        
        return $pdfOrdersData;
    }

    public function generateMassInvoicePdf($massOrderIds, $orderTemplate)
    {
        $pdfOrdersData = array();

        $pdfOrdersData = $this->generatePdfDataMass('invoice', $massOrderIds, $orderTemplate);
        
        return $pdfOrdersData;
    }

    public function generateMassShipmentPdf($massOrderIds, $orderTemplate)
    {
        $pdfOrdersData = array();

        $pdfOrdersData = $this->generatePdfDataMass('shipment', $massOrderIds, $orderTemplate);
        
        return $pdfOrdersData;
    }

    public function generateMassCreditMemoPdf($massOrderIds, $orderTemplate)
    {
        $pdfOrdersData = array();

        $pdfOrdersData = $this->generatePdfDataMass('memo', $massOrderIds, $orderTemplate);
        
        return $pdfOrdersData;
    }


    /**
     * Filename of the pdf and the stream to sent to the download
     *
     * @return array
     */
    public function generatePdfDataMass($type='', $ordrIds, $pdfTemplate)
    {
        /** instantiate the mPDF class and add the processed html to get the pdf*/
        if ($type == "invoice") {
            $applySettings = $this->getPDFSettingsMassInvoice($type, $ordrIds, $pdfTemplate);
        } elseif ($type == "shipment") {
            $applySettings = $this->getPDFSettingsMassShipment($type, $ordrIds, $pdfTemplate);
        } elseif ($type == "memo") {
            $applySettings = $this->getPDFSettingsMassCreditMemo($type, $ordrIds, $pdfTemplate);
        } else {
            $applySettings = $this->getPDFSettingsMass($type, $ordrIds, $pdfTemplate);
        }

        $fileParts = [
            'filestream' => $applySettings,
            'filename' => filter_var($parts['filename'], FILTER_SANITIZE_URL)
        ];

        return $fileParts;
    }

    /**
     * @param $parts
     * @return object
     */
    protected function getPDFSettingsMass($type, $massOrdrIds, $orderTemplate)
    {
        $maxMassOrdrIds = count($massOrdrIds);

        $maxMassOrdrIdKey = 1;

        foreach ($massOrdrIds as $massOrderIdSingle) {
             
            //fetch whole order information
            $orders = $this->orderInterface->load($massOrderIdSingle);
         
            $this->setOrderTemplate($orders);
            
            $this->setTemplate($orderTemplate);

            $parts = $this->_transport($type);
            
            $templateModel = $this->template;
            $xpos ='';
            $ypos = '';

            if ($this->orderTemplate) {
                $increment_id = $this->orderTemplate->getData('increment_id');
                if ((int)$this->template->getData('order_horizontal_barcode') > 0) {
                    $xpos =$this->template->getData('order_horizontal_barcode');
                }
                if ((int)$this->template->getData('order_horizontal_barcode') > 0) {
                    $ypos =$this->template->getData('order_horizontal_barcode');
                }
            }

            $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;

            $fontSize = $this->scopeConfig->getValue(self::FONTSIZE, $storeScope);
            if ($fontSize == '') {
                $fontSize = 10;
            }
            $config = [
                'mode' => '',
                'format' => self::PAPER_SIZE[$this->scopeConfig->getValue(self::PAPERSIZE, $storeScope)],
                'default_font_size' => $fontSize,
                'default_font' => $this->scopeConfig->getValue(self::FONTS, $storeScope),
                'margin_left' => $this->scopeConfig->getValue(self::LEFT_MARGIN, $storeScope),
                'margin_right' => $this->scopeConfig->getValue(self::RIGHT_MARGIN, $storeScope),
                'margin_top' => $this->scopeConfig->getValue(self::TOP_MARGIN, $storeScope),
                'margin_bottom' => $this->scopeConfig->getValue(self::BOTTOM_MARGIN, $storeScope),
                'allow_charset_conversion' => true,
                'orientation' => self::PAPER_ORI[$this->scopeConfig->getValue(self::ORIENTATION, $storeScope)],
                'showBarcodeNumbers'=>false
            ];


            // Create pdf for first time
            if ($maxMassOrdrIdKey == 1) {
                $pdf = new \Mpdf\Mpdf($config);
            }

            $pdf->charset_in = 'UTF-8';
            $pdf->SetDirectionality($this->scopeConfig->getValue(self::SCRIPT_DIR, $storeScope));
            $fontdata = $this->scopeConfig->getValue(self::FONTS, $storeScope);
            $fonttoapply=array();
            foreach ($this->fontlist as $font_list) {
                if ($font_list['value']==$fontdata) {
                    $fonttoapply[$fontdata]=$font_list['label'];
                    break;
                }
            }
            $pdf->autoScriptToLang = true;
            $pdf->autoLangToFont   = true;
          
            foreach ($fonttoapply as $f => $fs) {
                // add to fontdata array
                $pdf->fontdata[$fs] = $f;

                // add to available fonts array
                foreach (['R', 'B', 'I', 'BI'] as $style) {
                    if (isset($fs[$style]) && $fs[$style]) {
                        // warning: no suffix for regular style! hours wasted: 2
                        $pdf->available_unifonts[] = $f . trim($style, 'R');
                    }
                }
            }

            // set header, footer and body for first time
            if ($maxMassOrdrIdKey == 1) {
                $pdf->SetHTMLHeader($parts['header']);
                $pdf->SetHTMLFooter($parts['footer']);
                $pdf->WriteHTML(html_entity_decode($parts["body"]));
            }
            if ($this->scopeConfig->getValue(self::SHOW_BARCODE, $storeScope)) {
                $pdf->writeBarcode($increment_id, $this->scopeConfig->getValue(self::SHOW_TEXT_BARCODE, $storeScope), $xpos, $ypos, $this->scopeConfig->getValue(self::SIZE_BARCODE, $storeScope), 0, 1, 1, 2, 2, $this->scopeConfig->getValue(self::HEIGHT_BARCODE, $storeScope), false, false, $this->scopeConfig->getValue(self::TYPE_BARCODE, $storeScope), '0', '', 1);
            }

            // write additional pages body to pdf
            if ($maxMassOrdrIdKey != 1) {
                $pdf->WriteHTML(html_entity_decode($parts["body"]));
            }

            // add blank page for next orders
            if ($maxMassOrdrIdKey < $maxMassOrdrIds) {
                $pdf->AddPage($config);
            }

            $maxMassOrdrIdKey++;
        }
        $pdfToOutput = $pdf->Output('', 'S');
        return $pdfToOutput;
    }

    /**
     * @param $parts
     * @return object
     */
    protected function getPDFSettingsMassInvoice($type, $massInvoiceIds, $pdfTemplate)
    {
        $maxMassInvoiceIds = count($massInvoiceIds);

        $maxMassInvoiceIdKey = 1;
        foreach ($massInvoiceIds as $massInvoiceIdSingle) {
            $Invoice = $this->invoiceRepository->get($massInvoiceIdSingle);

            $this->request->setParam('invoice_id', $massInvoiceIdSingle);
         
            $this->setInvoice($Invoice);
            
            $this->setTemplate($pdfTemplate);

            $parts = $this->_transport($type);

            $templateModel = $this->template;
            $xpos ='';
            $ypos = '';

            if ($this->invoice) {
                $increment_id = $this->invoice->getData('increment_id');
                if ((int)$this->template->getData('invoice_horizontal_barcode') > 0) {
                    $xpos =$this->template->getData('invoice_horizontal_barcode');
                }
                if ((int)$this->template->getData('invoice_vertical_barcode') > 0) {
                    $ypos =$this->template->getData('invoice_vertical_barcode');
                }
            }
            $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;

            $fontSize = $this->scopeConfig->getValue(self::FONTSIZE, $storeScope);
            if ($fontSize == '') {
                $fontSize = 10;
            }
            $config = [
                'mode' => '',
                'format' => self::PAPER_SIZE[$this->scopeConfig->getValue(self::PAPERSIZE, $storeScope)],
                'default_font_size' => $fontSize,
                'default_font' => $this->scopeConfig->getValue(self::FONTS, $storeScope),
                'margin_left' => $this->scopeConfig->getValue(self::LEFT_MARGIN, $storeScope),
                'margin_right' => $this->scopeConfig->getValue(self::RIGHT_MARGIN, $storeScope),
                'margin_top' => $this->scopeConfig->getValue(self::TOP_MARGIN, $storeScope),
                'margin_bottom' => $this->scopeConfig->getValue(self::BOTTOM_MARGIN, $storeScope),
                'allow_charset_conversion' => true,
                'orientation' => self::PAPER_ORI[$this->scopeConfig->getValue(self::ORIENTATION, $storeScope)],
                'showBarcodeNumbers'=>false
            ];


            // Create pdf for first time
            if ($maxMassInvoiceIdKey == 1) {
                $pdf = new \Mpdf\Mpdf($config);
            }

            $pdf->charset_in = 'UTF-8';
            $pdf->SetDirectionality($this->scopeConfig->getValue(self::SCRIPT_DIR, $storeScope));
            $fontdata = $this->scopeConfig->getValue(self::FONTS, $storeScope);
            $fonttoapply=array();
            foreach ($this->fontlist as $font_list) {
                if ($font_list['value']==$fontdata) {
                    $fonttoapply[$fontdata]=$font_list['label'];
                    break;
                }
            }
            $pdf->autoScriptToLang = true;
            $pdf->autoLangToFont   = true;
          
            foreach ($fonttoapply as $f => $fs) {
                // add to fontdata array
                $pdf->fontdata[$fs] = $f;

                // add to available fonts array
                foreach (['R', 'B', 'I', 'BI'] as $style) {
                    if (isset($fs[$style]) && $fs[$style]) {
                        // warning: no suffix for regular style! hours wasted: 2
                        $pdf->available_unifonts[] = $f . trim($style, 'R');
                    }
                }
            }

            // set header, footer and body for first time
            if ($maxMassInvoiceIdKey == 1) {
                $pdf->SetHTMLHeader($parts['header']);
                $pdf->SetHTMLFooter($parts['footer']);
                $pdf->WriteHTML(html_entity_decode($parts["body"]));
            }
            if ($this->scopeConfig->getValue(self::SHOW_BARCODE, $storeScope)) {
                $pdf->writeBarcode($increment_id, $this->scopeConfig->getValue(self::SHOW_TEXT_BARCODE, $storeScope), $xpos, $ypos, $this->scopeConfig->getValue(self::SIZE_BARCODE, $storeScope), 0, 1, 1, 2, 2, $this->scopeConfig->getValue(self::HEIGHT_BARCODE, $storeScope), false, false, $this->scopeConfig->getValue(self::TYPE_BARCODE, $storeScope), '0', '', 1);
            }

            // write additional pages body to pdf
            if ($maxMassInvoiceIdKey != 1) {
                $pdf->WriteHTML(html_entity_decode($parts["body"]));
            }

            // add blank page for next orders
            if ($maxMassInvoiceIdKey < $maxMassInvoiceIds) {
                $pdf->AddPage($config);
            }

            $maxMassInvoiceIdKey++;
        }
        $pdfToOutput = $pdf->Output('', 'S');
        return $pdfToOutput;
    }
    /**
     * @param $parts
     * @return object
     */
    protected function getPDFSettingsMassShipment($type, $massShipmentIds, $pdfTemplate)
    {
        $maxMassShipmentIds = count($massShipmentIds);
        $maxMassShipmentIdKey = 1;
        foreach ($massShipmentIds as $massShipmentIdSingle) {
            $shipment = $this->modelShipment->load($massShipmentIdSingle);

            $this->request->setParam('shipment_id', $massShipmentIdSingle);

            $this->setShipment($shipment);
            
            $this->setTemplate($pdfTemplate);

            $parts = $this->_transport($type);

            $templateModel = $this->template;
            $xpos ='';
            $ypos = '';

          
            if ($this->shipment) {
                $increment_id = $this->shipment->getData('increment_id');
                if ((int)$this->template->getData('shipment_horizontal_barcode') > 0) {
                    $xpos =$this->template->getData('shipment_horizontal_barcode');
                }
                if ((int)$this->template->getData('shipment_vertical_barcode') > 0) {
                    $ypos =$this->template->getData('shipment_vertical_barcode');
                }
            }
            $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;

            $fontSize = $this->scopeConfig->getValue(self::FONTSIZE, $storeScope);
            if ($fontSize == '') {
                $fontSize = 10;
            }
            $config = [
                'mode' => '',
                'format' => self::PAPER_SIZE[$this->scopeConfig->getValue(self::PAPERSIZE, $storeScope)],
                'default_font_size' => $fontSize,
                'default_font' => $this->scopeConfig->getValue(self::FONTS, $storeScope),
                'margin_left' => $this->scopeConfig->getValue(self::LEFT_MARGIN, $storeScope),
                'margin_right' => $this->scopeConfig->getValue(self::RIGHT_MARGIN, $storeScope),
                'margin_top' => $this->scopeConfig->getValue(self::TOP_MARGIN, $storeScope),
                'margin_bottom' => $this->scopeConfig->getValue(self::BOTTOM_MARGIN, $storeScope),
                'allow_charset_conversion' => true,
                'orientation' => self::PAPER_ORI[$this->scopeConfig->getValue(self::ORIENTATION, $storeScope)],
                'showBarcodeNumbers'=>false
            ];


            // Create pdf for first time
            if ($maxMassShipmentIdKey == 1) {
                $pdf = new \Mpdf\Mpdf($config);
            }

            $pdf->charset_in = 'UTF-8';
            $pdf->SetDirectionality($this->scopeConfig->getValue(self::SCRIPT_DIR, $storeScope));
            $fontdata = $this->scopeConfig->getValue(self::FONTS, $storeScope);
            $fonttoapply=array();
            foreach ($this->fontlist as $font_list) {
                if ($font_list['value']==$fontdata) {
                    $fonttoapply[$fontdata]=$font_list['label'];
                    break;
                }
            }
            $pdf->autoScriptToLang = true;
            $pdf->autoLangToFont   = true;
          
            foreach ($fonttoapply as $f => $fs) {
                // add to fontdata array
                $pdf->fontdata[$fs] = $f;

                // add to available fonts array
                foreach (['R', 'B', 'I', 'BI'] as $style) {
                    if (isset($fs[$style]) && $fs[$style]) {
                        // warning: no suffix for regular style! hours wasted: 2
                        $pdf->available_unifonts[] = $f . trim($style, 'R');
                    }
                }
            }

            // set header, footer and body for first time
            if ($maxMassShipmentIdKey == 1) {
                $pdf->SetHTMLHeader($parts['header']);
                $pdf->SetHTMLFooter($parts['footer']);
                $pdf->WriteHTML(html_entity_decode($parts["body"]));
            }
            if ($this->scopeConfig->getValue(self::SHOW_BARCODE, $storeScope)) {
                $pdf->writeBarcode($increment_id, $this->scopeConfig->getValue(self::SHOW_TEXT_BARCODE, $storeScope), $xpos, $ypos, $this->scopeConfig->getValue(self::SIZE_BARCODE, $storeScope), 0, 1, 1, 2, 2, $this->scopeConfig->getValue(self::HEIGHT_BARCODE, $storeScope), false, false, $this->scopeConfig->getValue(self::TYPE_BARCODE, $storeScope), '0', '', 1);
            }

            // write additional pages body to pdf
            if ($maxMassShipmentIdKey != 1) {
                $pdf->WriteHTML(html_entity_decode($parts["body"]));
            }

            // add blank page for next orders
            if ($maxMassShipmentIdKey < $maxMassShipmentIds) {
                $pdf->AddPage($config);
            }

            $maxMassShipmentIdKey++;
        }
        $pdfToOutput = $pdf->Output('', 'S');
        return $pdfToOutput;
    }
    /**
     * @param $parts
     * @return object
     */
    protected function getPDFSettingsMassCreditMemo($type, $massCreditMemoIds, $pdfTemplate)
    {
        $maxMassCreditMemoIds = count($massCreditMemoIds);

        $maxMassCreditMemoIdKey = 1;
        foreach ($massCreditMemoIds as $massCreditMemoIdSingle) {
            $creditMemo = $this->modelCreditmemo->load($massCreditMemoIdSingle);

            $this->request->setParam('creditmemo_id', $massCreditMemoIdSingle);

            $this->setCreditMemo($creditMemo);
            
            $this->setTemplate($pdfTemplate);

            $parts = $this->_transport($type);

            $templateModel = $this->template;
            $xpos ='';
            $ypos = '';
            
            if ($this->memo) {
                $increment_id = $this->memo->getData('increment_id');
                if ((int)$this->template->getData('memo_horizontal_barcode') > 0) {
                    $xpos =$this->template->getData('memo_horizontal_barcode');
                }
                if ((int)$this->template->getData('memo_vertical_barcode') > 0) {
                    $ypos =$this->template->getData('memo_vertical_barcode');
                }
            }

            $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;

            $fontSize = $this->scopeConfig->getValue(self::FONTSIZE, $storeScope);
            if ($fontSize == '') {
                $fontSize = 10;
            }
            $config = [
                'mode' => '',
                'format' => self::PAPER_SIZE[$this->scopeConfig->getValue(self::PAPERSIZE, $storeScope)],
                'default_font_size' => $fontSize,
                'default_font' => $this->scopeConfig->getValue(self::FONTS, $storeScope),
                'margin_left' => $this->scopeConfig->getValue(self::LEFT_MARGIN, $storeScope),
                'margin_right' => $this->scopeConfig->getValue(self::RIGHT_MARGIN, $storeScope),
                'margin_top' => $this->scopeConfig->getValue(self::TOP_MARGIN, $storeScope),
                'margin_bottom' => $this->scopeConfig->getValue(self::BOTTOM_MARGIN, $storeScope),
                'allow_charset_conversion' => true,
                'orientation' => self::PAPER_ORI[$this->scopeConfig->getValue(self::ORIENTATION, $storeScope)],
                'showBarcodeNumbers'=>false
            ];


            // Create pdf for first time
            if ($maxMassCreditMemoIdKey == 1) {
                $pdf = new \Mpdf\Mpdf($config);
            }

            $pdf->charset_in = 'UTF-8';
            $pdf->SetDirectionality($this->scopeConfig->getValue(self::SCRIPT_DIR, $storeScope));
            $fontdata = $this->scopeConfig->getValue(self::FONTS, $storeScope);
            $fonttoapply=array();
            foreach ($this->fontlist as $font_list) {
                if ($font_list['value']==$fontdata) {
                    $fonttoapply[$fontdata]=$font_list['label'];
                    break;
                }
            }
            $pdf->autoScriptToLang = true;
            $pdf->autoLangToFont   = true;
          
            foreach ($fonttoapply as $f => $fs) {
                // add to fontdata array
                $pdf->fontdata[$fs] = $f;

                // add to available fonts array
                foreach (['R', 'B', 'I', 'BI'] as $style) {
                    if (isset($fs[$style]) && $fs[$style]) {
                        // warning: no suffix for regular style! hours wasted: 2
                        $pdf->available_unifonts[] = $f . trim($style, 'R');
                    }
                }
            }

            // set header, footer and body for first time
            if ($maxMassCreditMemoIdKey == 1) {
                $pdf->SetHTMLHeader($parts['header']);
                $pdf->SetHTMLFooter($parts['footer']);
                $pdf->WriteHTML(html_entity_decode($parts["body"]));
            }
            if ($this->scopeConfig->getValue(self::SHOW_BARCODE, $storeScope)) {
                $pdf->writeBarcode($increment_id, $this->scopeConfig->getValue(self::SHOW_TEXT_BARCODE, $storeScope), $xpos, $ypos, $this->scopeConfig->getValue(self::SIZE_BARCODE, $storeScope), 0, 1, 1, 2, 2, $this->scopeConfig->getValue(self::HEIGHT_BARCODE, $storeScope), false, false, $this->scopeConfig->getValue(self::TYPE_BARCODE, $storeScope), '0', '', 1);
            }

            // write additional pages body to pdf
            if ($maxMassCreditMemoIdKey != 1) {
                $pdf->WriteHTML(html_entity_decode($parts["body"]));
            }

            // add blank page for next orders
            if ($maxMassCreditMemoIdKey < $maxMassCreditMemoIds) {
                $pdf->AddPage($config);
            }

            $maxMassCreditMemoIdKey++;
        }
        $pdfToOutput = $pdf->Output('', 'S');
        return $pdfToOutput;
    }
}
