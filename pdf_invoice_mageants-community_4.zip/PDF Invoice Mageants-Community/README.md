# PDF invoice


	Current version number: 2.0.7
	Date :- 25/04/2023
	************************************************************
    Bug fixed
	************************************************************
    -> Make extension compatible with magento 2.4.6 version.
	************************************************************

***************************************************************************************************************************************************************************************

	Current version number: 2.0.6
	Date:- 29/03/2023
	****************************************************************
	Coding standard and Compatible with Hyva
	****************************************************************
	--> Mageants team make extension compatible with magento coding standard and compatible with hyva theme.

***************************************************************************************************************************************************************************************

	Current version number: 2.0.5
	Date:- 22/06/2022
	****************************************************************
	Bug fixed
	****************************************************************
	--> When multiple product added in order then all product display in single pdf page now MageAnts team set limited product show in single page.

	****************************************************************
	File Changes
	****************************************************************
	- lib/internal/Pdf_templates/Template01.html
	- lib/internal/Pdf_templates/Template02.html
	- lib/internal/Pdf_templates/Template03.html
	- lib/internal/Pdf_templates/Template04.html
	- Mageants/PdfInvoice/view/frontend/templates/email/items.phtml
	- Mageants/PdfInvoice/view/frontend/templates/email//items/order/default.phtml
	- Mageants/PdfInvoice/view/frontend/layout/sales_email_order_renderers_pdf.xml
	- Mageants/PdfInvoice/view/frontend/layout/mageants_sales_email_order_items_pdf.xml 
	- Mageants/PdfInvoice/composer.json
	- Mageants/PdfInvoice/etc/module.xml

***************************************************************************************************************************************************************************************	

	Current version number: 2.0.4
	Date:- 21/05/2021
	****************************************************************
	Bug fixed
	****************************************************************
	--> E-Mail Functionality was not working when attaching pdf in Email.
	--> Product not display in pdf of Invoice, Shipping and Credit Memo in Magento2.4 version.
	--> Make store wise configuration working in all version.

	****************************************************************
	File Changes
	****************************************************************
	- Mageants/PdfInvoice/Model/PdfRenderer.php
	- Mageants/PdfInvoice/etc/adminhtml/system.xml
	- Mageants/PdfInvoice/etc/adminhtml/events.xml
	- Mageants/PdfInvoice/Observer/CreditmemoSaveObserver.php
    - Mageants/PdfInvoice/Observer/ShipmentSaveObserver.php
    - Mageants/PdfInvoice/view/frontend/templates/items.phtml
	- Mageants/PdfInvoice/Helper/Pdf.php
	- Mageants/PdfInvoice/Controller/Adminhtml/Order/Invoice/Printgridinvoices.php
	- Mageants/PdfInvoice/Controller/Adminhtml/Order/Shipment/Printordershipments.php
	- Mageants/PdfInvoice/Controller/Adminhtml/Order/Creditmemo/Printordercreditmemos.php
	- Mageants/PdfInvoice/view/adminhtml/ui_component/sales_order_view_shipment_grid.xml
	- Mageants/PdfInvoice/view/adminhtml/ui_component/sales_order_view_invoice_grid.xml
	- Mageants/PdfInvoice/view/adminhtml/ui_component/sales_order_view_creditmemo_grid.xml
	- Mageants/PdfInvoice/view/frontend/layout/mageants_sales_email_order_creditmemo_items.xml
	- Mageants/PdfInvoice/view/frontend/layout/mageants_sales_email_order_shipment_items.xml
	- Mageants/PdfInvoice/view/frontend/layout/mageants_sales_email_order_invoice_items.xml
	- Mageants/PdfInvoice/composer.json
	- Mageants/PdfInvoice/etc/module.xml

***************************************************************************************************************************************************************************************	

	Current version number: 2.0.3
	Date:- 20/11/2019
	****************************************************************
	New feature
	****************************************************************
	--> Mageants add 'Customer notes' in invoice variable now admin also add customer notes(invoice comment) in pdf invoice. - https://nimb.ws/v4Djhe
	--> Pdf invoice extension not compatible with magento2.3.3 version, solved bugs and make compatible with magento2.3.3 version.

	****************************************************************
	File Changes
	****************************************************************
	Mageants/PdfInvoice/Helper/Pdf.php
	Mageants/PdfInvoice/view/adminhtml/ui_component/sales_order_view_invoice_grid.xml
	Mageants/PdfInvoice/composer.json
	Mageants/PdfInvoice/etc/module.xml

	****************************************************************
	New added files
	****************************************************************
	Mageants/PdfInvoice/Controller/Adminhtml/Order/Invoice/Printgridinvoices.php
	Mageants/PdfInvoice/Ui/Component/Control/PdfAction.php

***************************************************************************************************************************************************************************************	

	Current version number: 2.0.2
	Date:- 23/04/2019
	****************************************************************
	Bug fixed
	****************************************************************
	--> Multiple order print not work at one time from backend order grid. now solve issue and admin can print multiple order print at a time.
	--> When user place order then receive order print in email but In email the barcode is not display, so solve issue and working fine in all magento version.
	--> The Fax Number and Terms And Condition is not display proper in order print in magento2.3version.
	--> When admin add new variable in invoice print then invoice is not display proper in magento2.3version.
	--> User was redirecting to blank page on invoice printing of pending order from order grid.
	--> In 4th template company details and customer details was same, so change in both details.
	--> In 3rd template in company information some data was default added, so change company information in template, all issue solved and working fine in all magento version.


***************************************************************************************************************************************************************************************

	Current version number: 2.0.1
	Date:- 08/03/2019
	****************************************************************
	Bug fixed
	****************************************************************
	- MageAnts update Pdf invoice extension in magento2.3 version. Now Pdf invoice extension working with Magento2.1,Magento2.2 and Magento2.3.

***************************************************************************************************************************************************************************************

	Current version number: 2.0.1
	Date:- 24/01/2019
	****************************************************************
	Bug fixed
	****************************************************************
	- Update module version name in composer.json file same as module.xml file.

***************************************************************************************************************************************************************************************


	Current version number: 2.0.1
	Date :- 8/10/2018
	************************************************************
    Added New functionality
	************************************************************
	1) Added PDF printing for Order, Invoice, Shipment and Credit memo, Previously admin was able to print only invoice.
	2) Added priting links in order grid, invoice grid, shipment grid and Credit memo grid. There were no link in any grid in previous version.
	3) Four built in templates for PDF
	4) Admin can check preview
	5) Admin can change design individually for order, invoice, shipment, credit memo in same template.
	6) Dynamic variable button added like configuration variables, custom variables, order variables, shipment variables, invoice variables, credit memo variables.
	7) Now admin can also send pdf attachment with order, invoice, shipment and creditmemo email
	8) Updated module with compatible with multi language, rtl - ltr compatible, disbale core printing, font selection from configuration
	9) Admin can add barcode with configuration and horizontal and vartical position
	10) Admin can add business information and contact details in configuration to display in pdf
	11) Added priting links in frontend side to print order, shipment, invoice and credito memo. Previously we didn't use frontend side.


	Current version number: 2.0.0
	Date :- 18/7/2018
	
	************************************************************
    Bug fixed
	************************************************************
	--> Extension working fine in all magento version.
