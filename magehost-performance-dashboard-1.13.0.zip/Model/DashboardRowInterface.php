<?php

namespace MageHost\PerformanceDashboard\Model;

/**
 * Interface DashboardRowInterface
 *
 * @package MageHost\PerformanceDashboard\Model
 */
interface DashboardRowInterface
{
    public function load();
}
